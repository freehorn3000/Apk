Vazirmatn (SIL OFL 1.1) is downloaded here by the GitHub workflow at build time:
Vazirmatn-Regular.ttf, Vazirmatn-Medium.ttf, Vazirmatn-SemiBold.ttf, Vazirmatn-Bold.ttf
If the files are missing the app falls back to the system font.
