package ir.modiriat.app

import android.content.ClipData
import android.content.ClipboardManager
import android.os.PersistableBundle
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

val DebtKinds = listOf("قرض دادم", "قرض گرفتم", "او پس داد", "من پس دادم")

/** Effect on "what they owe me": lent and my repayment raise it, borrowed and their repayment lower it. */
fun debtSign(kind: Int): Int = if (kind == 0 || kind == 3) 1 else -1

fun netOf(es: List<DebtEntry>): Long = es.sumOf { debtSign(it.kind) * it.amount }

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EntryDialog(kind: Int, cards: List<BankCard>, onSave: (DebtEntry) -> Unit, onClose: () -> Unit) {
    var amt by remember { mutableStateOf("") }
    var ts by remember { mutableStateOf<Long?>(todayStart()) }
    var note by remember { mutableStateOf("") }
    var card by remember { mutableLongStateOf(-1L) }
    var hasDue by remember { mutableStateOf(false) }
    var due by remember { mutableStateOf<Long?>(todayStart()) }
    val v = digits(amt).toLongOrNull()
    val opts = listOf(-1L to "بدون اثر روی کارت", 0L to "نقدی") + cards.map { it.id to it.name.ifBlank { it.bank } }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(DebtKinds[kind]) },
        confirmButton = {
            TextButton(
                {
                    onSave(DebtEntry(personId = 0, kind = kind, amount = v!!, ts = ts!!, note = note.trim(), cardId = card, dueTs = if (hasDue && (kind == 0 || kind == 1)) (due ?: 0L) else 0L))
                },
                enabled = v != null && v > 0 && ts != null && (!hasDue || due != null)
            ) { Text("ثبت") }
        },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    amt, { amt = digits(it) }, Modifier.fillMaxWidth(), label = { Text("مبلغ (تومان)") }, visualTransformation = Thousands, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Text("تاریخ", fontWeight = FontWeight.SemiBold)
                DateFields(todayStart()) { ts = it }
                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("یادداشت (اختیاری)") }, singleLine = true)
                Text("اگر پول واقعاً از کارت یا نقدی جابه‌جا شده، حساب را انتخاب کنید. این ثبت هرگز در درآمد و هزینه حساب نمی‌شود.", style = MaterialTheme.typography.bodySmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { opts.forEach { o -> FilterChip(card == o.first, { card = o.first }, { Text(o.second) }) } }
                if (kind == 0 || kind == 1) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text("سررسید بازپرداخت و یادآوری"); Switch(hasDue, { hasDue = it }) }
                    if (hasDue) DateFields(todayStart()) { due = it }
                }
            }
        }
    )
}

@Composable
private fun PersonDialog(onSave: (Person) -> Unit, onClose: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("شخص جدید") },
        confirmButton = { TextButton({ onSave(Person(name = name.trim(), note = note.trim())) }, enabled = name.isNotBlank()) { Text("افزودن") } },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(name, { name = it.take(24) }, Modifier.fillMaxWidth(), label = { Text("نام (همان‌طور که در ثبت صوتی می‌گویید)") }, singleLine = true)
                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("یادداشت (اختیاری)") }, singleLine = true)
            }
        }
    )
}

private fun statement(p: Person, es: List<DebtEntry>, net: Long): String = buildString {
    appendLine("صورت‌حساب ${p.name}")
    es.sortedBy { it.ts }.forEach {
        appendLine("${fmtDateY(it.ts)} | ${DebtKinds[it.kind]} | ${it.amount.fa()} تومان" + if (it.note.isNotBlank()) " | ${it.note}" else "")
    }
    appendLine("-----")
    append(
        if (net > 0) "مانده: شما ${net.fa()} تومان بدهکارید"
        else if (net < 0) "مانده: من ${(-net).fa()} تومان به شما بدهکارم"
        else "مانده: تسویه‌شده"
    )
}

@Composable
fun PeopleScreen(pad: PaddingValues, vm: VM, cards: List<BankCard>, onMsg: (String) -> Unit, onLoans: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    fun share(doc: Doc, pdf: Boolean) {
        scope.launch {
            val f = runCatching { exportDoc(ctx, doc, pdf) }.getOrNull()
            if (f == null) onMsg("ساخت صورت‌حساب ناموفق بود")
            else { sendFile(ctx, f, if (pdf) "application/pdf" else "image/png"); vm.log("صورت‌حساب گرافیکی ارسال شد") }
        }
    }
    val persons by vm.persons.collectAsState()
    val debts by vm.debts.collectAsState()
    val loans by vm.loans.collectAsState()
    val its by vm.installments.collectAsState()
    var open by remember { mutableStateOf<Long?>(null) }
    var addPerson by remember { mutableStateOf(false) }
    var entryKind by remember { mutableStateOf<Int?>(null) }
    var delEntry by remember { mutableStateOf<DebtEntry?>(null) }
    var delPerson by remember { mutableStateOf(false) }
    var settle by remember { mutableStateOf(false) }
    val cardNames = remember(cards) { mapOf(-1L to "", 0L to "نقدی") + cards.associate { it.id to it.name.ifBlank { it.bank } } }
    val nets = persons.associate { p -> p.id to netOf(debts.filter { it.personId == p.id }) }
    val loanPeople = loans.map { it.personId }.toSet()
    val shown = persons.filter { it.id !in loanPeople }
    val person = shown.firstOrNull { it.id == open }

    fun netText(p: Person, n: Long): String =
        if (n > 0) "${p.name} ${n.fa()} تومان به شما بدهکار است" else if (n < 0) "شما ${(-n).fa()} تومان به ${p.name} بدهکارید" else "تسویه‌شده"

    if (person == null) {
        val recv = shown.sumOf { maxOf(nets[it.id] ?: 0L, 0L) }
        val owe = shown.sumOf { maxOf(-(nets[it.id] ?: 0L), 0L) } + loans.sumOf { loanRemaining(it, its, debts) }
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 150.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Seg(listOf("اشخاص", "وام‌ها"), 0, 36.dp) { if (it == 1) onLoans() } }
            item {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Text("بدهی و طلب", fontFamily = Fonts.head, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Button({ addPerson = true }) { Text("＋ شخص") }
                }
            }
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainerLow).padding(18.dp),
                    Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("طلب من", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        Text(recv.fa(), color = incomeColor(), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("بدهی من (با وام‌ها)", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        Text(owe.fa(), color = cs.error, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    }
                }
            }
            if (loans.isNotEmpty()) item { Text("وام‌های بانکی و اقساطشان فقط در کلید «وام‌ها» مدیریت می‌شوند و در این فهرست نمی‌آیند.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
            if (shown.isEmpty()) item { Text("برای شروع، با «＋ شخص» یک حساب بسازید، مثلاً نام یکی از اطرافیان.", color = cs.onSurfaceVariant) }
            items(shown, key = { it.id }) { p ->
                val n = nets[p.id] ?: 0L
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).clickable { open = p.id }.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(cs.primaryContainer), Alignment.Center) {
                        Text(p.name.firstOrNull()?.toString() ?: "•", fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = cs.onPrimaryContainer)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, fontWeight = FontWeight.SemiBold)
                        Text(netText(p, n), style = MaterialTheme.typography.bodySmall, color = if (n > 0) incomeColor() else if (n < 0) cs.error else cs.onSurfaceVariant)
                    }
                    Text(if (n == 0L) "" else (if (n > 0) n else -n).fa(), fontWeight = FontWeight.Bold, color = if (n > 0) incomeColor() else cs.error)
                }
            }
        }
    } else {
        val es = debts.filter { it.personId == person.id }
        val net = nets[person.id] ?: 0L
        val running = HashMap<Long, Long>().also { m -> var acc = 0L; es.sortedWith(compareBy({ it.ts }, { it.id })).forEach { acc += debtSign(it.kind) * it.amount; m[it.id] = acc } }
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 150.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ open = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت") }
                    Text(person.name, fontFamily = Fonts.head, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                }
            }
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainerLow).padding(18.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(netText(person, net), color = if (net > 0) incomeColor() else if (net < 0) cs.error else cs.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
                    if (net != 0L) Text((if (net > 0) net else -net).fa() + " تومان", fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 30.sp)
                    if (person.note.isNotBlank()) Text(person.note, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton({ entryKind = 0 }, Modifier.weight(1f)) { Text(DebtKinds[0]) }
                        FilledTonalButton({ entryKind = 1 }, Modifier.weight(1f)) { Text(DebtKinds[1]) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilledTonalButton({ entryKind = 2 }, Modifier.weight(1f)) { Text(DebtKinds[2]) }
                        FilledTonalButton({ entryKind = 3 }, Modifier.weight(1f)) { Text(DebtKinds[3]) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton({ settle = true }, Modifier.weight(1f), enabled = net != 0L) { Text("تسویه کامل") }
                        OutlinedButton({
                            val cm = ctx.getSystemService(ClipboardManager::class.java)
                            val clip = ClipData.newPlainText("statement", statement(person, es, net))
                            clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
                            cm.setPrimaryClip(clip); onMsg("صورت‌حساب کپی شد")
                            vm.log("صورت‌حساب متنی کپی شد")
                        }, Modifier.weight(1f)) { Text("کپی صورت‌حساب") }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ share(personDoc(person, es, System.currentTimeMillis()), false) }, Modifier.weight(1f), enabled = es.isNotEmpty()) { Text("ارسال صورت‌حساب (تصویر)") }
                        OutlinedButton({ share(personDoc(person, es, System.currentTimeMillis()), true) }, Modifier.weight(1f), enabled = es.isNotEmpty()) { Text("فایل PDF") }
                    }
                }
            }
            if (es.isEmpty()) item { Text("هنوز ثبتی نیست.", color = cs.onSurfaceVariant) }
            items(es, key = { it.id }) { e ->
                val up = debtSign(e.kind) > 0
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(DebtKinds[e.kind], fontWeight = FontWeight.SemiBold)
                        Text(
                            listOfNotNull(fmtDateY(e.ts), e.note.takeIf { it.isNotBlank() }, cardNames[e.cardId]?.takeIf { it.isNotBlank() }).joinToString(" · "),
                            style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                        )
                        if (e.dueTs > 0) Text("سررسید: ${fmtDateY(e.dueTs)}", style = MaterialTheme.typography.bodySmall, color = warnColor())
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(e.amount.fa(), fontWeight = FontWeight.Bold, color = if (up) incomeColor() else cs.error)
                        Text("مانده: ${(running[e.id] ?: 0L).fa()}", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    }
                    TextButton({ share(entryDoc(person, e, running[e.id] ?: 0L, cardNames[e.cardId]?.takeIf { it.isNotBlank() }, System.currentTimeMillis()), false) }) { Text("رسید") }
                    IconButton({ delEntry = e }) { Icon(Icons.Default.Delete, "حذف", tint = cs.onSurfaceVariant) }
                }
            }
            item {
                TextButton({ delPerson = true }, colors = ButtonDefaults.textButtonColors(contentColor = cs.error)) { Text("حذف حساب این شخص") }
            }
        }
    }

    if (addPerson) PersonDialog({ vm.addPerson(it); addPerson = false }) { addPerson = false }
    entryKind?.let { k ->
        EntryDialog(k, cards, { e -> person?.let { vm.addDebt(e.copy(personId = it.id)) }; entryKind = null }) { entryKind = null }
    }
    delEntry?.let { e ->
        AlertDialog(
            onDismissRequest = { delEntry = null },
            title = { Text("حذف این ثبت؟") },
            text = { Text("${DebtKinds[e.kind]} به مبلغ ${e.amount.fa()} تومان از حساب حذف می‌شود.") },
            confirmButton = { TextButton({ vm.delDebt(e); delEntry = null }, colors = ButtonDefaults.textButtonColors(contentColor = cs.error)) { Text("حذف") } },
            dismissButton = { TextButton({ delEntry = null }) { Text("انصراف") } }
        )
    }
    if (delPerson && person != null) AlertDialog(
        onDismissRequest = { delPerson = false },
        title = { Text("حذف حساب ${person.name}؟") },
        text = { Text("فقط حسابی که هیچ ثبتی ندارد حذف می‌شود. برای حذف حساب دارای ثبت، اول ثبت‌ها را پاک کنید.") },
        confirmButton = {
            TextButton({
                vm.delPerson(person) { onMsg("این حساب ثبت دارد و حذف نمی‌شود") }
                delPerson = false; open = null
            }, colors = ButtonDefaults.textButtonColors(contentColor = cs.error)) { Text("حذف") }
        },
        dismissButton = { TextButton({ delPerson = false }) { Text("انصراف") } }
    )
    if (settle && person != null) {
        val n = nets[person.id] ?: 0L
        AlertDialog(
            onDismissRequest = { settle = false },
            title = { Text("تسویه کامل") },
            text = { Text("${netText(person, n)}. یک ثبت تسویه به همین مبلغ اضافه می‌شود. این ثبت روی موجودی هیچ کارتی اثر ندارد؛ اگر پول جابه‌جا شده، پرداخت را دستی ثبت کنید.") },
            confirmButton = {
                TextButton({
                    if (n != 0L) vm.addDebt(DebtEntry(personId = person.id, kind = if (n > 0) 2 else 3, amount = if (n > 0) n else -n, ts = System.currentTimeMillis(), note = "تسویه کامل", cardId = -1, dueTs = 0))
                    settle = false
                }) { Text("تسویه شود") }
            },
            dismissButton = { TextButton({ settle = false }) { Text("انصراف") } }
        )
    }
}

@Composable
fun DebtsScreen(pad: PaddingValues, vm: VM, cards: List<BankCard>, cats: List<Category>, onMsg: (String) -> Unit) {
    var section by remember { mutableIntStateOf(0) }
    if (section == 0) PeopleScreen(pad, vm, cards, onMsg) { section = 1 }
    else LoansScreen(pad, vm, cards, cats, onMsg) { section = 0 }
}
