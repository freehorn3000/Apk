package ir.modiriat.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val ChequeStatus = listOf("در جریان", "پاس‌شده", "برگشتی", "لغوشده", "خرج‌شده")

fun parseJ(y: String, m: String, d: String): Long? {
    val yy = digits(y).toIntOrNull() ?: return null
    val mm = digits(m).toIntOrNull() ?: return null
    val dd = digits(d).toIntOrNull() ?: return null
    if (yy !in 1300..1600 || mm !in 1..12 || dd !in 1..(if (mm <= 6) 31 else if (mm <= 11) 30 else 29)) return null
    return jalaliToMs(yy, mm, dd)
}

/** Jalali date entry (year / month / day). Reports null while the date is invalid. */
@Composable
fun DateFields(init: Long, onChange: (Long?) -> Unit) {
    val j = remember { jalali(init) }
    var y by remember { mutableStateOf(j.first.toString()) }
    var m by remember { mutableStateOf(j.second.toString()) }
    var d by remember { mutableStateOf(j.third.toString()) }
    LaunchedEffect(y, m, d) { onChange(parseJ(y, m, d)) }
    val bad = parseJ(y, m, d) == null
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(y, { y = digits(it).take(4) }, Modifier.weight(1.3f), label = { Text("سال") }, singleLine = true, isError = bad, keyboardOptions = num)
            OutlinedTextField(m, { m = digits(it).take(2) }, Modifier.weight(1f), label = { Text("ماه") }, singleLine = true, isError = bad, keyboardOptions = num)
            OutlinedTextField(d, { d = digits(it).take(2) }, Modifier.weight(1f), label = { Text("روز") }, singleLine = true, isError = bad, keyboardOptions = num)
        }
        if (bad) Text("تاریخ معتبر نیست", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChequeDialog(init: Cheque?, cards: List<BankCard>, onSave: (Cheque) -> Unit, onClose: () -> Unit) {
    var incoming by remember { mutableStateOf(init?.incoming ?: false) }
    var amt by remember { mutableStateOf(init?.amount?.toString() ?: "") }
    var party by remember { mutableStateOf(init?.party ?: "") }
    var due by remember { mutableStateOf<Long?>(init?.dueTs ?: todayStart()) }
    var card by remember { mutableLongStateOf(init?.cardId ?: (cards.firstOrNull()?.id ?: 0L)) }
    var sayad by remember { mutableStateOf(init?.sayad ?: "") }
    var number by remember { mutableStateOf(init?.number ?: "") }
    var note by remember { mutableStateOf(init?.note ?: "") }
    var remind by remember { mutableStateOf(init?.remind ?: true) }
    val v = digits(amt).toLongOrNull()
    val opts = listOf(0L to "نقدی") + cards.map { it.id to it.name.ifBlank { it.bank } }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (init == null) "چک جدید" else "ویرایش چک") },
        confirmButton = {
            TextButton(
                {
                    onSave(
                        Cheque(
                            id = init?.id ?: 0, incoming = incoming, amount = v!!, dueTs = due!!, party = party.trim(), sayad = sayad, number = number.trim(),
                            cardId = card, status = init?.status ?: 0, note = note.trim(), remind = remind,
                            txId = init?.txId ?: 0, tx2Id = init?.tx2Id ?: 0, doneTs = init?.doneTs ?: 0
                        )
                    )
                },
                enabled = v != null && v > 0 && party.isNotBlank() && due != null
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Seg(listOf("پرداختی", "دریافتی"), if (incoming) 1 else 0, 40.dp) { incoming = it == 1 }
                OutlinedTextField(
                    amt, { amt = digits(it) }, Modifier.fillMaxWidth(), label = { Text("مبلغ (تومان)") }, visualTransformation = Thousands, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(party, { party = it.take(30) }, Modifier.fillMaxWidth(), label = { Text(if (incoming) "دریافت از" else "پرداخت به") }, singleLine = true)
                Text("تاریخ سررسید", fontWeight = FontWeight.SemiBold)
                DateFields(init?.dueTs ?: todayStart()) { due = it }
                Text(if (incoming) "کارت یا حساب واریز (هنگام وصول قابل تغییر)" else "حسابی که چک روی آن کشیده شده", fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { opts.forEach { o -> FilterChip(card == o.first, { card = o.first }, { Text(o.second) }) } }
                OutlinedTextField(
                    sayad, { sayad = digits(it).take(16) }, Modifier.fillMaxWidth(), label = { Text("شماره صیاد (اختیاری)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(number, { number = it.take(20) }, Modifier.fillMaxWidth(), label = { Text("شماره چک (اختیاری)") }, singleLine = true)
                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("یادداشت (اختیاری)") }, singleLine = true)
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text("یادآوری سررسید"); Switch(remind, { remind = it }) }
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClearDialog(c: Cheque, cards: List<BankCard>, onOk: (Long, Long) -> Unit, onClose: () -> Unit) {
    var card by remember { mutableLongStateOf(c.cardId) }
    var ts by remember { mutableStateOf<Long?>(c.dueTs) }
    val opts = listOf(0L to "نقدی") + cards.map { it.id to it.name.ifBlank { it.bank } }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("پاس‌کردن چک") },
        confirmButton = { TextButton({ onOk(ts!!, card) }, enabled = ts != null) { Text("ثبت و پاس‌کردن") } },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("با تأیید، یک ${if (c.incoming) "درآمد" else "هزینه"} به مبلغ ${c.amount.fa()} تومان در حساب انتخابی ثبت می‌شود.")
                Text("تاریخ پاس‌شدن", fontWeight = FontWeight.SemiBold)
                DateFields(c.dueTs) { ts = it }
                Text(if (c.incoming) "واریز به" else "برداشت از", fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { opts.forEach { o -> FilterChip(card == o.first, { card = o.first }, { Text(o.second) }) } }
            }
        }
    )
}

@Composable
fun EndorseDialog(c: Cheque, onOk: (Long) -> Unit, onClose: () -> Unit) {
    var ts by remember { mutableStateOf<Long?>(todayStart()) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("خرج‌کردن چک") },
        confirmButton = { TextButton({ onOk(ts!!) }, enabled = ts != null) { Text("ثبت") } },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("چک را به شخص دیگری واگذار کرده‌اید. یک درآمد و یک هزینه به مبلغ ${c.amount.fa()} تومان روی «نقدی» ثبت می‌شود، پس موجودی هیچ حسابی تغییر نمی‌کند ولی گزارش‌ها درست می‌ماند.")
                Text("تاریخ", fontWeight = FontWeight.SemiBold)
                DateFields(todayStart()) { ts = it }
            }
        }
    )
}

@Composable
private fun ChequeRow(c: Cheque, account: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val d = daysLeft(c.dueTs)
    val pend = c.status == 0
    val whenTxt = if (!pend) ChequeStatus[c.status] else if (d < 0) faDigits("${-d}") + " روز گذشته" else if (d == 0) "امروز" else faDigits("$d") + " روز دیگر"
    val whenColor = if (c.status == 2 || (pend && d < 0)) cs.error else if (pend && d <= 3) warnColor() else cs.onSurfaceVariant
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).clickable(onClick = onClick).padding(16.dp),
        Arrangement.SpaceBetween, Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(c.party, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text("${fmtDateY(c.dueTs)} · $account", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(c.amount.fa(), fontWeight = FontWeight.Bold)
            Text(whenTxt, fontSize = 12.sp, color = whenColor, fontWeight = FontWeight.SemiBold)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChequesScreen(pad: PaddingValues, vm: VM, cards: List<BankCard>, cats: List<Category>, bal: Map<Long, Long>, onMsg: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val cheques by vm.cheques.collectAsState()
    var dir by remember { mutableIntStateOf(0) }
    var showDone by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Cheque?>(null) }
    var detail by remember { mutableStateOf<Cheque?>(null) }
    var clearFor by remember { mutableStateOf<Cheque?>(null) }
    var endorseFor by remember { mutableStateOf<Cheque?>(null) }
    var confirm by remember { mutableStateOf<Pair<Cheque, Int>?>(null) } // 2 bounced, 3 cancelled, -1 delete, -2 revert clearing
    val names = remember(cards) { mapOf(0L to "نقدی") + cards.associate { it.id to it.name.ifBlank { it.bank } } }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
    fun defCat(income: Boolean): Long {
        val pool = cats.filter { it.income == income }
        return (pool.getOrNull(if (income) 2 else 6) ?: pool.lastOrNull())?.id ?: 0L
    }

    val pend = cheques.filter { it.status == 0 }
    val issued = pend.filter { !it.incoming }.sumOf { it.amount }
    val incoming = pend.filter { it.incoming }.sumOf { it.amount }
    val total = bal.values.sum()
    val warn = (listOf(0L) + cards.map { it.id }).mapNotNull { id ->
        val due = pend.filter { !it.incoming && it.cardId == id && daysLeft(it.dueTs) <= 30 }.sumOf { it.amount }
        if (due > (bal[id] ?: 0L)) Triple(id, due, bal[id] ?: 0L) else null
    }
    val list = cheques.filter { it.incoming == (dir == 1) && (showDone || it.status == 0 || it.status == 2) }
        .sortedWith(compareBy({ it.status != 0 && it.status != 2 }, { it.dueTs }))

    LazyColumn(
        Modifier.padding(pad).fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 150.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("چک‌ها", fontFamily = Fonts.head, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Button({ adding = true }) { Text("＋ چک") }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainerLow).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Column {
                        Text("چک‌های پرداختی در جریان", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        Text(issued.fa(), color = cs.error, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("چک‌های دریافتی در جریان", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        Text(incoming.fa(), color = incomeColor(), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
                HorizontalDivider(color = cs.outlineVariant)
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("موجودی بعد از چک‌های پرداختی", style = MaterialTheme.typography.bodySmall)
                    Text((total - issued).fa(), fontWeight = FontWeight.SemiBold)
                }
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("با احتساب چک‌های دریافتی (خوش‌بینانه)", style = MaterialTheme.typography.bodySmall)
                    Text((total - issued + incoming).fa(), fontWeight = FontWeight.SemiBold)
                }
                Text(
                    "چک تا پاس نشود در موجودی و در گزارش درآمد و هزینه حساب نمی‌شود.",
                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                )
                warn.forEach { (id, due, b) ->
                    Text(
                        "احتمال کمبود موجودی در «${names[id] ?: ""}»: چک‌های ۳۰ روز آینده ${due.fa()} و موجودی ${b.fa()} تومان",
                        style = MaterialTheme.typography.bodySmall, color = cs.error, fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Seg(listOf("پرداختی", "دریافتی"), dir, 36.dp) { dir = it }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("بسته‌شده‌ها", style = MaterialTheme.typography.bodySmall); Switch(showDone, { showDone = it })
                }
            }
        }
        if (list.isEmpty()) item { Text("چکی در این بخش نیست.", color = cs.onSurfaceVariant) }
        items(list, key = { it.id }) { c -> ChequeRow(c, names[c.cardId] ?: "", { detail = c }) }
    }

    if (adding) ChequeDialog(null, cards, { vm.addCheque(it); if (it.remind) askNotif(); adding = false }) { adding = false }
    edit?.let { e -> ChequeDialog(e, cards, { vm.updCheque(it); if (it.remind) askNotif(); edit = null }) { edit = null } }
    clearFor?.let { c ->
        ClearDialog(c, cards, { ts, card -> vm.clearCheque(c, ts, card, defCat(c.incoming)); clearFor = null }) { clearFor = null }
    }
    endorseFor?.let { c -> EndorseDialog(c, { ts -> vm.endorseCheque(c, ts, defCat(true), defCat(false)); endorseFor = null }) { endorseFor = null } }
    confirm?.let { (c, code) ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(when (code) { 2 -> "چک برگشت خورد؟"; 3 -> "چک لغو شد؟"; -1 -> "حذف چک؟"; else -> "برگشت پاس چک؟" }) },
            text = {
                Text(
                    when (code) {
                        2 -> "هیچ تراکنشی ثبت نمی‌شود و چک به‌عنوان «برگشتی» می‌ماند."
                        3 -> "هیچ تراکنشی ثبت نمی‌شود."
                        -1 -> "چک برای همیشه حذف می‌شود."
                        else -> "تراکنش‌هایی که هنگام پاس‌شدن این چک ثبت شده بود حذف می‌شوند و چک دوباره «در جریان» می‌شود."
                    }
                )
            },
            confirmButton = {
                TextButton({
                    when (code) { -1 -> vm.delCheque(c); -2 -> vm.revertCheque(c); else -> vm.setChequeStatus(c, code) }
                    confirm = null
                }) { Text("تأیید") }
            },
            dismissButton = { TextButton({ confirm = null }) { Text("انصراف") } }
        )
    }
    detail?.let { c ->
        val cur = cheques.firstOrNull { it.id == c.id } ?: c
        ModalBottomSheet(onDismissRequest = { detail = null }) {
            Column(Modifier.padding(20.dp).navigationBarsPadding().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("${if (cur.incoming) "چک دریافتی از" else "چک پرداختی به"} ${cur.party}", fontWeight = FontWeight.Bold)
                Text("${cur.amount.fa()} تومان", fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 28.sp)
                Text("سررسید: ${fmtDateY(cur.dueTs)} · وضعیت: ${ChequeStatus[cur.status]}", color = cs.onSurfaceVariant)
                Text("حساب: ${names[cur.cardId] ?: "نقدی"}", color = cs.onSurfaceVariant)
                if (cur.sayad.isNotBlank()) Text("شماره صیاد: \u202A${cur.sayad}\u202C", color = cs.onSurfaceVariant)
                if (cur.number.isNotBlank()) Text("شماره چک: ${cur.number}", color = cs.onSurfaceVariant)
                if (cur.note.isNotBlank()) Text(cur.note, color = cs.onSurfaceVariant)
                when (cur.status) {
                    0 -> {
                        Button({ clearFor = cur; detail = null }, Modifier.fillMaxWidth()) { Text("پاس شد") }
                        if (cur.incoming) FilledTonalButton({ endorseFor = cur; detail = null }, Modifier.fillMaxWidth()) { Text("خرج شد (واگذار به دیگری)") }
                        FilledTonalButton({ confirm = cur to 2; detail = null }, Modifier.fillMaxWidth()) { Text("برگشت خورد") }
                        FilledTonalButton({ confirm = cur to 3; detail = null }, Modifier.fillMaxWidth()) { Text("لغو شد") }
                        OutlinedButton({ edit = cur; detail = null }, Modifier.fillMaxWidth()) { Text("ویرایش") }
                        TextButton({ confirm = cur to -1; detail = null }, Modifier.fillMaxWidth(), colors = ButtonDefaults.textButtonColors(contentColor = cs.error)) { Text("حذف") }
                    }
                    2, 3 -> {
                        Button({ vm.setChequeStatus(cur, 0); detail = null }, Modifier.fillMaxWidth()) { Text("برگرداندن به «در جریان»") }
                        OutlinedButton({ edit = cur; detail = null }, Modifier.fillMaxWidth()) { Text("ویرایش") }
                        TextButton({ confirm = cur to -1; detail = null }, Modifier.fillMaxWidth(), colors = ButtonDefaults.textButtonColors(contentColor = cs.error)) { Text("حذف") }
                    }
                    else -> {
                        Text("مبلغ و حساب این چک قفل است. برای اصلاح، اول پاس را برگردانید.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                        OutlinedButton({ confirm = cur to -2; detail = null }, Modifier.fillMaxWidth()) { Text("برگشت پاس (حذف تراکنش مرتبط)") }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
