package ir.modiriat.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

@Entity
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val emoji: String, val color: Long, val income: Boolean
)

@Entity
data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Long, val income: Boolean, val catId: Long, val note: String, val ts: Long
)

@Dao
interface D {
    @Query("SELECT * FROM Tx ORDER BY ts DESC") fun txs(): Flow<List<Tx>>
    @Query("SELECT * FROM Category") fun cats(): Flow<List<Category>>
    @Insert suspend fun add(t: Tx)
    @Delete suspend fun del(t: Tx)
}

/** DB passphrase: random 32 bytes, wrapped by an AES-GCM key that never leaves the Android Keystore. */
object Keys {
    fun passphrase(c: Context): ByteArray {
        val sp = c.getSharedPreferences("k", Context.MODE_PRIVATE)
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias("db")) {
            KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
                init(
                    KeyGenParameterSpec.Builder("db", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build()
                )
            }.generateKey()
        }
        val key = ks.getKey("db", null) as SecretKey
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val stored = sp.getString("p", null)
        if (stored == null) {
            val raw = ByteArray(32).also { SecureRandom().nextBytes(it) }
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val out = cipher.iv + cipher.doFinal(raw)
            sp.edit().putString("p", Base64.encodeToString(out, Base64.NO_WRAP)).apply()
            return raw
        }
        val b = Base64.decode(stored, Base64.NO_WRAP)
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, b.copyOfRange(0, 12)))
        return cipher.doFinal(b, 12, b.size - 12)
    }
}

@Database(entities = [Category::class, Tx::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun d(): D

    companion object {
        fun build(c: Context): AppDb {
            System.loadLibrary("sqlcipher")
            return Room.databaseBuilder(c, AppDb::class.java, "m.db")
                .openHelperFactory(SupportOpenHelperFactory(Keys.passphrase(c)))
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        val e = listOf(
                            Triple("خوراک", "🍽️", 0xFFE8A33DL), Triple("حمل‌ونقل", "🚌", 0xFF4C8DF6L),
                            Triple("خانه و قبوض", "🏠", 0xFF8E6CEFL), Triple("خرید", "🛍️", 0xFFE0574FL),
                            Triple("سلامت", "💊", 0xFF2BB3A3L), Triple("تفریح", "🎬", 0xFFEC6FA8L),
                            Triple("سایر", "📦", 0xFF8A9A96L)
                        )
                        val i = listOf(
                            Triple("حقوق", "💼", 0xFF0E8F6EL), Triple("کار آزاد", "💻", 0xFF3FB950L),
                            Triple("سایر درآمدها", "💰", 0xFF8A9A96L)
                        )
                        e.forEach { db.execSQL("INSERT INTO Category(name,emoji,color,income) VALUES(?,?,?,0)", arrayOf(it.first, it.second, it.third)) }
                        i.forEach { db.execSQL("INSERT INTO Category(name,emoji,color,income) VALUES(?,?,?,1)", arrayOf(it.first, it.second, it.third)) }
                    }
                }).build()
        }
    }
}
