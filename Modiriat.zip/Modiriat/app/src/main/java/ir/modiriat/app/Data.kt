package ir.modiriat.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.room.*
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow
import net.zetetic.database.sqlcipher.SupportOpenHelperFactory
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

@Entity
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String, val emoji: String, val color: Long, val income: Boolean
)

/** cardId 0 = cash / no card. */
@Entity
data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Long, val income: Boolean, val catId: Long, val note: String, val ts: Long,
    @ColumnInfo(defaultValue = "0") val cardId: Long = 0
)

@Entity
data class BankCard(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val bank: String, val number: String, val name: String, val initial: Long
)

@Entity
data class Transfer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fromId: Long, val toId: Long, val amount: Long, val note: String, val ts: Long
)

@Entity
data class Cheque(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val incoming: Boolean, val amount: Long, val dueTs: Long, val party: String, val sayad: String, val number: String,
    val cardId: Long, val status: Int, val note: String, val remind: Boolean,
    val txId: Long = 0, val tx2Id: Long = 0, val doneTs: Long = 0
)

@Entity
data class Person(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val note: String)

/** kind: 0 lent (they owe me), 1 borrowed (I owe), 2 they paid back, 3 I paid back. cardId: -1 not linked, 0 cash. */
@Entity
data class DebtEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long, val kind: Int, val amount: Long, val ts: Long, val note: String, val cardId: Long, val dueTs: Long
)

/** A received loan. The lender is also a Person; disbursement and principal repayments are DebtEntry rows of that person. */
@Entity
data class Loan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personId: Long, val lender: String, val principal: Long, val fees: Long, val receivedTs: Long, val cnt: Int,
    val cardId: Long, val note: String, val remind: Boolean, val disbDebtId: Long, val feeTxId: Long
)

@Entity
data class Installment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val loanId: Long, val num: Int, val dueTs: Long, val amount: Long, val interest: Long,
    val paid: Boolean, val paidTs: Long, val paidAmount: Long, val debtId: Long, val txId: Long
)

@Entity
data class Event(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ts: Long, val text: String
)

@Dao
interface D {
    @Query("SELECT * FROM Cheque ORDER BY dueTs") fun cheques(): Flow<List<Cheque>>
    @Insert suspend fun addCheque(c: Cheque): Long
    @Update suspend fun updCheque(c: Cheque)
    @Delete suspend fun delCheque(c: Cheque)
    @Query("DELETE FROM Tx WHERE id=:id") suspend fun delTxId(id: Long)
    @Query("SELECT * FROM Person ORDER BY name") fun persons(): Flow<List<Person>>
    @Insert suspend fun addPerson(p: Person): Long
    @Query("DELETE FROM Person WHERE id=:id") suspend fun delPerson(id: Long)
    @Query("SELECT COUNT(*) FROM DebtEntry WHERE personId=:id") suspend fun personUsed(id: Long): Int
    @Query("SELECT * FROM DebtEntry ORDER BY ts DESC, id DESC") fun debts(): Flow<List<DebtEntry>>
    @Insert suspend fun addDebt(e: DebtEntry): Long
    @Delete suspend fun delDebt(e: DebtEntry)
    @Query("DELETE FROM Cheque") suspend fun clearCheques()
    @Query("DELETE FROM Person") suspend fun clearPersons()
    @Query("DELETE FROM DebtEntry") suspend fun clearDebts()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putCheques(l: List<Cheque>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putPersons(l: List<Person>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putDebts(l: List<DebtEntry>)
    @Query("SELECT * FROM Loan ORDER BY id DESC") fun loans(): Flow<List<Loan>>
    @Insert suspend fun addLoan(l: Loan): Long
    @Update suspend fun updLoan(l: Loan)
    @Query("DELETE FROM Loan WHERE id=:id") suspend fun delLoan(id: Long)
    @Query("SELECT * FROM Installment ORDER BY dueTs") fun installments(): Flow<List<Installment>>
    @Insert suspend fun addInstallments(l: List<Installment>)
    @Update suspend fun updInstallment(i: Installment)
    @Query("DELETE FROM Installment WHERE loanId=:id") suspend fun delInstallments(id: Long)
    @Query("DELETE FROM DebtEntry WHERE id=:id") suspend fun delDebtId(id: Long)
    @Query("DELETE FROM Loan") suspend fun clearLoans()
    @Query("DELETE FROM Installment") suspend fun clearInstallments()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putLoans(l: List<Loan>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putInstallments(l: List<Installment>)
    @Query("SELECT * FROM Event ORDER BY id DESC LIMIT 200") fun events(): Flow<List<Event>>
    @Insert suspend fun addEvent(e: Event)
    @Query("DELETE FROM Event WHERE id NOT IN (SELECT id FROM Event ORDER BY id DESC LIMIT 500)") suspend fun trimEvents()
    @Query("DELETE FROM Event") suspend fun clearEvents()
    @Query("SELECT * FROM Tx ORDER BY ts DESC") fun txs(): Flow<List<Tx>>
    @Query("SELECT * FROM Category") fun cats(): Flow<List<Category>>
    @Query("SELECT * FROM BankCard ORDER BY id") fun cards(): Flow<List<BankCard>>
    @Query("SELECT * FROM Transfer ORDER BY ts DESC") fun trs(): Flow<List<Transfer>>
    @Insert suspend fun add(t: Tx): Long
    @Delete suspend fun del(t: Tx)
    @Insert suspend fun addCat(c: Category)
    @Query("SELECT COUNT(*) FROM Tx WHERE catId=:id") suspend fun used(id: Long): Int
    @Query("DELETE FROM Category WHERE id=:id") suspend fun delCat(id: Long)
    @Insert suspend fun addCard(c: BankCard)
    @Update suspend fun updCard(c: BankCard)
    @Query("DELETE FROM BankCard WHERE id=:id") suspend fun delCard(id: Long)
    @Query("SELECT (SELECT COUNT(*) FROM Tx WHERE cardId=:id) + (SELECT COUNT(*) FROM Transfer WHERE fromId=:id OR toId=:id) + (SELECT COUNT(*) FROM Cheque WHERE cardId=:id) + (SELECT COUNT(*) FROM DebtEntry WHERE cardId=:id) + (SELECT COUNT(*) FROM Loan WHERE cardId=:id)")
    suspend fun cardUsed(id: Long): Int
    @Query("DELETE FROM Tx") suspend fun clearTx()
    @Query("DELETE FROM Transfer") suspend fun clearTr()
    @Query("DELETE FROM BankCard") suspend fun clearCards()
    @Query("DELETE FROM Category") suspend fun clearCats()
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putCats(l: List<Category>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putTxs(l: List<Tx>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putCards(l: List<BankCard>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putTrs(l: List<Transfer>)
    @Insert suspend fun addTr(x: Transfer)
    @Delete suspend fun delTr(x: Transfer)
}

/** DB passphrase: random 32 bytes, wrapped by an AES-GCM key that never leaves the Android Keystore. */
object Keys {
    fun passphrase(c: Context): ByteArray {
        val sp = c.getSharedPreferences("k", Context.MODE_PRIVATE)
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias("db")) {
            // best first: StrongBox + unlocked-only, then unlocked-only, then plain
            val tries = listOf(true to true, false to true, false to false)
            var done = false
            for ((strong, unlocked) in tries) {
                if (done) break
                done = runCatching {
                    val spec = KeyGenParameterSpec.Builder("db", KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    if (unlocked) spec.setUnlockedDeviceRequired(true)
                    if (strong) spec.setIsStrongBoxBacked(true)
                    KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply { init(spec.build()) }.generateKey()
                }.isSuccess
            }
        }
        val key = ks.getKey("db", null) as SecretKey
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val stored = sp.getString("p", null)
        if (stored == null) {
            val raw = ByteArray(32).also { SecureRandom().nextBytes(it) }
            cipher.init(Cipher.ENCRYPT_MODE, key)
            val out = cipher.iv + cipher.doFinal(raw)
            sp.edit().putString("p", Base64.encodeToString(out, Base64.NO_WRAP)).apply()
            return raw
        }
        val b = Base64.decode(stored, Base64.NO_WRAP)
        cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, b.copyOfRange(0, 12)))
        return cipher.doFinal(b, 12, b.size - 12)
    }
}

private val M12 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE Tx ADD COLUMN cardId INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE TABLE IF NOT EXISTS BankCard (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, bank TEXT NOT NULL, number TEXT NOT NULL, name TEXT NOT NULL, initial INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS Transfer (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, fromId INTEGER NOT NULL, toId INTEGER NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL, ts INTEGER NOT NULL)")
    }
}

private val M23 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS Event (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ts INTEGER NOT NULL, text TEXT NOT NULL)")
    }
}

private val M34 = object : Migration(3, 4) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS Cheque (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, incoming INTEGER NOT NULL, amount INTEGER NOT NULL, dueTs INTEGER NOT NULL, party TEXT NOT NULL, sayad TEXT NOT NULL, number TEXT NOT NULL, cardId INTEGER NOT NULL, status INTEGER NOT NULL, note TEXT NOT NULL, remind INTEGER NOT NULL, txId INTEGER NOT NULL, tx2Id INTEGER NOT NULL, doneTs INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS Person (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, note TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS DebtEntry (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, personId INTEGER NOT NULL, kind INTEGER NOT NULL, amount INTEGER NOT NULL, ts INTEGER NOT NULL, note TEXT NOT NULL, cardId INTEGER NOT NULL, dueTs INTEGER NOT NULL)")
    }
}

private val M45 = object : Migration(4, 5) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS Loan (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, personId INTEGER NOT NULL, lender TEXT NOT NULL, principal INTEGER NOT NULL, fees INTEGER NOT NULL, receivedTs INTEGER NOT NULL, cnt INTEGER NOT NULL, cardId INTEGER NOT NULL, note TEXT NOT NULL, remind INTEGER NOT NULL, disbDebtId INTEGER NOT NULL, feeTxId INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS Installment (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, loanId INTEGER NOT NULL, num INTEGER NOT NULL, dueTs INTEGER NOT NULL, amount INTEGER NOT NULL, interest INTEGER NOT NULL, paid INTEGER NOT NULL, paidTs INTEGER NOT NULL, paidAmount INTEGER NOT NULL, debtId INTEGER NOT NULL, txId INTEGER NOT NULL)")
    }
}

@Database(entities = [Category::class, Tx::class, BankCard::class, Transfer::class, Event::class, Cheque::class, Person::class, DebtEntry::class, Loan::class, Installment::class], version = 5, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun d(): D

    companion object {
        fun build(c: Context): AppDb {
            System.loadLibrary("sqlcipher")
            return Room.databaseBuilder(c, AppDb::class.java, "m.db")
                .openHelperFactory(SupportOpenHelperFactory(Keys.passphrase(c)))
                .addMigrations(M12, M23, M34, M45)
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        val e = listOf(
                            Triple("خوراک", "🍽️", 0xFFE8A33DL), Triple("حمل‌ونقل", "🚌", 0xFF4C8DF6L),
                            Triple("خانه و قبوض", "🏠", 0xFF8E6CEFL), Triple("خرید", "🛍️", 0xFFE0574FL),
                            Triple("سلامت", "💊", 0xFF2BB3A3L), Triple("تفریح", "🎬", 0xFFEC6FA8L),
                            Triple("سایر", "📦", 0xFF8A9A96L)
                        )
                        val i = listOf(
                            Triple("حقوق", "💼", 0xFF0E8F6EL), Triple("کار آزاد", "💻", 0xFF3FB950L),
                            Triple("سایر درآمدها", "💰", 0xFF8A9A96L)
                        )
                        e.forEach { db.execSQL("INSERT INTO Category(name,emoji,color,income) VALUES(?,?,?,0)", arrayOf(it.first, it.second, it.third)) }
                        i.forEach { db.execSQL("INSERT INTO Category(name,emoji,color,income) VALUES(?,?,?,1)", arrayOf(it.first, it.second, it.third)) }
                    }
                }).build()
        }
    }
}
