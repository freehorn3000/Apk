package ir.modiriat.app

import android.content.Context
import java.io.File
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** Automatic safety copy of the current data, taken right before a restore, encrypted with the database key. */
object Safety {
    private fun file(ctx: Context) = File(ctx.filesDir, "pre-restore.bin")
    fun exists(ctx: Context) = file(ctx).exists()

    fun save(ctx: Context, json: ByteArray) {
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(Keys.passphrase(ctx), "AES"), GCMParameterSpec(128, iv))
        file(ctx).writeBytes(iv + c.doFinal(json))
    }

    fun load(ctx: Context): Backup.Data? = runCatching {
        val b = file(ctx).readBytes()
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(Keys.passphrase(ctx), "AES"), GCMParameterSpec(128, b.copyOfRange(0, 12)))
        Backup.parse(c.doFinal(b, 12, b.size - 12))
    }.getOrNull()
}
