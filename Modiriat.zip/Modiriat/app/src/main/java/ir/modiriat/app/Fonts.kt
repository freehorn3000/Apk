package ir.modiriat.app

import android.content.Context
import android.graphics.Typeface
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

/**
 * Bundled Vazirmatn (assets/fonts, added by the build workflow). If the files are missing,
 * everything silently falls back to the system font, so a failed download never breaks the app.
 */
object Fonts {
    var body: FontFamily? = null
    var head: FontFamily = FontFamily.Serif
    private var regular: Typeface? = null
    private var bold: Typeface? = null

    fun load(ctx: Context) {
        runCatching {
            val am = ctx.assets
            val have = am.list("fonts")?.toSet() ?: emptySet()
            if ("Vazirmatn-Regular.ttf" in have && "Vazirmatn-Bold.ttf" in have) {
                val list = mutableListOf(
                    Font("fonts/Vazirmatn-Regular.ttf", am, FontWeight.Normal),
                    Font("fonts/Vazirmatn-Bold.ttf", am, FontWeight.Bold)
                )
                if ("Vazirmatn-Medium.ttf" in have) list.add(Font("fonts/Vazirmatn-Medium.ttf", am, FontWeight.Medium))
                if ("Vazirmatn-SemiBold.ttf" in have) list.add(Font("fonts/Vazirmatn-SemiBold.ttf", am, FontWeight.SemiBold))
                val fam = FontFamily(list)
                regular = Typeface.createFromAsset(am, "fonts/Vazirmatn-Regular.ttf")
                bold = Typeface.createFromAsset(am, "fonts/Vazirmatn-Bold.ttf")
                body = fam; head = fam
            }
        }
    }

    fun typeface(isBold: Boolean): Typeface =
        (if (isBold) bold else regular) ?: Typeface.create(Typeface.DEFAULT, if (isBold) Typeface.BOLD else Typeface.NORMAL)
}
