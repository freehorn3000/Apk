package ir.modiriat.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

class Cell(val text: String, val color: Int = 0xFF161B33.toInt(), val bold: Boolean = false)

/** One printable document (statement / receipt). Coordinates are in a 390-unit wide page. */
class Doc(
    val title: String, val left: String, val right: String,
    val partyLabel: String, val party: String,
    val tiles: List<Triple<String, String, Int>>,
    val finalLabel: String, val finalValue: String, val finalPill: String, val formula: String,
    val heads: List<String>, val rows: List<List<Cell>>, val colW: List<Float>,
    val note: String, val id: String
)

private val INK = 0xFF161B33.toInt()
private val MUTED = 0xFF4D5578.toInt()
private val LINE = 0xFFD5DAEA.toInt()
private val ZEBRA = 0xFFF7F8FD.toInt()
private val ROW = 0xFFE8EBF5.toInt()
private val PAGE = 0xFFF1F3FA.toInt()
val TEAL = 0xFF0B7F72.toInt()
val CORAL = 0xFFB63A33.toInt()
private val GOLD = 0xFFE0A93B.toInt()
private val WHITE = Color.WHITE
private val WHITE_SOFT = 0xE6FFFFFF.toInt()

val DebtLabels = listOf("قرض به شما", "قرض از شما", "بازپرداخت شما", "بازپرداخت من")

fun sgn(v: Long): String = if (v < 0) (-v).fa() + "−" else v.fa()

fun docId(vararg parts: String): String {
    val h = MessageDigest.getInstance("SHA-256").digest(parts.joinToString("|").toByteArray()).joinToString("") { "%02X".format(it) }
    return h.substring(0, 4) + "-" + h.substring(4, 8)
}

private fun tp(size: Float, color: Int, bold: Boolean = false) =
    TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = size; this.color = color; typeface = Fonts.typeface(bold) }

/** align: 0 = start (right side, RTL), 1 = opposite (left side), 2 = centre. boxH > 0 centres the text vertically in that height. */
private fun Canvas.txt(s: String, x: Float, y: Float, w: Float, p: TextPaint, align: Int = 0, maxLines: Int = 3, boxH: Float = 0f): Float {
    if (s.isEmpty()) return 0f
    val a = when (align) { 0 -> Layout.Alignment.ALIGN_NORMAL; 1 -> Layout.Alignment.ALIGN_OPPOSITE; else -> Layout.Alignment.ALIGN_CENTER }
    val l = StaticLayout.Builder.obtain(s, 0, s.length, p, w.toInt().coerceAtLeast(1))
        .setAlignment(a).setTextDirection(TextDirectionHeuristics.RTL).setIncludePad(false)
        .setMaxLines(maxLines).setEllipsize(TextUtils.TruncateAt.END).build()
    save()
    translate(x, if (boxH > 0f) y + (boxH - l.height) / 2f else y)
    l.draw(this)
    restore()
    return l.height.toFloat()
}

private fun docHeight(d: Doc): Float {
    var h = 226f + ((d.tiles.size + 1) / 2) * 66f + 8f + 112f + 14f
    if (d.rows.isNotEmpty()) h += 28f + 34f + d.rows.size * 50f + 10f
    if (d.note.isNotBlank()) h += 56f
    return h + 80f
}

private fun draw(c: Canvas, d: Doc, H: Float) {
    val W = 390f; val M = 22f
    val (heroC, deepC) = heroColors()
    val p = Paint(Paint.ANTI_ALIAS_FLAG)
    c.drawColor(WHITE)
    // header
    p.shader = LinearGradient(0f, 0f, W, 150f, heroC, deepC, Shader.TileMode.CLAMP)
    c.drawRect(0f, 0f, W, 150f, p); p.shader = null
    p.color = GOLD; c.drawRoundRect(RectF(W - M - 36f, 22f, W - M, 58f), 12f, 12f, p)
    c.txt("ح", W - M - 36f, 22f, 36f, tp(20f, deepC, true), 2, 1, 36f)
    c.txt("حسابداری شخصی", W - M - 46f - 200f, 30f, 200f, tp(17f, WHITE, true), 0, 1)
    c.txt("شماره سند", M, 24f, 110f, tp(11f, WHITE_SOFT), 1, 1)
    c.txt(d.id, M, 40f, 110f, tp(12f, WHITE, true), 1, 1)
    c.txt(d.title, M, 68f, W - 2 * M, tp(24f, WHITE, true), 0, 1)
    p.shader = LinearGradient(M, 0f, W - M, 0f, intArrayOf(0, GOLD, 0), null, Shader.TileMode.CLAMP)
    c.drawRect(M, 112f, W - M, 113.5f, p); p.shader = null
    c.txt(d.left, W - M - 200f, 124f, 200f, tp(12f, WHITE_SOFT), 0, 1)
    c.txt(d.right, M, 124f, 150f, tp(12f, WHITE_SOFT), 1, 1)
    // party
    c.txt(d.partyLabel, W - M - 220f, 164f, 220f, tp(12f, MUTED), 0, 1)
    c.txt(d.party, W - M - 250f, 182f, 250f, tp(22f, INK, true), 0, 1)
    p.color = 0xFFE6EBFA.toInt(); c.drawCircle(M + 24f, 192f, 24f, p)
    c.txt(d.party.take(1), M, 192f - 24f, 48f, tp(22f, deepC, true), 2, 1, 48f)
    // tiles
    var y = 226f
    val tw = (W - 2 * M - 10f) / 2f
    val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1f; color = LINE }
    d.tiles.forEachIndexed { i, t ->
        val x = if (i % 2 == 0) W - M - tw else M
        val ty = y + (i / 2) * 66f
        c.drawRoundRect(RectF(x, ty, x + tw, ty + 56f), 16f, 16f, stroke)
        c.txt(t.first, x + 14f, ty + 8f, tw - 28f, tp(12f, MUTED), 0, 1)
        c.txt(t.second, x + 14f, ty + 28f, tw - 28f, tp(15f, t.third, true), 0, 1)
    }
    y += ((d.tiles.size + 1) / 2) * 66f + 8f
    // final balance
    p.color = deepC; c.drawRoundRect(RectF(M, y, W - M, y + 112f), 20f, 20f, p)
    c.txt(d.finalLabel, W - M - 18f - 180f, y + 14f, 180f, tp(13f, WHITE_SOFT), 0, 1)
    p.color = GOLD; c.drawRoundRect(RectF(M + 18f, y + 12f, M + 18f + 112f, y + 36f), 12f, 12f, p)
    c.txt(d.finalPill, M + 18f, y + 12f, 112f, tp(12f, deepC, true), 2, 1, 24f)
    c.txt(d.finalValue, M + 18f, y + 36f, W - 2 * M - 36f, tp(32f, WHITE, true), 0, 1)
    c.txt(d.formula, M + 18f, y + 82f, W - 2 * M - 36f, tp(11.5f, WHITE_SOFT), 0, 2)
    y += 112f + 14f
    // table
    if (d.rows.isNotEmpty()) {
        c.txt("ریز ثبت‌ها", W - M - 200f, y, 200f, tp(16f, INK, true), 0, 1)
        y += 28f
        val usable = W - 2 * M - 18f
        val ws = d.colW.map { it * usable }
        val xs = ArrayList<Float>(); var xr = W - M
        ws.forEach { w -> xs.add(xr - w); xr -= w + 6f }
        val aligns = listOf(0, 0, 1, 1)
        d.heads.forEachIndexed { i, h -> c.txt(h, xs[i], y + 8f, ws[i], tp(12f, MUTED, true), aligns[i], 1) }
        p.color = deepC; c.drawRect(M, y + 30f, W - M, y + 32f, p)
        y += 34f
        d.rows.forEachIndexed { r, row ->
            if (r % 2 == 1) { p.color = ZEBRA; c.drawRect(M, y, W - M, y + 50f, p) }
            p.color = ROW; c.drawRect(M, y + 49f, W - M, y + 50f, p)
            row.forEachIndexed { i, cell -> c.txt(cell.text, xs[i], y, ws[i], tp(12.5f, cell.color, cell.bold), aligns[i], 2, 50f) }
            y += 50f
        }
        y += 10f
    }
    if (d.note.isNotBlank()) c.txt(d.note, M, y + 4f, W - 2 * M, tp(11.5f, MUTED), 0, 3)
    // footer
    p.color = PAGE; c.drawRect(0f, H - 72f, W, H, p)
    p.shader = LinearGradient(M, 0f, W - M, 0f, intArrayOf(0, GOLD, 0), null, Shader.TileMode.CLAMP)
    c.drawRect(M, H - 72f, W - M, H - 70.5f, p); p.shader = null
    c.txt("تهیه‌شده با حسابداری شخصی", W - M - 200f, H - 58f, 200f, tp(12f, MUTED), 0, 1)
    c.txt("سند غیررسمی", M, H - 58f, 120f, tp(12f, MUTED), 1, 1)
    c.txt("در صورت مغایرت لطفاً اطلاع دهید.", W - M - 250f, H - 38f, 250f, tp(11.5f, MUTED), 0, 1)
}

suspend fun exportDoc(ctx: Context, d: Doc, pdf: Boolean): File = withContext(Dispatchers.Default) {
    val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
    val f = File(dir, "statement-${d.id}.${if (pdf) "pdf" else "png"}")
    val h = docHeight(d)
    if (pdf) {
        val s = 595f / 390f
        val doc = PdfDocument()
        val page = doc.startPage(PdfDocument.PageInfo.Builder(595, (h * s).toInt(), 1).create())
        page.canvas.scale(s, s); draw(page.canvas, d, h)
        doc.finishPage(page)
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
    } else {
        val s = 1080f / 390f
        val bmp = Bitmap.createBitmap(1080, (h * s).toInt(), Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp); cv.scale(s, s); draw(cv, d, h)
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bmp.recycle()
    }
    f
}

/** Opens the system share sheet. The temporary file lives in the cache and is removed after an hour. */
fun sendFile(ctx: Context, f: File, mime: String) {
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    LockCtl.skipNext = true
    ctx.startActivity(Intent.createChooser(i, "ارسال").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun cleanShare(ctx: Context) {
    File(ctx.cacheDir, "share").listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 3_600_000L }?.forEach { it.delete() }
}

// ---------- builders ----------

fun personDoc(p: Person, es: List<DebtEntry>, now: Long): Doc {
    val sorted = es.sortedWith(compareBy({ it.ts }, { it.id }))
    var acc = 0L
    val rows = sorted.map { e ->
        val up = debtSign(e.kind) > 0
        acc += debtSign(e.kind) * e.amount
        listOf(
            Cell(fmtDate(e.ts)),
            Cell(DebtLabels[e.kind] + if (e.note.isNotBlank()) "\n" + e.note else ""),
            Cell(e.amount.fa() + if (up) "+" else "−", if (up) TEAL else CORAL, true),
            Cell(sgn(acc))
        )
    }
    val net = acc
    fun sum(k: Int) = es.filter { it.kind == k }.sumOf { it.amount }
    return Doc(
        "صورت‌حساب بدهی و طلب", "تاریخ صدور: ${fmtDateY(now)}",
        if (sorted.isEmpty()) "" else "از ${fmtDate(sorted.first().ts)} تا ${fmtDate(sorted.last().ts)}",
        "حساب شما", p.name,
        listOf(Triple(DebtLabels[0], sum(0).fa(), TEAL), Triple(DebtLabels[1], sum(1).fa(), CORAL), Triple(DebtLabels[2], sum(2).fa(), INK), Triple(DebtLabels[3], sum(3).fa(), INK)),
        "مانده نهایی (تومان)", (if (net < 0) -net else net).fa(),
        if (net > 0) "شما بدهکارید" else if (net < 0) "من بدهکارم" else "تسویه‌شده",
        "${sum(0).fa()} − ${sum(1).fa()} − ${sum(2).fa()} + ${sum(3).fa()} = ${sgn(net)}",
        listOf("تاریخ", "شرح", "مبلغ", "مانده"), rows, listOf(0.2f, 0.28f, 0.26f, 0.26f),
        "مانده مثبت یعنی شما به من بدهکارید و مانده منفی یعنی من به شما بدهکارم.",
        docId(p.name, es.size.toString(), net.toString(), fmtDateY(now))
    )
}

fun entryDoc(p: Person, e: DebtEntry, after: Long, account: String?, now: Long): Doc = Doc(
    "رسید ثبت بدهی و طلب", "تاریخ صدور: ${fmtDateY(now)}", "",
    "شخص", p.name,
    listOf(
        Triple("تاریخ ثبت", fmtDateY(e.ts), INK), Triple("نوع", DebtLabels[e.kind], if (debtSign(e.kind) > 0) TEAL else CORAL),
        Triple("حساب", account ?: "ثبت دفتری", INK), Triple("یادداشت", e.note.ifBlank { "—" }, INK)
    ),
    "مبلغ (تومان)", e.amount.fa(), DebtLabels[e.kind],
    "مانده حساب پس از این ثبت: ${sgn(after)} (مثبت یعنی شما بدهکارید)",
    emptyList(), emptyList(), listOf(0.25f, 0.25f, 0.25f, 0.25f), "",
    docId(p.name, e.id.toString(), e.amount.toString(), e.ts.toString())
)

fun loanDoc(l: Loan, its: List<Installment>, remainingPrincipal: Long, now: Long): Doc {
    val sorted = its.sortedBy { it.num }
    val paid = sorted.count { it.paid }
    val over = sorted.count { !it.paid && daysLeft(it.dueTs) < 0 }
    val rows = sorted.map { i ->
        val st = if (i.paid) "پرداخت‌شده" else if (daysLeft(i.dueTs) < 0) "معوق" else "در انتظار"
        listOf(
            Cell(i.num.toLong().fa()), Cell(fmtDateY(i.dueTs)), Cell(i.amount.fa(), INK, true),
            Cell(st, if (i.paid) TEAL else if (st == "معوق") CORAL else MUTED, true)
        )
    }
    val left = sorted.filter { !it.paid }.sumOf { it.amount }
    return Doc(
        "صورت‌حساب وام", "تاریخ صدور: ${fmtDateY(now)}", "${sorted.size.toLong().fa()} قسط",
        "وام‌دهنده", l.lender,
        listOf(
            Triple("مبلغ وام", l.principal.fa(), INK), Triple("جمع اقساط", sorted.sumOf { it.amount }.fa(), INK),
            Triple("پرداخت‌شده", "${paid.toLong().fa()} از ${sorted.size.toLong().fa()}", TEAL), Triple("مانده اصل", remainingPrincipal.fa(), CORAL)
        ),
        "مانده اقساط (تومان)", left.fa(), if (left == 0L) "تسویه‌شده" else if (over > 0) "${over.toLong().fa()} قسط معوق" else "در جریان",
        sorted.firstOrNull { !it.paid }?.let { "قسط بعدی: ${fmtDateY(it.dueTs)} · ${it.amount.fa()} تومان" } ?: "همه اقساط پرداخت شده است",
        listOf("قسط", "سررسید", "مبلغ", "وضعیت"), rows, listOf(0.14f, 0.34f, 0.28f, 0.24f),
        "تقسیم قسط به اصل و سود برآوردی است. مبنا همیشه برگه رسمی بانک است.",
        docId(l.lender, l.id.toString(), left.toString(), fmtDateY(now))
    )
}

fun installmentReceipt(l: Loan, i: Installment, total: Int, remainingPrincipal: Long, now: Long): Doc = Doc(
    "رسید پرداخت قسط وام", "تاریخ صدور: ${fmtDateY(now)}", "",
    "وام‌دهنده", l.lender,
    listOf(
        Triple("شماره قسط", "${i.num.toLong().fa()} از ${total.toLong().fa()}", INK), Triple("تاریخ پرداخت", fmtDateY(i.paidTs), INK),
        Triple("اصل ≈", (i.paidAmount - i.interest).coerceAtLeast(0L).fa(), TEAL), Triple("سود و جریمه ≈", minOf(i.interest, i.paidAmount).fa(), CORAL)
    ),
    "مبلغ پرداختی (تومان)", i.paidAmount.fa(), "پرداخت‌شده",
    "مانده اصل وام تا این لحظه: ${remainingPrincipal.fa()} تومان",
    emptyList(), emptyList(), listOf(0.25f, 0.25f, 0.25f, 0.25f), "",
    docId(l.lender, i.id.toString(), i.paidAmount.toString(), i.paidTs.toString())
)
