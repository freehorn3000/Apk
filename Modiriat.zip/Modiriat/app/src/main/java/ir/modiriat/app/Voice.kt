package ir.modiriat.app

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Push-to-talk wrapper: start() on press, stop() on release delivers the final text. */
class Voice(private val ctx: Context, private val onText: (String) -> Unit, private val onState: (String) -> Unit) {
    private var sr: SpeechRecognizer? = null

    fun start() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { onState("سرویس تشخیص گفتار گوشی در دسترس نیست"); return }
        val offline = ctx.getSharedPreferences("set", Context.MODE_PRIVATE).getBoolean("offline", true)
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    onState("")
                    if (t.isNullOrBlank()) onState("متوجه نشدم، دوباره بگویید") else onText(t)
                }
                override fun onError(e: Int) {
                    onState(
                        when (e) {
                            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "چیزی نشنیدم، دکمه را نگه دارید و صحبت کنید"
                            12, 13 -> "بسته آفلاین فارسی روی گوشی نیست. بسته زبان فارسی را در تنظیمات گوشی دانلود کنید، یا در تنظیمات برنامه حالت آفلاین را خاموش کنید (صدا به Google می‌رود)"
                            else -> "خطا در تشخیص گفتار ($e)"
                        }
                    )
                }
                override fun onPartialResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onState("«$it»") }
                }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline)
            )
        }
    }

    fun stop() { sr?.stopListening() }
    fun destroy() { sr?.destroy(); sr = null }
}
