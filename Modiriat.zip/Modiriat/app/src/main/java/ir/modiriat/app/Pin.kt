package ir.modiriat.app

import android.content.Context
import android.util.Base64
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** App PIN: used only when the phone has no screen lock / strong biometric. Stored as salted PBKDF2 hash. */
object Pin {
    private fun sp(c: Context) = c.getSharedPreferences("pin", Context.MODE_PRIVATE)
    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)
    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)).encoded

    fun isSet(c: Context) = sp(c).contains("h")

    fun set(c: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp(c).edit().putString("s", b64(salt)).putString("h", b64(hash(pin, salt))).putInt("f", 0).putLong("u", 0).apply()
    }

    /** 0 = correct, -1 = wrong, >0 = locked for that many seconds. */
    fun check(c: Context, pin: String): Int {
        val p = sp(c)
        val now = System.currentTimeMillis()
        val until = p.getLong("u", 0)
        if (now < until) return ((until - now) / 1000 + 1).toInt()
        val s = p.getString("s", null) ?: return -1
        val h = p.getString("h", null) ?: return -1
        if (MessageDigest.isEqual(hash(pin, unb64(s)), unb64(h))) { p.edit().putInt("f", 0).apply(); return 0 }
        val f = p.getInt("f", 0) + 1
        val lock = if (f >= 5) minOf(3600L, 30L shl (f - 5).coerceAtMost(7)) else 0L
        p.edit().putInt("f", f).putLong("u", now + lock * 1000).apply()
        return if (lock > 0) lock.toInt() else -1
    }
}

class PinReq(val setup: Boolean, val onOk: () -> Unit)

object Gate { var req by mutableStateOf<PinReq?>(null) }

@Composable
fun PinHost() {
    val r = Gate.req ?: return
    val ctx = LocalContext.current
    var a by remember(r) { mutableStateOf("") }
    var b by remember(r) { mutableStateOf("") }
    var err by remember(r) { mutableStateOf("") }
    val keys = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)
    AlertDialog(
        onDismissRequest = { Gate.req = null },
        title = { Text(if (r.setup) "ساخت رمز برنامه" else "رمز برنامه") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (r.setup) Text("برای محافظت از اطلاعات، یک رمز ۴ تا ۸ رقمی بسازید.")
                OutlinedTextField(a, { a = digits(it).take(8) }, label = { Text(if (r.setup) "رمز جدید" else "رمز") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = keys)
                if (r.setup) OutlinedTextField(b, { b = digits(it).take(8) }, label = { Text("تکرار رمز") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = keys)
                if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = {
            TextButton({
                if (r.setup) {
                    if (a.length < 4) err = "رمز باید حداقل ۴ رقم باشد"
                    else if (a != b) err = "دو رمز یکسان نیست"
                    else { Pin.set(ctx, a); Gate.req = null; r.onOk() }
                } else {
                    val x = Pin.check(ctx, a)
                    if (x == 0) { Gate.req = null; r.onOk() }
                    else { err = if (x > 0) "تلاش زیاد. ${x.toLong().fa()} ثانیه صبر کنید" else "رمز اشتباه است"; a = "" }
                }
            }) { Text("تأیید") }
        },
        dismissButton = { TextButton({ Gate.req = null }) { Text("انصراف") } }
    )
}
