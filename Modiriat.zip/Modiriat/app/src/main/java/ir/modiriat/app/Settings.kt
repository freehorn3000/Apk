package ir.modiriat.app

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class PwReq(val export: Boolean, val uri: Uri? = null)

@Composable
private fun RowItem(title: String, sub: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).clickable(onClick = onClick).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
    }
}

@Composable
fun SettingsScreen(pad: PaddingValues, vm: VM, onMsg: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val sp = remember { ctx.getSharedPreferences("set", Context.MODE_PRIVATE) }
    var offline by remember { mutableStateOf(sp.getBoolean("offline", true)) }
    var pwdFor by remember { mutableStateOf<PwReq?>(null) }
    var pendingPw by remember { mutableStateOf("") }
    var wipe by remember { mutableStateOf(false) }
    val deviceLock = remember {
        ctx.activity()?.let { BiometricManager.from(it).canAuthenticate(BIOMETRIC_STRONG or DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS } ?: false
    }

    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri == null) pendingPw = ""
        else scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching {
                    val blob = Backup.encrypt(pendingPw, Backup.toJson(vm.cats.value, vm.txs.value, vm.cards.value, vm.trs.value))
                    ctx.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(blob) }
                }.isSuccess
            }
            pendingPw = ""
            onMsg(if (ok) "پشتیبان ذخیره شد" else "ذخیره پشتیبان ناموفق بود")
        }
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) pwdFor = PwReq(false, uri) }

    LazyColumn(
        Modifier.padding(pad).fillMaxSize(),
        contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 100.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("تنظیمات", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("امنیت", color = cs.primary, fontWeight = FontWeight.Bold) }
        item {
            RowItem(
                "رمز برنامه",
                if (deviceLock) "قفل گوشی شما فعال است و برای ورود استفاده می‌شود. رمز برنامه فقط وقتی لازم است که قفل گوشی نباشد."
                else if (Pin.isSet(ctx)) "فعال. برای تغییر لمس کنید" else "قفل گوشی ندارید. برای محافظت، رمز برنامه بسازید"
            ) {
                if (Pin.isSet(ctx)) Gate.req = PinReq(false) { Gate.req = PinReq(true) { onMsg("رمز برنامه تغییر کرد") } }
                else Gate.req = PinReq(true) { onMsg("رمز برنامه ساخته شد") }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).padding(16.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("تشخیص صدا ترجیحاً آفلاین", fontWeight = FontWeight.SemiBold)
                    Text("با بسته زبان فارسی روی گوشی، صدا به اینترنت نمی‌رود. اگر بسته نباشد ثبت صوتی کار نمی‌کند.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
                Switch(offline, { offline = it; sp.edit().putBoolean("offline", it).apply() })
            }
        }
        item { Text("اطلاعات", color = cs.primary, fontWeight = FontWeight.Bold) }
        item { RowItem("پشتیبان‌گیری رمزنگاری‌شده", "همه اطلاعات در یک فایل با رمز دلخواه ذخیره می‌شود") { pwdFor = PwReq(true) } }
        item { RowItem("بازیابی از پشتیبان", "اطلاعات فعلی با محتوای فایل جایگزین می‌شود") { importL.launch(arrayOf("*/*")) } }
        item { Text("خطر", color = cs.error, fontWeight = FontWeight.Bold) }
        item { RowItem("پاک‌کردن کل اطلاعات", "همه تراکنش‌ها، کارت‌ها و کلید رمزنگاری برای همیشه پاک می‌شود") { wipe = true } }
    }

    pwdFor?.let { r ->
        PwDialog(
            title = if (r.export) "رمز پشتیبان" else "رمز فایل پشتیبان",
            confirm = r.export,
            note = if (r.export) "این رمز را فراموش نکنید. بدون آن فایل قابل بازیابی نیست." else "اطلاعات فعلی با محتوای فایل جایگزین می‌شود.",
            onOk = { pw ->
                pwdFor = null
                if (r.export) { pendingPw = pw; exportL.launch("hesab-backup.hsb") }
                else scope.launch {
                    val data = withContext(Dispatchers.IO) {
                        runCatching {
                            val blob = ctx.contentResolver.openInputStream(r.uri!!)!!.use { it.readBytes() }
                            Backup.parse(Backup.decrypt(pw, blob))
                        }.getOrNull()
                    }
                    if (data == null) onMsg("رمز اشتباه است یا فایل معتبر نیست")
                    else vm.restore(data) { ok -> onMsg(if (ok) "اطلاعات بازیابی شد" else "بازیابی ناموفق بود") }
                }
            },
            onClose = { pwdFor = null }
        )
    }

    if (wipe) AlertDialog(
        onDismissRequest = { wipe = false },
        title = { Text("پاک‌کردن کل اطلاعات؟") },
        text = { Text("همه تراکنش‌ها، کارت‌ها و دسته‌ها برای همیشه پاک می‌شود و برگشت ندارد. اگر پشتیبان ندارید، اول پشتیبان بگیرید.") },
        confirmButton = {
            TextButton(
                { wipe = false; ctx.activity()?.let { a -> authenticate(a, "تأیید پاک‌کردن") { vm.wipe(a) } } },
                colors = ButtonDefaults.textButtonColors(contentColor = cs.error)
            ) { Text("پاک شود") }
        },
        dismissButton = { TextButton({ wipe = false }) { Text("انصراف") } }
    )
}

@Composable
fun PwDialog(title: String, confirm: Boolean, note: String, onOk: (String) -> Unit, onClose: () -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    val ok = a.length >= 8 && (!confirm || a == b)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(note, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(a, { a = it }, label = { Text("رمز (حداقل ۸ نویسه)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                if (confirm) OutlinedTextField(b, { b = it }, label = { Text("تکرار رمز") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            }
        },
        confirmButton = { TextButton({ onOk(a) }, enabled = ok) { Text("تأیید") } },
        dismissButton = { TextButton(onClose) { Text("انصراف") } }
    )
}
