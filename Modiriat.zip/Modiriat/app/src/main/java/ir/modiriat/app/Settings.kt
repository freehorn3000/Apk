package ir.modiriat.app

import android.content.Context
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** mode: 0 save backup to a file, 1 share backup, 2 restore, 3 check a backup file without restoring. */
private class PwReq(val mode: Int, val uri: Uri? = null)

@Composable
private fun RowItem(title: String, sub: String, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).clickable(onClick = onClick).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(title, fontWeight = FontWeight.SemiBold)
        Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun SwitchItem(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).padding(16.dp),
        Arrangement.SpaceBetween, Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Switch(on, onChange)
    }
}

@Composable
private fun Head(t: String, danger: Boolean = false) =
    Text(t, color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)

@Composable
fun SettingsScreen(pad: PaddingValues, vm: VM, onMsg: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val sp = remember { ctx.getSharedPreferences("set", Context.MODE_PRIVATE) }
    val events by vm.events.collectAsState()
    var offline by remember { mutableStateOf(sp.getBoolean("offline", true)) }
    var voiceConfirm by remember { mutableStateOf(sp.getBoolean("voiceConfirm", false)) }
    var remOn by remember { mutableStateOf(sp.getBoolean("remOn", true)) }
    var remHour by remember { mutableIntStateOf(sp.getInt("remHour", 9)) }
    var remDays by remember { mutableIntStateOf(sp.getInt("remDays", 3)) }
    var lockDelay by remember { mutableIntStateOf(sp.getInt("lockDelay", 0)) }
    var lastBackup by remember { mutableLongStateOf(sp.getLong("lastBackup", 0L)) }
    var safetyExists by remember { mutableStateOf(Safety.exists(ctx)) }
    var showLog by remember { mutableStateOf(false) }
    var clearLog by remember { mutableStateOf(false) }
    var pwdFor by remember { mutableStateOf<PwReq?>(null) }
    var pendingPw by remember { mutableStateOf("") }
    var importMode by remember { mutableIntStateOf(2) }
    var pendingRestore by remember { mutableStateOf<Backup.Data?>(null) }
    var restoreSafety by remember { mutableStateOf<Backup.Data?>(null) }
    var wipe by remember { mutableStateOf(false) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun reRem() { Reminders.reschedule(ctx, vm.cheques.value, vm.debts.value, vm.loans.value, vm.installments.value) }
    val deviceLock = remember {
        ctx.activity()?.let { BiometricManager.from(it).canAuthenticate(BIOMETRIC_STRONG or DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS } ?: false
    }
    val lockOpts = listOf(0, 30, 60, 300)

    fun json() = Backup.toJson(
        vm.cats.value, vm.txs.value, vm.cards.value, vm.trs.value, vm.cheques.value, vm.persons.value, vm.debts.value, vm.loans.value, vm.installments.value
    )
    fun marked() { lastBackup = System.currentTimeMillis(); sp.edit().putLong("lastBackup", lastBackup).apply() }

    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val pw = pendingPw
        pendingPw = ""
        if (uri == null) return@rememberLauncherForActivityResult
        if (pw.length < 8) { onMsg("رمز پشتیبان از دست رفت. دوباره پشتیبان بگیرید"); return@rememberLauncherForActivityResult }
        scope.launch {
            // write, then read the file back and check it decrypts and matches
            val verified: Boolean? = withContext(Dispatchers.IO) {
                runCatching {
                    ctx.contentResolver.openOutputStream(uri, "wt")!!.use { it.write(Backup.encrypt(pw, json())) }
                    val back = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    val d = Backup.parse(Backup.decrypt(pw, back))
                    d.txs.size == vm.txs.value.size && d.cards.size == vm.cards.value.size && d.trs.size == vm.trs.value.size &&
                        d.cheques.size == vm.cheques.value.size && d.debts.size == vm.debts.value.size && d.loans.size == vm.loans.value.size
                }.getOrNull()
            }
            if (verified == true) marked()
            vm.log(if (verified == true) "پشتیبان ذخیره و بررسی شد" else "پشتیبان‌گیری ناموفق یا بررسی‌نشده بود")
            onMsg(
                when (verified) {
                    true -> "پشتیبان ذخیره شد و سلامت فایل بررسی شد ✓"
                    false -> "فایل ذخیره شد ولی بررسی سلامت ناموفق بود. دوباره پشتیبان بگیرید"
                    null -> "ذخیره پشتیبان ناموفق بود"
                }
            )
        }
    }
    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) pwdFor = PwReq(importMode, uri) }

    if (showLog) {
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 150.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton({ showLog = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت") }
                        Text("رویدادها", fontFamily = Fonts.head, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    }
                    if (events.isNotEmpty()) TextButton({ clearLog = true }) { Text("پاک‌کردن") }
                }
            }
            item { Text("گزارش فعالیت فقط روی همین گوشی و داخل دیتابیس رمزنگاری‌شده می‌ماند.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
            if (events.isEmpty()) item { Text("هنوز رویدادی ثبت نشده.", color = cs.onSurfaceVariant) }
            items(events, key = { it.id }) { e ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cs.surfaceContainerLow).padding(14.dp)) {
                    Text(e.text)
                    Text("${fmtDate(e.ts)} · ${fmtTime(e.ts)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
        }
    } else LazyColumn(
        Modifier.padding(pad).fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 150.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text("تنظیمات", fontFamily = Fonts.head, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }

        item { Head("ظاهر") }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("رنگ برنامه", fontWeight = FontWeight.SemiBold)
                Seg(PaletteNames, Pref.palette, 40.dp) { Pref.palette = it; Pref.save(ctx) }
                Text("حالت نمایش", fontWeight = FontWeight.SemiBold)
                Seg(listOf("خودکار", "روشن", "تیره"), Pref.mode, 40.dp) { Pref.mode = it; Pref.save(ctx) }
            }
        }

        item { Head("ثبت صوتی") }
        item {
            SwitchItem("اول نشان بده، بعد ثبت کن", "قبل از ذخیره، خلاصه مبلغ و دسته را می‌بینید و تأیید می‌کنید. اگر خاموش باشد، بلافاصله ثبت می‌شود و دکمه واگرد دارید.", voiceConfirm) {
                voiceConfirm = it; sp.edit().putBoolean("voiceConfirm", it).apply()
            }
        }
        item {
            SwitchItem("تشخیص صدا ترجیحاً آفلاین", "با بسته زبان فارسی روی گوشی، صدا به اینترنت نمی‌رود. اگر بسته نباشد ثبت صوتی کار نمی‌کند.", offline) {
                offline = it; sp.edit().putBoolean("offline", it).apply()
            }
        }

        item { Head("یادآوری سررسید") }
        item {
            SwitchItem(
                "یادآوری چک، بدهی و اقساط",
                "اعلان‌ها عمومی هستند و نام یا مبلغ در صفحه قفل نمی‌آید. روی بعضی گوشی‌ها (مثل شیائومی و هوآوی) باید برای برنامه «اجرای خودکار» و «بدون محدودیت باتری» را روشن کنید.",
                remOn
            ) {
                remOn = it; sp.edit().putBoolean("remOn", it).apply(); reRem()
                if (it && Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    notif.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ساعت یادآوری", fontWeight = FontWeight.SemiBold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(7, 8, 9, 10, 12, 15, 18, 20).forEach { h ->
                        Pill(faDigits("$h") + ":۰۰", remHour == h) { remHour = h; sp.edit().putInt("remHour", h).apply(); reRem() }
                    }
                }
                Text("چند روز قبل (علاوه بر خود روز سررسید)", fontWeight = FontWeight.SemiBold)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0, 1, 2, 3, 5, 7).forEach { d ->
                        Pill(if (d == 0) "فقط روز سررسید" else faDigits("$d") + " روز", remDays == d) { remDays = d; sp.edit().putInt("remDays", d).apply(); reRem() }
                    }
                }
            }
        }

        item { Head("امنیت") }
        item {
            RowItem(
                "رمز برنامه",
                if (deviceLock) "قفل گوشی شما فعال است و برای ورود استفاده می‌شود. رمز برنامه فقط وقتی لازم است که قفل گوشی نباشد."
                else if (Pin.isSet(ctx)) "فعال. برای تغییر لمس کنید" else "قفل گوشی ندارید. برای محافظت، رمز برنامه بسازید"
            ) {
                if (Pin.isSet(ctx)) Gate.req = PinReq(false) { Gate.req = PinReq(true) { onMsg("رمز برنامه تغییر کرد") } }
                else Gate.req = PinReq(true) { onMsg("رمز برنامه ساخته شد") }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("قفل خودکار بعد از خروج از برنامه", fontWeight = FontWeight.SemiBold)
                Seg(listOf("فوری", "۳۰ ثانیه", "۱ دقیقه", "۵ دقیقه"), lockOpts.indexOf(lockDelay).coerceAtLeast(0), 40.dp) {
                    lockDelay = lockOpts[it]; sp.edit().putInt("lockDelay", lockDelay).apply()
                }
                Text("هنگام انتخاب فایل پشتیبان یا ارسال صورت‌حساب، برنامه قفل نمی‌شود.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
        }
        item { RowItem("رویدادها", "چه چیزی، کی ثبت، حذف، کپی یا بازیابی شده است") { showLog = true } }

        item { Head("پشتیبان‌گیری و بازیابی") }
        item {
            val stale = lastBackup == 0L || System.currentTimeMillis() - lastBackup > 30L * 86_400_000L
            Text(
                if (lastBackup == 0L) "هنوز پشتیبان نگرفته‌اید." else "آخرین پشتیبان: ${fmtDateY(lastBackup)}",
                color = if (stale) warnColor() else cs.onSurfaceVariant, fontWeight = FontWeight.SemiBold
            )
        }
        item { RowItem("ذخیره پشتیبان رمزنگاری‌شده", "فایل را در حافظه گوشی ذخیره می‌کند و سلامتش را بلافاصله بررسی می‌کند") { pwdFor = PwReq(0) } }
        item { RowItem("ارسال پشتیبان", "فایل رمزنگاری‌شده را مستقیم به تلگرام، Drive، ایمیل و … می‌فرستد") { pwdFor = PwReq(1) } }
        item { RowItem("بررسی فایل پشتیبان", "فایل و رمز را آزمایش می‌کند، بدون اینکه چیزی را جایگزین کند") { importMode = 3; LockCtl.skipNext = true; importL.launch(arrayOf("*/*")) } }
        item { RowItem("بازیابی از پشتیبان", "اطلاعات فعلی با محتوای فایل جایگزین می‌شود. قبلش خودکار یک نسخه ایمنی گرفته می‌شود") { importMode = 2; LockCtl.skipNext = true; importL.launch(arrayOf("*/*")) } }
        if (safetyExists) item {
            RowItem("بازگردانی نسخه ایمنی", "اطلاعات پیش از آخرین بازیابی را برمی‌گرداند (اگر فایل اشتباه بود)") {
                restoreSafety = Safety.load(ctx)
                if (restoreSafety == null) onMsg("نسخه ایمنی خوانده نشد")
            }
        }

        item { Head("خطر", true) }
        item { RowItem("پاک‌کردن کل اطلاعات", "همه تراکنش‌ها، کارت‌ها و کلید رمزنگاری برای همیشه پاک می‌شود") { wipe = true } }
        item { Text("نسخه ۱٫۵ · اطلاعات فقط روی همین گوشی است و برنامه مجوز اینترنت ندارد", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant) }
    }

    pwdFor?.let { r ->
        val confirm = r.mode == 0 || r.mode == 1
        PwDialog(
            title = if (confirm) "رمز پشتیبان" else "رمز فایل پشتیبان",
            confirm = confirm,
            note = if (confirm) "این رمز را فراموش نکنید. بدون آن فایل قابل بازیابی نیست." else "رمزی که هنگام پشتیبان‌گیری گذاشتید را وارد کنید.",
            onOk = { pw ->
                pwdFor = null
                when (r.mode) {
                    0 -> { pendingPw = pw; LockCtl.skipNext = true; exportL.launch("hesab-backup.hsb") }
                    1 -> scope.launch {
                        val f = withContext(Dispatchers.IO) {
                            runCatching {
                                val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
                                File(dir, "hesab-backup.hsb").also { it.writeBytes(Backup.encrypt(pw, json())) }
                            }.getOrNull()
                        }
                        if (f == null) onMsg("ساخت پشتیبان ناموفق بود")
                        else { marked(); vm.log("پشتیبان برای ارسال ساخته شد"); sendFile(ctx, f, "application/octet-stream") }
                    }
                    else -> scope.launch {
                        val data = withContext(Dispatchers.IO) {
                            runCatching {
                                val blob = ctx.contentResolver.openInputStream(r.uri!!)!!.use { it.readBytes() }
                                Backup.parse(Backup.decrypt(pw, blob))
                            }.getOrNull()
                        }
                        if (data == null) onMsg("رمز اشتباه است یا فایل معتبر نیست")
                        else if (r.mode == 3) onMsg(
                            "فایل سالم است: ${data.txs.size.toLong().fa()} تراکنش، ${data.cards.size.toLong().fa()} کارت، ${data.cheques.size.toLong().fa()} چک، ${data.loans.size.toLong().fa()} وام"
                        )
                        else pendingRestore = data
                    }
                }
            },
            onClose = { pwdFor = null }
        )
    }

    pendingRestore?.let { d ->
        AlertDialog(
            onDismissRequest = { pendingRestore = null },
            title = { Text("جایگزینی اطلاعات؟") },
            text = { Text("فایل شامل ${d.txs.size.toLong().fa()} تراکنش و ${d.cards.size.toLong().fa()} کارت است. اطلاعات فعلی کاملاً جایگزین می‌شود. قبلش یک نسخه ایمنی از اطلاعات فعلی گرفته می‌شود.") },
            confirmButton = {
                TextButton(
                    {
                        pendingRestore = null
                        scope.launch {
                            withContext(Dispatchers.IO) { runCatching { Safety.save(ctx, json()) } }
                            safetyExists = Safety.exists(ctx)
                            vm.restore(d) { ok -> onMsg(if (ok) "اطلاعات بازیابی شد" else "بازیابی ناموفق بود") }
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = cs.error)
                ) { Text("جایگزین شود") }
            },
            dismissButton = { TextButton({ pendingRestore = null }) { Text("انصراف") } }
        )
    }

    restoreSafety?.let { d ->
        AlertDialog(
            onDismissRequest = { restoreSafety = null },
            title = { Text("بازگردانی نسخه ایمنی؟") },
            text = { Text("اطلاعات فعلی با نسخه ایمنی (${d.txs.size.toLong().fa()} تراکنش، ${d.cards.size.toLong().fa()} کارت) جایگزین می‌شود.") },
            confirmButton = {
                TextButton({ restoreSafety = null; vm.restore(d) { ok -> onMsg(if (ok) "نسخه ایمنی بازگردانده شد" else "بازگردانی ناموفق بود") } }) { Text("بازگردان") }
            },
            dismissButton = { TextButton({ restoreSafety = null }) { Text("انصراف") } }
        )
    }

    if (clearLog) AlertDialog(
        onDismissRequest = { clearLog = false },
        title = { Text("پاک‌کردن رویدادها؟") },
        text = { Text("گزارش فعالیت برای همیشه پاک می‌شود. تراکنش‌ها دست نمی‌خورند.") },
        confirmButton = { TextButton({ clearLog = false; vm.clearEvents() }) { Text("پاک شود") } },
        dismissButton = { TextButton({ clearLog = false }) { Text("انصراف") } }
    )

    if (wipe) AlertDialog(
        onDismissRequest = { wipe = false },
        title = { Text("پاک‌کردن کل اطلاعات؟") },
        text = { Text("همه تراکنش‌ها، کارت‌ها و دسته‌ها برای همیشه پاک می‌شود و برگشت ندارد. اگر پشتیبان ندارید، اول پشتیبان بگیرید.") },
        confirmButton = {
            TextButton(
                { wipe = false; ctx.activity()?.let { a -> authenticate(a, "تأیید پاک‌کردن") { vm.wipe(a) } } },
                colors = ButtonDefaults.textButtonColors(contentColor = cs.error)
            ) { Text("پاک شود") }
        },
        dismissButton = { TextButton({ wipe = false }) { Text("انصراف") } }
    )
}

@Composable
fun PwDialog(title: String, confirm: Boolean, note: String, onOk: (String) -> Unit, onClose: () -> Unit) {
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    val ok = a.length >= 8 && (!confirm || a == b)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(note, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(a, { a = it }, label = { Text("رمز (حداقل ۸ نویسه)") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                if (confirm) OutlinedTextField(b, { b = it }, label = { Text("تکرار رمز") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
            }
        },
        confirmButton = { TextButton({ onOk(a) }, enabled = ok) { Text("تأیید") } },
        dismissButton = { TextButton(onClose) { Text("انصراف") } }
    )
}
