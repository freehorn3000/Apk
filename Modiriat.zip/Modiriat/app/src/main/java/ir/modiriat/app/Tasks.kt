package ir.modiriat.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.Instant
import java.time.ZoneId

val Repeats = listOf("بدون تکرار", "روزانه", "هفتگی", "ماهانه", "سالانه")
val Leads = listOf(0 to "در همان لحظه", 10 to "۱۰ دقیقه قبل", 60 to "۱ ساعت قبل", 1440 to "۱ روز قبل")

/** Next occurrence after [ts] for a repeating task (monthly and yearly follow the Jalali calendar). */
fun plusRepeat(ts: Long, rep: Int): Long {
    val z = ZoneId.systemDefault()
    val zdt = Instant.ofEpochMilli(ts).atZone(z)
    return when (rep) {
        1 -> zdt.plusDays(1).toInstant().toEpochMilli()
        2 -> zdt.plusWeeks(1).toInstant().toEpochMilli()
        3, 4 -> {
            val day = zdt.toLocalDate().atStartOfDay(z).toInstant().toEpochMilli()
            addJalaliMonths(day, if (rep == 3) 1 else 12) + zdt.toLocalTime().toSecondOfDay() * 1000L
        }
        else -> ts
    }
}

fun nextOcc(due: Long, rep: Int, from: Long): Long {
    var t = due; var n = 0
    while (t < from && n++ < 5000) t = plusRepeat(t, rep)
    return t
}

/** The occurrence that matters now: a repeating task whose time passed yesterday or earlier shows its next one. */
fun effDue(t: Task): Long = if (t.rep == 0) t.dueTs else nextOcc(t.dueTs, t.rep, todayStart())

fun fmtWhen(ts: Long): String = fmtDateY(ts) + " · " + fmtTime(ts)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TaskDialog(init: Task, onSave: (Task) -> Unit, onDelete: (() -> Unit)?, onClose: () -> Unit) {
    val t0 = Instant.ofEpochMilli(init.dueTs).atZone(ZoneId.systemDefault())
    var title by remember { mutableStateOf(init.title) }
    var note by remember { mutableStateOf(init.note) }
    var day by remember { mutableStateOf<Long?>(dayStart(init.dueTs)) }
    var hh by remember { mutableStateOf(t0.hour.toString()) }
    var mm by remember { mutableStateOf(t0.minute.toString()) }
    var rep by remember { mutableIntStateOf(init.rep) }
    var lead by remember { mutableIntStateOf(init.leadMin) }
    var show by remember { mutableStateOf(init.showTitle) }
    val h = digits(hh).toIntOrNull()
    val m = digits(mm).toIntOrNull()
    val ok = title.isNotBlank() && day != null && h != null && h in 0..23 && m != null && m in 0..59
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (init.id == 0L) "یادآوری جدید" else "ویرایش یادآوری") },
        confirmButton = {
            TextButton(
                {
                    onSave(
                        init.copy(
                            title = title.trim().take(80), note = note.trim(), dueTs = day!! + h!! * 3_600_000L + m!! * 60_000L,
                            rep = rep, leadMin = lead, showTitle = show, done = false, doneTs = 0
                        )
                    )
                },
                enabled = ok
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it.take(80) }, Modifier.fillMaxWidth(), label = { Text("چه کاری؟") }, singleLine = true)
                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("یادداشت (اختیاری)") })
                Text("تاریخ", fontWeight = FontWeight.SemiBold)
                DateFields(init.dueTs) { day = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(hh, { hh = digits(it).take(2) }, Modifier.weight(1f), label = { Text("ساعت (۰ تا ۲۳)") }, singleLine = true, keyboardOptions = num)
                    OutlinedTextField(mm, { mm = digits(it).take(2) }, Modifier.weight(1f), label = { Text("دقیقه") }, singleLine = true, keyboardOptions = num)
                }
                Text("تکرار", fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Repeats.forEachIndexed { i, r -> FilterChip(rep == i, { rep = i }, { Text(r) }) } }
                Text("یادآوری اضافه", fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Leads.forEach { l -> FilterChip(lead == l.first, { lead = l.first }, { Text(l.second) }) } }
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(end = 8.dp)) {
                        Text("نمایش عنوان در اعلان")
                        Text("عنوان کوتاه بیرون از دیتابیس رمزنگاری‌شده هم نگه داشته می‌شود. اگر خاموش باشد، اعلان فقط «یک یادآوری دارید» می‌گوید.", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(show, { show = it })
                }
                if (onDelete != null) TextButton(onDelete, colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("حذف این یادآوری") }
            }
        }
    )
}

class AgendaItem(val ts: Long, val title: String, val sub: String, val kind: Int, val task: Task?, val tab: Int)

@Composable
private fun AgendaRow(a: AgendaItem, bad: Boolean, onClick: () -> Unit, onCheck: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.surfaceContainerLow).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (a.kind == 0) Box(Modifier.size(44.dp).clickable(onClick = onCheck), Alignment.Center) {
            Box(Modifier.size(26.dp).clip(CircleShape).border(2.dp, if (bad) cs.error else cs.primary, CircleShape))
        }
        else Box(Modifier.size(44.dp), Alignment.Center) { Text(listOf("", "🧾", "🏦", "🤝")[a.kind], fontSize = 22.sp) }
        Column(Modifier.weight(1f).padding(end = 8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(a.title, fontWeight = FontWeight.SemiBold, maxLines = 2)
            Text(a.sub, style = MaterialTheme.typography.bodySmall, color = if (bad) cs.error else cs.onSurfaceVariant, maxLines = 2)
        }
    }
}

@Composable
fun TasksScreen(pad: PaddingValues, vm: VM, onMsg: (String) -> Unit, onOpenTab: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val tasks by vm.tasks.collectAsState()
    val cheques by vm.cheques.collectAsState()
    val installments by vm.installments.collectAsState()
    val loans by vm.loans.collectAsState()
    val debts by vm.debts.collectAsState()
    val persons by vm.persons.collectAsState()
    var showDone by remember { mutableStateOf(false) }
    var showFin by remember { mutableStateOf(ctx.getSharedPreferences("set", Context.MODE_PRIVATE).getBoolean("showFin", false)) }
    var edit by remember { mutableStateOf<Task?>(null) }
    var confirmDel by remember { mutableStateOf<Task?>(null) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val today = todayStart()
    val tomorrow = today + 86_400_000L
    val lender = loans.associate { it.id to it.lender }
    val pn = persons.associate { it.id to it.name }
    val loanPeople = loans.map { it.personId }.toSet()
    val nets = debts.groupBy { it.personId }.mapValues { e -> netOf(e.value) }
    val items = buildList<AgendaItem> {
        tasks.filter { !it.done }.forEach { t ->
            val d = effDue(t)
            add(AgendaItem(d, t.title, fmtWhen(d) + (if (t.rep != 0) " · " + Repeats[t.rep] else "") + (if (t.note.isNotBlank()) " · " + t.note else ""), 0, t, 0))
        }
        if (showFin) {
        cheques.filter { it.status == 0 }.forEach { add(AgendaItem(it.dueTs, "چک ${it.party}", "${fmtDateY(it.dueTs)} · ${it.amount.fa()} تومان", 1, null, 3)) }
        installments.filter { !it.paid }.forEach { add(AgendaItem(it.dueTs, "قسط ${it.num.toLong().fa()} وام ${lender[it.loanId] ?: ""}", "${fmtDateY(it.dueTs)} · ${it.amount.fa()} تومان", 2, null, 4)) }
        debts.filter { it.dueTs > 0 && (it.kind == 0 || it.kind == 1) && (nets[it.personId] ?: 0L) != 0L && it.personId !in loanPeople }
            .forEach { add(AgendaItem(it.dueTs, "سررسید ${DebtKinds[it.kind]} · ${pn[it.personId] ?: ""}", "${fmtDateY(it.dueTs)} · ${it.amount.fa()} تومان", 3, null, 4)) }
        }
    }
    val overdue = items.filter { it.ts < today }.sortedBy { it.ts }
    val todayL = items.filter { it.ts in today until tomorrow }.sortedBy { it.ts }
    val upcoming = items.filter { it.ts >= tomorrow }.sortedBy { it.ts }.take(60)
    val done = tasks.filter { it.done }.sortedByDescending { it.doneTs }
    fun newTask() = Task(title = "", note = "", dueTs = ((System.currentTimeMillis() / 3_600_000L) + 1) * 3_600_000L, rep = 0, leadMin = 0, done = false, doneTs = 0, showTitle = false)

    @Composable
    fun section(title: String, list: List<AgendaItem>, bad: Boolean) {
        if (list.isEmpty()) return
        Text(title, color = if (bad) cs.error else cs.primary, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        list.forEach { a ->
            AgendaRow(a, bad, { if (a.task != null) edit = a.task else onOpenTab(a.tab) }, { a.task?.let { vm.completeTask(it); onMsg("انجام شد ✓") } })
            Spacer(Modifier.height(8.dp))
        }
    }

    LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 150.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("یادآوری‌ها", fontFamily = Fonts.head, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Button({ edit = newTask() }) { Text("＋ یادآوری") }
            }
        }
        item {
            Column {
                if (items.isEmpty()) Text("یادآوری یا سررسیدی نیست. با «＋ یادآوری» یا ثبت صوتی («یادآوری کن فردا ساعت ۱۰ به علی زنگ بزنم») اضافه کنید.", color = cs.onSurfaceVariant)
                section("معوق", overdue, true)
                section("امروز", todayL, false)
                section("پیش‌رو", upcoming, false)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("نمایش سررسید چک، قسط و بدهی", color = cs.onSurfaceVariant)
                Switch(showFin, { showFin = it; ctx.getSharedPreferences("set", Context.MODE_PRIVATE).edit().putBoolean("showFin", it).apply() })
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("انجام‌شده‌ها (${done.size.toLong().fa()})", color = cs.onSurfaceVariant)
                Switch(showDone, { showDone = it })
            }
        }
        if (showDone) item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                done.forEach { t ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.surfaceContainerLow).clickable { vm.updTask(t.copy(done = false, doneTs = 0)); onMsg("به فهرست برگشت") }.padding(14.dp),
                        Arrangement.SpaceBetween, Alignment.CenterVertically
                    ) {
                        Text(t.title, textDecoration = TextDecoration.LineThrough, color = cs.onSurfaceVariant, modifier = Modifier.weight(1f))
                        Text("لمس برای بازگرداندن", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }

    edit?.let { t ->
        TaskDialog(t, { saved -> if (saved.id == 0L) vm.addTask(saved) else vm.updTask(saved); askNotif(); edit = null }, if (t.id != 0L) ({ confirmDel = t; edit = null }) else null) { edit = null }
    }
    confirmDel?.let { t ->
        AlertDialog(
            onDismissRequest = { confirmDel = null },
            title = { Text("حذف یادآوری؟") },
            text = { Text("«${t.title}» برای همیشه حذف می‌شود.") },
            confirmButton = { TextButton({ vm.delTask(t); confirmDel = null }, colors = ButtonDefaults.textButtonColors(contentColor = cs.error)) { Text("حذف") } },
            dismissButton = { TextButton({ confirmDel = null }) { Text("انصراف") } }
        )
    }
}
