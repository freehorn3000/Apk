package ir.modiriat.app

import android.content.Context
import java.security.MessageDigest

/** cat = index inside the seeded list of its type (expense: 0..6, income: 0..2). note = spoken text without the amount. */
data class Parsed(val amount: Long?, val income: Boolean, val cat: Int, val note: String)

private val W = mapOf(
    "صفر" to 0.0, "یک" to 1.0, "دو" to 2.0, "سه" to 3.0, "چهار" to 4.0, "پنج" to 5.0, "شش" to 6.0, "شیش" to 6.0,
    "هفت" to 7.0, "هشت" to 8.0, "نه" to 9.0, "ده" to 10.0, "یازده" to 11.0, "دوازده" to 12.0, "سیزده" to 13.0,
    "چهارده" to 14.0, "پانزده" to 15.0, "پونزده" to 15.0, "شانزده" to 16.0, "شونزده" to 16.0, "هفده" to 17.0,
    "هجده" to 18.0, "نوزده" to 19.0, "بیست" to 20.0, "سی" to 30.0, "چهل" to 40.0, "پنجاه" to 50.0, "شصت" to 60.0,
    "هفتاد" to 70.0, "هشتاد" to 80.0, "نود" to 90.0, "صد" to 100.0, "یکصد" to 100.0, "دویست" to 200.0,
    "سیصد" to 300.0, "چهارصد" to 400.0, "پانصد" to 500.0, "پونصد" to 500.0, "ششصد" to 600.0,
    "هفتصد" to 700.0, "هشتصد" to 800.0, "نهصد" to 900.0
)
private val M = mapOf("هزار" to 1e3, "میلیون" to 1e6, "ملیون" to 1e6, "میلیارد" to 1e9)
private val UNIT_WORDS = setOf("تومان", "تومن", "تومانی", "ریال")
private val EDGE_WORDS = setOf("و", "با", "از", "به", "روی")

private val EXP_WORDS = listOf("خرج", "خریدم", "پرداخت", "دادم", "هزینه")
private val INC_WORDS = listOf("درآمد", "حقوق", "دریافت", "واریز", "فروختم", "فروش", "پاداش", "عیدی", "سود", "دستمزد")
private val EXP_CATS = listOf(
    0 to listOf("ناهار", "شام", "صبحانه", "غذا", "نان", "نون", "میوه", "رستوران", "کافه", "قهوه", "چای", "سوپر", "پیتزا", "ساندویچ", "خوراک", "شیرینی", "بستنی"),
    1 to listOf("تاکسی", "اسنپ", "تپسی", "بنزین", "مترو", "اتوبوس", "کرایه", "پارکینگ", "ماشین", "عوارض"),
    2 to listOf("اجاره", "قبض", "برق", "گاز", "اینترنت", "شارژ", "موبایل", "تلفن", "رهن"),
    3 to listOf("خرید", "لباس", "کفش", "کتاب", "دیجی", "هدیه", "کیف", "پوشاک"),
    4 to listOf("دکتر", "دارو", "درمان", "دندان", "بیمارستان", "ویزیت", "آزمایش"),
    5 to listOf("سینما", "فیلم", "بازی", "سفر", "کنسرت", "تفریح", "پارک")
)
private val INC_CATS = listOf(0 to listOf("حقوق", "دستمزد"), 1 to listOf("کار آزاد", "پروژه", "فریلنس", "فروش", "فروختم"))

private val GROUP = Regex("^\\d{1,3}([,/.]\\d{3})+$")   // 2/500/000  2,500,000  2.500.000
private val DEC = Regex("^\\d+[/.]\\d{1,2}$")             // 2/5  2.5
private val PLAIN = Regex("^\\d+(\\.\\d+)?$")
private val SEP = Regex("[,/.]")

private fun norm(s: String): String {
    val sb = StringBuilder()
    for (ch in s) {
        val d = Character.digit(ch, 10)
        sb.append(
            when {
                ch == 'ي' -> 'ی'
                ch == 'ك' -> 'ک'
                ch == '\u200c' -> ' '
                ch == '٬' || ch == '،' -> ','
                ch == '٫' -> '/'
                d >= 0 -> '0' + d
                else -> ch
            }
        )
    }
    return sb.toString().lowercase()
}

private fun num(t: String): Double? {
    if (GROUP.matches(t)) return t.replace(SEP, "").toDouble()
    if (DEC.matches(t)) return t.replace('/', '.').toDouble()
    val p = t.replace(",", "")
    return if (PLAIN.matches(p)) p.toDouble() else W[t]
}

fun parseVoice(raw: String): Parsed {
    val text = norm(raw)
    val toks = text.split(Regex("\\s+")).map { it.trim('.', ',', '؟', '?', '!', '«', '»', '"') }.filter { it.isNotEmpty() }
    var best = 0.0; var bestIdx = emptySet<Int>()
    var total = 0.0; var cur = 0.0; var open = false; var lastM = 0.0
    var gi = mutableListOf<Int>()
    fun close() {
        if (open) {
            // "دو میلیون و پانصد" = 2,500,000 (the word «هزار» is dropped in speech)
            val rest = if (lastM >= 1e6 && cur >= 1 && cur < 1000) cur * lastM / 1000 else cur
            val v = total + rest
            if (v > best) { best = v; bestIdx = gi.toSet() }
        }
        total = 0.0; cur = 0.0; open = false; lastM = 0.0; gi = mutableListOf()
    }
    for ((i, t) in toks.withIndex()) {
        val n = num(t); val m = M[t]
        when {
            n != null -> { cur += n; open = true; gi.add(i) }
            m != null -> { total += (if (open && cur > 0) cur else 1.0) * m; cur = 0.0; open = true; lastM = m; gi.add(i) }
            t == "نیم" && open -> { cur += if (cur == 0.0 && lastM > 0) 0.5 * lastM else 0.5; gi.add(i) }
            t == "و" && open -> gi.add(i)
            else -> close()
        }
    }
    close()
    if (text.contains("ریال")) best /= 10
    val income = EXP_WORDS.none { text.contains(it) } && INC_WORDS.any { text.contains(it) }
    val cat = if (income) INC_CATS.firstOrNull { (_, k) -> k.any { text.contains(it) } }?.first ?: 2
    else EXP_CATS.firstOrNull { (_, k) -> k.any { text.contains(it) } }?.first ?: 6
    val note = trimEdges(toks.filterIndexed { i, t -> i !in bestIdx && t !in UNIT_WORDS })
    return Parsed(if (best >= 1) best.toLong() else null, income, cat, note.joinToString(" "))
}

private fun trimEdges(l: List<String>): List<String> {
    var a = 0; var b = l.size
    while (a < b && l[a] in EDGE_WORDS) a++
    while (b > a && l[b - 1] in EDGE_WORDS) b--
    return l.subList(a, b)
}

/** Removes card words ("با کارت ملی") from the note. */
fun cleanNote(note: String, words: List<String>): String {
    var s = note
    words.filter { it.isNotBlank() }.forEach { s = s.replace(it, " ") }
    listOf("با کارت", "از کارت", "از حساب", "با حساب", "کارت").forEach { s = s.replace(it, " ") }
    return trimEdges(s.split(Regex("\\s+")).filter { it.isNotEmpty() }).joinToString(" ")
}

fun pickCat(cats: List<Category>, p: Parsed): Category? {
    val pool = cats.filter { it.income == p.income }
    return pool.getOrNull(p.cat) ?: pool.lastOrNull()
}

private fun hit(text: String, toks: List<String>, w: String): Boolean =
    w.isNotBlank() && (if (w.contains(' ')) text.contains(w) else w in toks)

/** Card named in speech: nickname first, then bank name. */
fun cardFromText(cards: List<BankCard>, text: String): BankCard? {
    val toks = text.split(Regex("\\s+")).map { it.trim('.', ',', '،', '؟', '!', '«', '»') }
    return cards.firstOrNull { hit(text, toks, it.name) } ?: cards.firstOrNull { hit(text, toks, it.bank) }
}

fun isCash(text: String): Boolean = listOf("نقد", "نقدی", "کیف پول").any { text.contains(it) }

/** Local learning: words you use in manual notes -> the category you chose. Only hashes are stored. */
object Learn {
    private fun sp(c: Context) = c.getSharedPreferences("learn", Context.MODE_PRIVATE)
    private fun h(w: String) = MessageDigest.getInstance("SHA-256").digest(w.toByteArray()).joinToString("") { "%02x".format(it) }.take(24)
    private fun words(s: String) = s.lowercase().split(Regex("\\s+")).map { it.trim('.', ',', '،', '؟', '!') }
        .filter { it.length >= 3 && it.any { ch -> !ch.isDigit() } }

    fun put(c: Context, note: String, catId: Long) { val e = sp(c).edit(); words(note).forEach { e.putLong(h(it), catId) }; e.apply() }

    fun find(c: Context, text: String): Long? {
        val p = sp(c)
        return words(text).firstNotNullOfOrNull { w -> if (p.contains(h(w))) p.getLong(h(w), 0) else null }
    }
}
