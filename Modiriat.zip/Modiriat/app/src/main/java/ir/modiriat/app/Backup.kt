package ir.modiriat.app

import org.json.JSONArray
import org.json.JSONObject
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Encrypted backup: "HSB1" + salt(16) + iv(12) + AES-256-GCM(JSON). Key = PBKDF2-SHA256(password, 310k rounds). */
object Backup {
    class Data(
        val cats: List<Category>, val txs: List<Tx>, val cards: List<BankCard>, val trs: List<Transfer>,
        val cheques: List<Cheque> = emptyList(), val persons: List<Person> = emptyList(), val debts: List<DebtEntry> = emptyList(),
        val loans: List<Loan> = emptyList(), val installments: List<Installment> = emptyList()
    )

    private const val MAGIC = "HSB1"

    private fun key(pw: String, salt: ByteArray) = SecretKeySpec(
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(pw.toCharArray(), salt, 310_000, 256)).encoded, "AES"
    )

    private fun rnd(n: Int) = ByteArray(n).also { SecureRandom().nextBytes(it) }

    fun toJson(
        cats: List<Category>, txs: List<Tx>, cards: List<BankCard>, trs: List<Transfer>,
        cheques: List<Cheque> = emptyList(), persons: List<Person> = emptyList(), debts: List<DebtEntry> = emptyList(),
        loans: List<Loan> = emptyList(), installments: List<Installment> = emptyList()
    ): ByteArray {
        val o = JSONObject().put("v", 3)
        o.put("cats", JSONArray().apply { cats.forEach { put(JSONObject().put("id", it.id).put("name", it.name).put("emoji", it.emoji).put("color", it.color).put("income", it.income)) } })
        o.put("txs", JSONArray().apply { txs.forEach { put(JSONObject().put("id", it.id).put("amount", it.amount).put("income", it.income).put("catId", it.catId).put("note", it.note).put("ts", it.ts).put("cardId", it.cardId)) } })
        o.put("cards", JSONArray().apply { cards.forEach { put(JSONObject().put("id", it.id).put("bank", it.bank).put("number", it.number).put("name", it.name).put("initial", it.initial)) } })
        o.put("trs", JSONArray().apply { trs.forEach { put(JSONObject().put("id", it.id).put("fromId", it.fromId).put("toId", it.toId).put("amount", it.amount).put("note", it.note).put("ts", it.ts)) } })
        o.put("cheques", JSONArray().apply {
            cheques.forEach {
                put(JSONObject().put("id", it.id).put("incoming", it.incoming).put("amount", it.amount).put("dueTs", it.dueTs).put("party", it.party).put("sayad", it.sayad)
                    .put("number", it.number).put("cardId", it.cardId).put("status", it.status).put("note", it.note).put("remind", it.remind)
                    .put("txId", it.txId).put("tx2Id", it.tx2Id).put("doneTs", it.doneTs))
            }
        })
        o.put("persons", JSONArray().apply { persons.forEach { put(JSONObject().put("id", it.id).put("name", it.name).put("note", it.note)) } })
        o.put("debts", JSONArray().apply {
            debts.forEach {
                put(JSONObject().put("id", it.id).put("personId", it.personId).put("kind", it.kind).put("amount", it.amount).put("ts", it.ts)
                    .put("note", it.note).put("cardId", it.cardId).put("dueTs", it.dueTs))
            }
        })
        o.put("loans", JSONArray().apply {
            loans.forEach {
                put(JSONObject().put("id", it.id).put("personId", it.personId).put("lender", it.lender).put("principal", it.principal).put("fees", it.fees)
                    .put("receivedTs", it.receivedTs).put("cnt", it.cnt).put("cardId", it.cardId).put("note", it.note).put("remind", it.remind)
                    .put("disbDebtId", it.disbDebtId).put("feeTxId", it.feeTxId))
            }
        })
        o.put("installments", JSONArray().apply {
            installments.forEach {
                put(JSONObject().put("id", it.id).put("loanId", it.loanId).put("num", it.num).put("dueTs", it.dueTs).put("amount", it.amount).put("interest", it.interest)
                    .put("paid", it.paid).put("paidTs", it.paidTs).put("paidAmount", it.paidAmount).put("debtId", it.debtId).put("txId", it.txId))
            }
        })
        return o.toString().toByteArray(Charsets.UTF_8)
    }

    fun parse(b: ByteArray): Data {
        val o = JSONObject(String(b, Charsets.UTF_8))
        require(o.getInt("v") in 1..3)
        fun arr(k: String): List<JSONObject> = o.optJSONArray(k)?.let { a -> (0 until a.length()).map { a.getJSONObject(it) } } ?: emptyList()
        return Data(
            arr("cats").map { Category(it.getLong("id"), it.getString("name"), it.getString("emoji"), it.getLong("color"), it.getBoolean("income")) },
            arr("txs").map { Tx(it.getLong("id"), it.getLong("amount"), it.getBoolean("income"), it.getLong("catId"), it.getString("note"), it.getLong("ts"), it.getLong("cardId")) },
            arr("cards").map { BankCard(it.getLong("id"), it.getString("bank"), it.getString("number"), it.getString("name"), it.getLong("initial")) },
            arr("trs").map { Transfer(it.getLong("id"), it.getLong("fromId"), it.getLong("toId"), it.getLong("amount"), it.getString("note"), it.getLong("ts")) },
            arr("cheques").map {
                Cheque(it.getLong("id"), it.getBoolean("incoming"), it.getLong("amount"), it.getLong("dueTs"), it.getString("party"), it.getString("sayad"), it.getString("number"),
                    it.getLong("cardId"), it.getInt("status"), it.getString("note"), it.getBoolean("remind"), it.getLong("txId"), it.getLong("tx2Id"), it.getLong("doneTs"))
            },
            arr("persons").map { Person(it.getLong("id"), it.getString("name"), it.getString("note")) },
            arr("debts").map { DebtEntry(it.getLong("id"), it.getLong("personId"), it.getInt("kind"), it.getLong("amount"), it.getLong("ts"), it.getString("note"), it.getLong("cardId"), it.getLong("dueTs")) },
            arr("loans").map {
                Loan(it.getLong("id"), it.getLong("personId"), it.getString("lender"), it.getLong("principal"), it.getLong("fees"), it.getLong("receivedTs"), it.getInt("cnt"),
                    it.getLong("cardId"), it.getString("note"), it.getBoolean("remind"), it.getLong("disbDebtId"), it.getLong("feeTxId"))
            },
            arr("installments").map {
                Installment(it.getLong("id"), it.getLong("loanId"), it.getInt("num"), it.getLong("dueTs"), it.getLong("amount"), it.getLong("interest"),
                    it.getBoolean("paid"), it.getLong("paidTs"), it.getLong("paidAmount"), it.getLong("debtId"), it.getLong("txId"))
            }
        )
    }

    fun encrypt(pw: String, plain: ByteArray): ByteArray {
        val salt = rnd(16); val iv = rnd(12)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(pw, salt), GCMParameterSpec(128, iv))
        return MAGIC.toByteArray() + salt + iv + c.doFinal(plain)
    }

    /** Throws if the password is wrong or the file was modified (GCM authentication). */
    fun decrypt(pw: String, blob: ByteArray): ByteArray {
        require(blob.size > 48 && String(blob, 0, 4) == MAGIC)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(pw, blob.copyOfRange(4, 20)), GCMParameterSpec(128, blob.copyOfRange(20, 32)))
        return c.doFinal(blob, 32, blob.size - 32)
    }
}
