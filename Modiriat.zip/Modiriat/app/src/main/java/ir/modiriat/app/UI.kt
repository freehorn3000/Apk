package ir.modiriat.app

import android.Manifest
import android.content.Context
import android.os.Build
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.coerceAtLeast
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/** Appearance settings (palette + light/dark), kept in SharedPreferences "set". */
object Pref {
    var palette by mutableIntStateOf(0)
    var mode by mutableIntStateOf(0) // 0 system, 1 light, 2 dark
    fun load(c: Context) {
        val s = c.getSharedPreferences("set", Context.MODE_PRIVATE)
        palette = s.getInt("pal2", 0); mode = s.getInt("mode", 0)
    }
    fun save(c: Context) { c.getSharedPreferences("set", Context.MODE_PRIVATE).edit().putInt("pal2", palette).putInt("mode", mode).apply() }
}

val PaletteNames = listOf("لاجورد", "ارغوانی", "سبز")

private class Pal(
    val p: Long, val deep: Long, val cont: Long, val hero: Long, val accent: Long, val darkP: Long,
    val bg: Long, val dbg: Long, val dcard: Long, val ink: Long, val muted: Long, val outline: Long
)
private val Pals = listOf(
    Pal(0xFF2B4BC8, 0xFF18286F, 0xFFE6EBFA, 0xFF2F54D6, 0xFFE0A93B, 0xFF8EA2FF, 0xFFF1F3FA, 0xFF0E1226, 0xFF181D3D, 0xFF161B33, 0xFF4D5578, 0xFFD5DAEA),
    Pal(0xFF7B3FA0, 0xFF4A1F66, 0xFFEEE0F6, 0xFF8E4BB5, 0xFFF2A93B, 0xFFC9A0F0, 0xFFF6F2F8, 0xFF140F1C, 0xFF1F1829, 0xFF1E1626, 0xFF5C4E68, 0xFFE0D6E8),
    Pal(0xFF147748, 0xFF0D4D2E, 0xFFD6EFE0, 0xFF16824E, 0xFFE0A93B, 0xFF4FD1A0, 0xFFEAECEB, 0xFF0D1514, 0xFF16211F, 0xFF14231D, 0xFF4A5A54, 0xFFD2D8D5)
)

@Composable
fun Theme(content: @Composable () -> Unit) {
    val dark = when (Pref.mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val pal = Pals[Pref.palette.coerceIn(0, 2)]
    val cs = if (dark) darkColorScheme(
        primary = Color(pal.darkP), onPrimary = Color(0xFF0B1030), primaryContainer = Color(pal.deep), onPrimaryContainer = Color.White,
        background = Color(pal.dbg), surface = Color(pal.dbg), onSurface = Color(0xFFE8EBFA), onSurfaceVariant = Color(0xFFA8B0D4),
        error = Color(0xFFFF8A80), surfaceContainerLow = Color(pal.dcard), surfaceContainerHighest = Color(0xFF2A3060), outlineVariant = Color(0xFF2E3560)
    ) else lightColorScheme(
        primary = Color(pal.p), onPrimary = Color.White, primaryContainer = Color(pal.cont), onPrimaryContainer = Color(pal.deep),
        background = Color(pal.bg), surface = Color(pal.bg), onSurface = Color(pal.ink), onSurfaceVariant = Color(pal.muted),
        error = Color(0xFFB63A33), surfaceContainerLow = Color.White, surfaceContainerHighest = Color(0xFFDDE2EE), outlineVariant = Color(pal.outline)
    )
    // default text colour for the whole app (fixes black text on dark cards)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl, LocalContentColor provides cs.onSurface) {
        MaterialTheme(colorScheme = cs, typography = appTypography()) {
            ProvideTextStyle(MaterialTheme.typography.bodyLarge) { content() }
        }
    }
}

private fun appTypography(): Typography {
    val b = Typography()
    val f = Fonts.body ?: return b
    fun TextStyle.t() = copy(fontFamily = f)
    return Typography(
        displayLarge = b.displayLarge.t(), displayMedium = b.displayMedium.t(), displaySmall = b.displaySmall.t(),
        headlineLarge = b.headlineLarge.t(), headlineMedium = b.headlineMedium.t(), headlineSmall = b.headlineSmall.t(),
        titleLarge = b.titleLarge.t(), titleMedium = b.titleMedium.t(), titleSmall = b.titleSmall.t(),
        bodyLarge = b.bodyLarge.t(), bodyMedium = b.bodyMedium.t(), bodySmall = b.bodySmall.t(),
        labelLarge = b.labelLarge.t(), labelMedium = b.labelMedium.t(), labelSmall = b.labelSmall.t()
    )
}

/** Header gradient colours of the selected palette (used by the exported statements too). */
fun heroColors(): Pair<Int, Int> { val p = Pals[Pref.palette.coerceIn(0, 2)]; return p.hero.toInt() to p.deep.toInt() }

private fun heroBrush(): Brush {
    val p = Pals[Pref.palette.coerceIn(0, 2)]
    return Brush.linearGradient(listOf(Color(p.hero), Color(p.deep)))
}

@Composable fun incomeColor(): Color = if (MaterialTheme.colorScheme.background.luminance() < .5f) Color(0xFF5FE0C8) else Color(0xFF0B7F72)
@Composable fun warnColor(): Color = if (MaterialTheme.colorScheme.background.luminance() < .5f) Color(0xFFFFD79A) else Color(0xFF8A5A00)
@Composable fun accentColor(): Color = Color(Pals[Pref.palette.coerceIn(0, 2)].accent)

@Composable
fun LockScreen(onTry: () -> Unit) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("🔒", fontSize = 56.sp)
            Text("حسابداری شخصی", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, fontFamily = Fonts.head)
            FilledTonalButton(onTry) { Text("باز کردن قفل") }
        }
    }
}

sealed class Entry(val ts: Long, val key: String) {
    class T(val t: Tx) : Entry(t.ts, "t${t.id}")
    class X(val x: Transfer) : Entry(x.ts, "x${x.id}")
}

fun short(n: Long): String = when {
    n >= 1_000_000 -> faDigits(String.format(Locale.US, "%.1f", n / 1e6).removeSuffix(".0")) + " میلیون"
    n >= 1_000 -> faDigits((n / 1000).toString()) + " هزار"
    else -> n.fa()
}

private fun Modifier.hatched(c: Color) = drawBehind {
    val step = 9.dp.toPx(); val w = 2.dp.toPx()
    var x = -size.height
    while (x < size.width) { drawLine(c, Offset(x, size.height), Offset(x + size.height, 0f), w); x += step }
}

@Composable
fun App(vm: VM = viewModel()) {
    val txs by vm.txs.collectAsState()
    val cats by vm.cats.collectAsState()
    val cards by vm.cards.collectAsState()
    val trs by vm.trs.collectAsState()
    val cheques by vm.cheques.collectAsState()
    val persons by vm.persons.collectAsState()
    val debts by vm.debts.collectAsState()
    val loans by vm.loans.collectAsState()
    val installments by vm.installments.collectAsState()
    val tasks by vm.tasks.collectAsState()
    val byId = cats.associateBy { it.id }
    val names = remember(cards) { mapOf(0L to "نقدی") + cards.associate { it.id to it.name.ifBlank { it.bank } } }
    val bal = remember(cards, txs, trs, debts) { balances(cards, txs, trs, debts) }
    val now = jalali(System.currentTimeMillis())
    val tomorrowStart = todayStart() + 86_400_000L
    val badge = tasks.count { !it.done && effDue(it) < tomorrowStart } + cheques.count { it.status == 0 && it.dueTs < tomorrowStart } +
        installments.count { !it.paid && it.dueTs < tomorrowStart }
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) } // 0 home, 1 cards, 2 settings
    var filter by remember { mutableStateOf<Long?>(null) }
    var lastCard by remember { mutableLongStateOf(-1L) }
    var py by remember { mutableIntStateOf(now.first) }
    var pm by remember { mutableIntStateOf(now.second) }
    var yearly by remember { mutableStateOf(false) }
    var chartIncome by remember { mutableStateOf(false) }
    val withJ = remember(txs) { txs.map { it to jalali(it.ts) } }
    fun cardOk(t: Tx) = filter == null || t.cardId == filter
    fun inPeriod(j: Triple<Int, Int, Int>) = j.first == py && (yearly || j.second == pm)
    fun monthSum(y: Int, m: Int, income: Boolean) =
        withJ.filter { (t, j) -> j.first == y && j.second == m && t.income == income && cardOk(t) }.sumOf { it.first.amount }
    val period = withJ.filter { (t, j) -> inPeriod(j) && cardOk(t) }.map { it.first }
    val trPeriod = trs.filter { inPeriod(jalali(it.ts)) && (filter == null || it.fromId == filter || it.toId == filter) }
    val entries = buildList<Entry> {
        period.forEach { add(Entry.T(it)) }
        trPeriod.forEach { add(Entry.X(it)) }
    }.sortedByDescending { it.ts }
    val inc = period.filter { it.income }.sumOf { it.amount }
    val exp = period.filter { !it.income }.sumOf { it.amount }
    val shownBal = filter?.let { bal[it] ?: 0L } ?: bal.values.sum()
    val ym = if (yearly) (1..12).map { py to it } else (5 downTo 0).map { k -> val idx = py * 12 + (pm - 1) - k; (idx / 12) to (idx % 12 + 1) }
    val barVals = ym.map { (y, m) -> monthSum(y, m, chartIncome) }
    val barLabels = ym.map { (_, m) -> if (yearly) m.toLong().fa() else Months[m - 1] }
    val prevIdx = py * 12 + (pm - 1) - 1
    val prevExp = monthSum(prevIdx / 12, prevIdx % 12 + 1, false)
    val delta = if (!yearly && prevExp > 0) {
        val pct = ((exp - prevExp) * 100.0 / prevExp).roundToInt()
        "${if (pct >= 0) "▲" else "▼"} هزینه ${faDigits(abs(pct).toString())}٪ ${if (pct >= 0) "بیشتر" else "کمتر"} از ماه قبل"
    } else null
    fun step(d: Int) {
        if (yearly) py += d else {
            var nm = pm + d
            if (nm < 1) { nm = 12; py-- } else if (nm > 12) { nm = 1; py++ }
            pm = nm
        }
    }

    var sheet by remember { mutableStateOf(false) }
    var catDlg by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Tx?>(null) }
    var pendingDebt by remember { mutableStateOf<DebtEntry?>(null) }
    var pendingTask by remember { mutableStateOf<Task?>(null) }
    var draft by remember { mutableStateOf<Task?>(null) }
    val notifL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notifL.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        status = if (ok) "حالا دکمه را نگه دارید و صحبت کنید" else "برای ثبت صوتی، اجازه میکروفون لازم است"
    }
    fun commit(t: Tx) {
        vm.add(t) { saved ->
            lastCard = saved.cardId
            scope.launch {
                val cardPart = if (cards.isEmpty()) "" else " · ${names[saved.cardId] ?: "نقدی"}"
                val r = snack.showSnackbar(
                    "${if (saved.income) "درآمد" else "هزینه"} ${saved.amount.fa()} تومان · ${byId[saved.catId]?.name ?: ""}$cardPart ثبت شد",
                    "واگرد", duration = SnackbarDuration.Short
                )
                if (r == SnackbarResult.ActionPerformed) vm.del(saved)
            }
        }
    }
    fun commitDebt(e: DebtEntry) {
        vm.addDebt(e) { saved ->
            scope.launch {
                val r = snack.showSnackbar("${DebtKinds[saved.kind]} · ${saved.amount.fa()} تومان ثبت شد", "واگرد", duration = SnackbarDuration.Short)
                if (r == SnackbarResult.ActionPerformed) vm.delDebt(saved)
            }
        }
    }
    fun handleDebt(text: String, kind: Int) {
        val per = personFromText(persons.filter { p -> loans.none { it.personId == p.id } }, text)
        val amt = parseVoice(text).amount
        val card = cardFromText(cards, text)
        val cid = when { card != null -> card.id; isCash(text) -> 0L; else -> -1L }
        if (per == null) status = "شخص را نشناختم. اول او را در بخش «بدهی» اضافه کنید"
        else if (amt == null) status = "مبلغ را متوجه نشدم: «$text»"
        else {
            val e = DebtEntry(personId = per.id, kind = kind, amount = amt, ts = System.currentTimeMillis(), note = "", cardId = cid, dueTs = 0)
            if (ctx.getSharedPreferences("set", Context.MODE_PRIVATE).getBoolean("voiceConfirm", false)) pendingDebt = e else commitDebt(e)
        }
    }
    val handle = rememberUpdatedState { text: String ->
        if (isTaskPhrase(text)) {
            val tv = parseTaskVoice(text, System.currentTimeMillis(), ctx.getSharedPreferences("set", Context.MODE_PRIVATE).getInt("remHour", 9))
            if (tv != null) pendingTask = tv else status = "یادآوری را متوجه نشدم"
        } else {
        val dk = debtKind(text)
        if (dk != null) handleDebt(text, dk) else {
        val p0 = parseVoice(text)
        val learned = Learn.find(ctx, text)?.let { id -> cats.firstOrNull { it.id == id } }
        val named = cats.firstOrNull { it.id > 10 && text.contains(it.name) } ?: learned
        val p = if (named != null) p0.copy(income = named.income) else p0
        val c = named ?: pickCat(cats, p)
        val card = cardFromText(cards, text)
        val cid = when {
            card != null -> card.id
            isCash(text) -> 0L
            lastCard >= 0 -> lastCard
            else -> cards.firstOrNull()?.id ?: 0L
        }
        val amt = p.amount
        if (amt == null) status = "مبلغ را متوجه نشدم: «$text»"
        else if (c == null) status = "دسته‌ای پیدا نشد"
        else {
            val t0 = jalali(System.currentTimeMillis()); py = t0.first; pm = t0.second; yearly = false
            val note = cleanNote(p.note, listOfNotNull(card?.name, card?.bank))
            val tx = Tx(amount = amt, income = p.income, catId = c.id, note = note, ts = System.currentTimeMillis(), cardId = cid)
            if (ctx.getSharedPreferences("set", Context.MODE_PRIVATE).getBoolean("voiceConfirm", false)) pending = tx else commit(tx)
        }
        }
        }
    }
    val voice = remember { Voice(ctx, { handle.value(it) }, { status = it }) }
    DisposableEffect(Unit) { onDispose { voice.destroy() } }
    LaunchedEffect(cheques, debts, loans, installments, tasks) { Reminders.reschedule(ctx, cheques, debts, loans, installments, tasks) }
    LaunchedEffect(status, listening) { if (status.isNotEmpty() && !listening) { delay(4000); status = "" } }

    Box(Modifier.fillMaxSize().background(cs.background)) {
        Scaffold(
            containerColor = Color.Transparent,
            snackbarHost = { SnackbarHost(snack, Modifier.padding(bottom = 100.dp)) }
        ) { pad ->
            when (tab) {
                2 -> SettingsScreen(pad, vm) { m -> scope.launch { snack.showSnackbar(m) } }
                1 -> CardsScreen(
                    pad, cards, bal, { vm.addCard(it) }, { vm.updCard(it) }, { c, blocked -> vm.delCard(c, blocked) },
                    { vm.addTr(it) }, { m -> scope.launch { snack.showSnackbar(m) } }, { vm.log(it) }
                )
                5 -> TasksScreen(pad, vm, { m -> scope.launch { snack.showSnackbar(m) } }, { tab = it })
                3 -> ChequesScreen(pad, vm, cards, cats, bal) { m -> scope.launch { snack.showSnackbar(m) } }
                4 -> DebtsScreen(pad, vm, cards, cats) { m -> scope.launch { snack.showSnackbar(m) } }
                else -> LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 150.dp)) {
                    item { HomeHeader(badge, { tab = 5 }) { tab = 2 } }
                    if (txs.size >= 5 && System.currentTimeMillis() - ctx.getSharedPreferences("set", Context.MODE_PRIVATE).getLong("lastBackup", 0L) > 30L * 86_400_000L) item {
                        Sec {
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.surfaceContainerLow).clickable { tab = 2 }.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("💾", fontSize = 20.sp)
                                Text("بیش از ۳۰ روز است پشتیبان نگرفته‌اید. برای محافظت از اطلاعات، یک پشتیبان رمزنگاری‌شده بگیرید.", color = warnColor(), style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    item {
                        Sec {
                            Hero(
                                shownBal, filter?.let { "موجودی ${names[it] ?: ""}" } ?: "موجودی کل", inc, exp,
                                if (yearly) "درآمد سال" else "درآمد ${Months[pm - 1]}", if (yearly) "هزینه سال" else "هزینه ${Months[pm - 1]}", delta
                            )
                        }
                    }
                    if (cards.isNotEmpty()) item {
                        Sec {
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Pill("همه", filter == null) { filter = null }
                                Pill("نقدی", filter == 0L) { filter = 0L }
                                cards.forEach { c -> Pill(names[c.id] ?: "", filter == c.id) { filter = c.id } }
                            }
                        }
                    }
                    item {
                        Sec {
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton({ step(-1) }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "قبلی") }
                                    Text(
                                        if (yearly) "سال ${py.p()}" else "${Months[pm - 1]} ${py.p()}", Modifier.widthIn(min = 92.dp),
                                        fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 20.sp
                                    )
                                    IconButton({ step(1) }) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "بعدی") }
                                }
                                Seg(listOf("ماهانه", "سالانه"), if (yearly) 1 else 0, 36.dp) { yearly = it == 1 }
                            }
                        }
                    }
                    item {
                        Sec {
                            Column(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainerLow).padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                                    Text(
                                        (if (chartIncome) "درآمد " else "هزینه ") + (if (yearly) "ماه‌های سال ${py.p()}" else "۶ ماه اخیر"),
                                        fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 17.sp
                                    )
                                    Seg(listOf("هزینه", "درآمد"), if (chartIncome) 1 else 0, 30.dp) { chartIncome = it == 1 }
                                }
                                MonthBars(barVals, barLabels, if (yearly) pm - 1 else 5) { i -> val (y, m) = ym[i]; py = y; pm = m; yearly = false }
                            }
                        }
                    }
                    item { Sec { CatBars(period.filter { !it.income }, byId) } }
                    item {
                        Column(
                            Modifier.fillMaxWidth()
                                .background(cs.surfaceContainerLow, if (entries.isEmpty()) RoundedCornerShape(24.dp) else RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                                .padding(horizontal = 18.dp)
                        ) {
                            Row(Modifier.fillMaxWidth().height(56.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                                Text("تراکنش‌ها", fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                TextButton({ sheet = true }) {
                                    Icon(Icons.Default.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("ثبت دستی", fontWeight = FontWeight.SemiBold)
                                }
                            }
                            if (entries.isEmpty()) Text(
                                if (txs.isEmpty()) "دکمه 🎙️ را نگه دارید و بگویید: «ناهار صد و پنجاه هزار تومان» یا «حقوق ۲۵ میلیون واریز شد». یا با «ثبت دستی» اضافه کنید."
                                else "در این دوره تراکنشی ثبت نشده.",
                                Modifier.padding(bottom = 18.dp), color = cs.onSurfaceVariant
                            )
                        }
                    }
                    itemsIndexed(entries, key = { _, e -> e.key }) { i, e ->
                        val last = i == entries.lastIndex
                        Column(
                            Modifier.fillMaxWidth()
                                .background(cs.surfaceContainerLow, if (last) RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp) else RectangleShape)
                                .padding(horizontal = 18.dp)
                        ) {
                            HorizontalDivider(color = cs.outlineVariant)
                            when (e) {
                                is Entry.T -> TxRow(e.t, byId[e.t.catId], if (cards.isEmpty()) null else names[e.t.cardId]) {
                                    vm.del(e.t)
                                    scope.launch {
                                        val r = snack.showSnackbar("تراکنش حذف شد", "واگرد", duration = SnackbarDuration.Short)
                                        if (r == SnackbarResult.ActionPerformed) vm.restoreTx(e.t)
                                    }
                                }
                                is Entry.X -> TransferRow(e.x, names) {
                                    vm.delTr(e.x)
                                    scope.launch {
                                        val r = snack.showSnackbar("انتقال حذف شد", "واگرد", duration = SnackbarDuration.Short)
                                        if (r == SnackbarResult.ActionPerformed) vm.addTr(e.x)
                                    }
                                }
                            }
                            if (last) Spacer(Modifier.height(6.dp))
                        }
                    }
                }
            }
        }
        if (status.isNotEmpty()) Surface(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 124.dp).padding(horizontal = 24.dp),
            shape = RoundedCornerShape(16.dp), color = cs.surfaceContainerHighest
        ) { Text(status, Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) }
        FloatingNav(tab, { tab = it }, Modifier.align(Alignment.BottomCenter)) {
            Box(
                Modifier.size(68.dp).scale(if (listening) 1.12f else 1f).clip(CircleShape)
                    .border(5.dp, cs.background, CircleShape)
                    .background(if (listening) cs.error else accentColor())
                    .semantics { contentDescription = "نگه دارید و هزینه یا درآمد را بگویید" }
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                perm.launch(Manifest.permission.RECORD_AUDIO)
                            } else {
                                listening = true; status = "در حال گوش دادن…"; voice.start()
                                tryAwaitRelease()
                                listening = false; voice.stop()
                            }
                        })
                    },
                Alignment.Center
            ) { Text("🎙️", fontSize = 28.sp) }
        }
    }

    pending?.let { t ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("این مورد ثبت شود؟") },
            text = {
                Text(
                    "${if (t.income) "درآمد" else "هزینه"}: ${t.amount.fa()} تومان\nدسته: ${byId[t.catId]?.name ?: ""}\nکارت: ${names[t.cardId] ?: "نقدی"}" +
                        if (t.note.isNotBlank()) "\nشرح: ${t.note}" else ""
                )
            },
            confirmButton = { TextButton({ commit(t); pending = null }) { Text("ثبت") } },
            dismissButton = { TextButton({ pending = null }) { Text("لغو") } }
        )
    }
    pendingDebt?.let { e ->
        AlertDialog(
            onDismissRequest = { pendingDebt = null },
            title = { Text("این مورد ثبت شود؟") },
            text = { Text("${DebtKinds[e.kind]}: ${e.amount.fa()} تومان\nشخص: ${persons.firstOrNull { it.id == e.personId }?.name ?: ""}" + if (e.cardId >= 0) "\nکارت: ${names[e.cardId] ?: "نقدی"}" else "") },
            confirmButton = { TextButton({ commitDebt(e); pendingDebt = null }) { Text("ثبت") } },
            dismissButton = { TextButton({ pendingDebt = null }) { Text("لغو") } }
        )
    }
    pendingTask?.let { t ->
        AlertDialog(
            onDismissRequest = { pendingTask = null },
            title = { Text("این یادآوری ثبت شود؟") },
            text = { Text("${t.title}\n${fmtWhen(t.dueTs)}") },
            confirmButton = { TextButton({ vm.addTask(t); askNotif(); pendingTask = null; scope.launch { snack.showSnackbar("یادآوری ثبت شد") } }) { Text("ثبت") } },
            dismissButton = {
                Row {
                    TextButton({ draft = t; pendingTask = null }) { Text("ویرایش") }
                    TextButton({ pendingTask = null }) { Text("لغو") }
                }
            }
        )
    }
    draft?.let { t -> TaskDialog(t, { vm.addTask(it); askNotif(); draft = null }, null) { draft = null } }
    if (sheet) AddSheet(
        cats, cards, if (lastCard >= 0) lastCard else cards.firstOrNull()?.id ?: 0L,
        { sheet = false }, { catDlg = true }
    ) {
        if (it.note.isNotBlank()) Learn.put(ctx, it.note, it.catId)
        vm.add(it); lastCard = it.cardId; sheet = false
    }
    if (catDlg) CatDialog(cats, { vm.addCat(it) }, { c, blocked -> vm.delCat(c, blocked) }) { catDlg = false }
}

@Composable
private fun Sec(content: @Composable ColumnScope.() -> Unit) = Column(Modifier.fillMaxWidth().padding(bottom = 14.dp), content = content)

@Composable
fun HomeHeader(badge: Int, onBell: () -> Unit, onSettings: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().height(56.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(cs.primary), Alignment.Center) { Text("💳", fontSize = 18.sp) }
            Text("حسابداری شخصی", fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 21.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box {
                IconButton(onBell, Modifier.size(44.dp).clip(CircleShape).background(cs.surfaceContainerLow)) { Text("🔔", fontSize = 18.sp) }
                if (badge > 0) Box(Modifier.align(Alignment.TopEnd).size(18.dp).clip(CircleShape).background(cs.error), Alignment.Center) {
                    Text(badge.coerceAtMost(99).toLong().fa(), color = Color.White, fontSize = 11.sp)
                }
            }
            IconButton(onSettings, Modifier.size(44.dp).clip(CircleShape).background(cs.surfaceContainerLow)) { Icon(Icons.Default.Settings, "تنظیمات") }
        }
    }
}

@Composable
fun Hero(bal: Long, title: String, inc: Long, exp: Long, incLbl: String, expLbl: String, delta: String?) {
    val soft = Color.White.copy(alpha = .86f)
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(heroBrush()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(title, color = soft, fontSize = 13.sp)
            if (delta != null) Box(Modifier.clip(RoundedCornerShape(12.dp)).background(Color(0x66000000)).padding(horizontal = 10.dp, vertical = 5.dp)) {
                Text(delta, color = Color(0xFFBFF0D4), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(bal.fa(), color = Color.White, fontSize = 44.sp, lineHeight = 56.sp, fontWeight = FontWeight.Bold, fontFamily = Fonts.head)
            Text("تومان", color = soft, modifier = Modifier.padding(bottom = 10.dp))
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, Color(0xFFC9A75A), Color.Transparent))))
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF6FE3BE))); Text(incLbl, color = soft, fontSize = 12.sp)
                }
                Text(inc.fa(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFFFF9C94))); Text(expLbl, color = soft, fontSize = 12.sp)
                }
                Text(exp.fa(), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
        }
        Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(Color.White.copy(alpha = .14f))) {
            if (inc + exp > 0) Row(Modifier.fillMaxSize()) {
                if (inc > 0) Box(Modifier.weight(inc.toFloat()).fillMaxHeight().background(Color(0xFF6FE3BE)))
                if (exp > 0) Box(Modifier.weight(exp.toFloat()).fillMaxHeight().background(Color(0xFFFF9C94)))
            }
        }
    }
}

@Composable
fun Pill(text: String, on: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(22.dp)
    Box(
        Modifier.height(44.dp).clip(shape).background(if (on) cs.primary else cs.surfaceContainerLow)
            .border(1.dp, if (on) cs.primary else cs.outlineVariant, shape).clickable(onClick = onClick).padding(horizontal = 20.dp),
        Alignment.Center
    ) { Text(text, color = if (on) cs.onPrimary else cs.onSurface, fontSize = 14.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal) }
}

@Composable
fun Seg(opts: List<String>, sel: Int, h: Dp = 36.dp, onSel: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.clip(RoundedCornerShape(50)).background(cs.surfaceContainerLow).border(1.dp, cs.outlineVariant, RoundedCornerShape(50)).padding(3.dp)) {
        opts.forEachIndexed { i, t ->
            Box(
                Modifier.height(h).clip(RoundedCornerShape(50)).background(if (i == sel) cs.primary else Color.Transparent)
                    .clickable { onSel(i) }.padding(horizontal = 16.dp),
                Alignment.Center
            ) {
                Text(t, fontSize = 13.sp, color = if (i == sel) cs.onPrimary else cs.onSurfaceVariant, fontWeight = if (i == sel) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}

@Composable
fun MonthBars(values: List<Long>, labels: List<String>, sel: Int, onPick: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val mx = (values.maxOrNull() ?: 0L).coerceAtLeast(1L).toFloat()
    val many = values.size > 6
    Row(Modifier.fillMaxWidth().height(176.dp), Arrangement.SpaceBetween, Alignment.Bottom) {
        values.forEachIndexed { i, v ->
            val on = i == sel
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { onPick(i) }.padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom
            ) {
                if (on && !many) Box(Modifier.clip(RoundedCornerShape(10.dp)).background(cs.primaryContainer).padding(horizontal = 6.dp, vertical = 2.dp)) {
                    Text(short(v), fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = cs.onPrimaryContainer)
                }
                Spacer(Modifier.height(6.dp))
                Box(
                    Modifier.fillMaxWidth(if (many) .5f else .62f).height((110f * v / mx).dp.coerceAtLeast(8.dp)).clip(RoundedCornerShape(50))
                        .background(if (on) cs.primary else cs.primary.copy(alpha = .16f))
                        .then(if (on) Modifier else Modifier.hatched(cs.primary.copy(alpha = .35f)))
                )
                Spacer(Modifier.height(6.dp))
                Text(labels[i], fontSize = 12.sp, color = if (on) cs.onSurface else cs.onSurfaceVariant, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, maxLines = 1)
            }
        }
    }
}

@Composable
fun CatBars(ex: List<Tx>, cats: Map<Long, Category>) {
    val g = ex.groupBy { it.catId }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }.take(4)
    if (g.isEmpty()) return
    val top = g.first().value.toFloat()
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainerLow).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("بیشترین هزینه‌ها", fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        g.forEach { e ->
            val c = cats[e.key]
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("${c?.emoji ?: ""} ${c?.name ?: ""}")
                    Text(e.value.fa(), color = cs.onSurfaceVariant)
                }
                Box(Modifier.fillMaxWidth(e.value / top).height(6.dp).clip(CircleShape).background(Color(c?.color ?: 0xFF8A9A96)))
            }
        }
    }
}

@Composable
fun FloatingNav(tab: Int, onTab: (Int) -> Unit, modifier: Modifier, mic: @Composable () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(36.dp)
    Box(modifier.navigationBarsPadding().padding(start = 12.dp, end = 12.dp, bottom = 16.dp).fillMaxWidth().height(98.dp)) {
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(72.dp).shadow(12.dp, shape).background(cs.surfaceContainerLow, shape).padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
                NavItem("🏠", "خانه", tab == 0) { onTab(0) }
                NavItem("💳", "کارت‌ها", tab == 1) { onTab(1) }
            }
            Spacer(Modifier.width(72.dp))
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
                NavItem("🧾", "چک‌ها", tab == 3) { onTab(3) }
                NavItem("🤝", "بدهی", tab == 4) { onTab(4) }
            }
        }
        Box(Modifier.align(Alignment.TopCenter)) { mic() }
    }
}

@Composable
private fun NavItem(icon: String, label: String, on: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Column(
        Modifier.width(58.dp).height(54.dp).clip(RoundedCornerShape(18.dp)).background(if (on) cs.primaryContainer else Color.Transparent).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(icon, fontSize = 18.sp)
        Text(label, fontSize = 12.sp, color = if (on) cs.onPrimaryContainer else cs.onSurfaceVariant, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
    }
}

@Composable
fun TxRow(t: Tx, c: Category?, card: String?, onDel: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(Color(c?.color ?: 0xFF8A9A96).copy(alpha = .22f)), Alignment.Center) {
            Text(c?.name?.firstOrNull()?.toString() ?: "•", fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c?.name ?: "", fontWeight = FontWeight.SemiBold)
            Text(
                listOfNotNull(fmtDate(t.ts), t.note.takeIf { it.isNotBlank() }, card).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1
            )
        }
        // sign goes after the number
        Text(t.amount.fa() + if (t.income) "+" else "−", color = if (t.income) incomeColor() else cs.error, fontWeight = FontWeight.Bold)
        IconButton(onDel) { Icon(Icons.Default.Delete, "حذف", tint = cs.onSurfaceVariant) }
    }
}

@Composable
fun TransferRow(x: Transfer, names: Map<Long, String>, onDel: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(cs.surfaceContainerHighest), Alignment.Center) { Text("🔁") }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("انتقال از ${names[x.fromId] ?: "؟"} به ${names[x.toId] ?: "؟"}", fontWeight = FontWeight.SemiBold, maxLines = 1)
            Text(
                listOfNotNull(fmtDate(x.ts), x.note.takeIf { it.isNotBlank() }).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant, maxLines = 1
            )
        }
        Text(x.amount.fa(), fontWeight = FontWeight.Bold)
        IconButton(onDel) { Icon(Icons.Default.Delete, "حذف", tint = cs.onSurfaceVariant) }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddSheet(cats: List<Category>, cards: List<BankCard>, defCard: Long, onClose: () -> Unit, onCats: () -> Unit, onSave: (Tx) -> Unit) {
    var inc by remember { mutableStateOf(false) }
    var amt by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var cid by remember { mutableStateOf<Long?>(null) }
    var cardSel by remember { mutableLongStateOf(defCard) }
    val v = digits(amt).toLongOrNull()
    ModalBottomSheet(onDismissRequest = onClose) {
        Column(
            Modifier.padding(20.dp).navigationBarsPadding().imePadding().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("هزینه", "درآمد").forEachIndexed { i, l ->
                    SegmentedButton(selected = (i == 1) == inc, onClick = { inc = i == 1; cid = null }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(l) }
                }
            }
            OutlinedTextField(
                amt, { amt = digits(it) }, Modifier.fillMaxWidth(),
                label = { Text("مبلغ (تومان)") }, visualTransformation = Thousands, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cats.filter { it.income == inc }.forEach { c ->
                    FilterChip(cid == c.id, { cid = c.id }, { Text("${c.emoji} ${c.name}") })
                }
                AssistChip(onClick = onCats, label = { Text("＋ دسته جدید") })
            }
            if (cards.isNotEmpty()) {
                Text("کارت", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(cardSel == 0L, { cardSel = 0L }, { Text("نقدی") })
                    cards.forEach { c -> FilterChip(cardSel == c.id, { cardSel = c.id }, { Text(c.name.ifBlank { c.bank }) }) }
                }
            }
            OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("یادداشت (اختیاری)") }, singleLine = true)
            Button(
                {
                    onSave(Tx(amount = v!!, income = inc, catId = cid!!, note = note.trim(), ts = System.currentTimeMillis(), cardId = if (cards.isEmpty()) 0L else cardSel))
                },
                Modifier.fillMaxWidth().height(52.dp), enabled = v != null && v > 0 && cid != null
            ) { Text("ثبت") }
            Spacer(Modifier.height(8.dp))
        }
    }
}

private val Palette = listOf(0xFFE8A33DL, 0xFF4C8DF6L, 0xFF8E6CEFL, 0xFFE0574FL, 0xFF2BB3A3L, 0xFFEC6FA8L, 0xFF3FB950L, 0xFF8A9A96L)
private val Emojis = listOf("🏷️", "🎓", "🐶", "🎁", "🧾", "💳", "🚗", "🏋️", "📱", "☕", "🧴", "🛠️", "✈️", "👶", "🏦", "📈")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CatDialog(cats: List<Category>, onAdd: (Category) -> Unit, onDel: (Category, () -> Unit) -> Unit, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var inc by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf(Emojis[0]) }
    var color by remember { mutableStateOf(Palette[0]) }
    var warn by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClose) { Text("بستن") } },
        title = { Text("دسته جدید") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    listOf("هزینه", "درآمد").forEachIndexed { i, l ->
                        SegmentedButton(selected = (i == 1) == inc, onClick = { inc = i == 1 }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(l) }
                    }
                }
                OutlinedTextField(name, { name = it.take(20) }, Modifier.fillMaxWidth(), label = { Text("نام دسته") }, singleLine = true)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Emojis.forEach { e ->
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(if (e == emoji) cs.primaryContainer else Color.Transparent).clickable { emoji = e },
                            Alignment.Center
                        ) { Text(e, fontSize = 20.sp) }
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Palette.forEach { c ->
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).background(Color(c))
                                .border(3.dp, if (c == color) cs.onSurface else Color.Transparent, CircleShape).clickable { color = c }
                        )
                    }
                }
                Button({ onAdd(Category(name = name.trim(), emoji = emoji, color = color, income = inc)); name = ""; warn = "" }, Modifier.fillMaxWidth(), enabled = name.isNotBlank()) { Text("افزودن") }
                val mine = cats.filter { it.id > 10 }
                if (mine.isNotEmpty()) {
                    HorizontalDivider()
                    Text("دسته‌های شما", fontWeight = FontWeight.Bold)
                    mine.forEach { c ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${c.emoji} ${c.name} · ${if (c.income) "درآمد" else "هزینه"}", Modifier.weight(1f))
                            IconButton({ onDel(c) { warn = "«${c.name}» تراکنش دارد و حذف نمی‌شود" } }) { Icon(Icons.Default.Delete, "حذف") }
                        }
                    }
                }
                if (warn.isNotEmpty()) Text(warn, color = cs.error, style = MaterialTheme.typography.bodySmall)
            }
        }
    )
}
