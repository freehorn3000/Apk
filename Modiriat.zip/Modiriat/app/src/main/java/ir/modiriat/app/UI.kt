package ir.modiriat.app

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.draw.scale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.lifecycle.viewmodel.compose.viewModel

private val Light = lightColorScheme(
    primary = Color(0xFF0E8F6E), onPrimary = Color.White, primaryContainer = Color(0xFFCDEBE1),
    background = Color(0xFFEEF3F1), surface = Color(0xFFEEF3F1), onSurface = Color(0xFF12302B),
    onSurfaceVariant = Color(0xFF5B716C), error = Color(0xFFD9453D),
    surfaceContainerLow = Color.White, surfaceContainerHighest = Color(0xFFD9E4E0)
)
private val Dark = darkColorScheme(
    primary = Color(0xFF4FD1A9), onPrimary = Color(0xFF00382B), primaryContainer = Color(0xFF1B4A3E),
    background = Color(0xFF0D1514), surface = Color(0xFF0D1514), onSurface = Color(0xFFE3EDEA),
    onSurfaceVariant = Color(0xFF9BB0AB), error = Color(0xFFFF8A80),
    surfaceContainerLow = Color(0xFF16211F), surfaceContainerHighest = Color(0xFF26332F)
)

@Composable
fun Theme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
    }
}

@Composable
fun LockScreen(onTry: () -> Unit) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("🔒", fontSize = 56.sp)
            Text("حسابداری شخصی", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            FilledTonalButton(onTry) { Text("باز کردن قفل") }
        }
    }
}

sealed class Entry(val ts: Long, val key: String) {
    class T(val t: Tx) : Entry(t.ts, "t${t.id}")
    class X(val x: Transfer) : Entry(x.ts, "x${x.id}")
}

@Composable
fun App(vm: VM = viewModel()) {
    val txs by vm.txs.collectAsState()
    val cats by vm.cats.collectAsState()
    val cards by vm.cards.collectAsState()
    val trs by vm.trs.collectAsState()
    val byId = cats.associateBy { it.id }
    val names = remember(cards) { mapOf(0L to "نقدی") + cards.associate { it.id to it.name.ifBlank { it.bank } } }
    val bal = remember(cards, txs, trs) { balances(cards, txs, trs) }
    val now = jalali(System.currentTimeMillis())
    val cs = MaterialTheme.colorScheme
    var tab by remember { mutableIntStateOf(0) }
    var filter by remember { mutableStateOf<Long?>(null) }
    var lastCard by remember { mutableLongStateOf(-1L) }
    var py by remember { mutableIntStateOf(now.first) }
    var pm by remember { mutableIntStateOf(now.second) }
    var yearly by remember { mutableStateOf(false) }
    val withJ = remember(txs) { txs.map { it to jalali(it.ts) } }
    fun inPeriod(j: Triple<Int, Int, Int>) = j.first == py && (yearly || j.second == pm)
    val period = withJ.filter { (t, j) -> inPeriod(j) && (filter == null || t.cardId == filter) }.map { it.first }
    val trPeriod = trs.filter { inPeriod(jalali(it.ts)) && (filter == null || it.fromId == filter || it.toId == filter) }
    val entries = buildList<Entry> {
        period.forEach { add(Entry.T(it)) }
        trPeriod.forEach { add(Entry.X(it)) }
    }.sortedByDescending { it.ts }
    val inc = period.filter { it.income }.sumOf { it.amount }
    val exp = period.filter { !it.income }.sumOf { it.amount }
    val shownBal = filter?.let { bal[it] ?: 0L } ?: bal.values.sum()
    val yi = remember(withJ, py, filter) {
        LongArray(13).also { a -> withJ.forEach { (t, j) -> if (j.first == py && t.income && (filter == null || t.cardId == filter)) a[j.second] += t.amount } }
    }
    val ye = remember(withJ, py, filter) {
        LongArray(13).also { a -> withJ.forEach { (t, j) -> if (j.first == py && !t.income && (filter == null || t.cardId == filter)) a[j.second] += t.amount } }
    }
    fun step(d: Int) {
        if (yearly) py += d else {
            var nm = pm + d
            if (nm < 1) { nm = 12; py-- } else if (nm > 12) { nm = 1; py++ }
            pm = nm
        }
    }

    var sheet by remember { mutableStateOf(false) }
    var catDlg by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        status = if (ok) "حالا دکمه را نگه دارید و صحبت کنید" else "برای ثبت صوتی، اجازه میکروفون لازم است"
    }
    val handle = rememberUpdatedState { text: String ->
        val p0 = parseVoice(text)
        val named = cats.firstOrNull { it.id > 10 && text.contains(it.name) }
        val p = if (named != null) p0.copy(income = named.income) else p0
        val c = named ?: pickCat(cats, p)
        val card = cardFromText(cards, text)
        val cid = when {
            card != null -> card.id
            isCash(text) -> 0L
            lastCard >= 0 -> lastCard
            else -> cards.firstOrNull()?.id ?: 0L
        }
        val amt = p.amount
        if (amt == null) status = "مبلغ را متوجه نشدم: «$text»"
        else if (c == null) status = "دسته‌ای پیدا نشد"
        else {
            val t0 = jalali(System.currentTimeMillis()); py = t0.first; pm = t0.second; yearly = false
            val note = cleanNote(p.note, listOfNotNull(card?.name, card?.bank))
            vm.add(Tx(amount = amt, income = p.income, catId = c.id, note = note, ts = System.currentTimeMillis(), cardId = cid)) { saved ->
                lastCard = cid
                scope.launch {
                    val cardPart = if (cards.isEmpty()) "" else " · ${names[cid] ?: "نقدی"}"
                    val r = snack.showSnackbar(
                        "${if (saved.income) "درآمد" else "هزینه"} ${saved.amount.fa()} تومان · ${c.name}$cardPart ثبت شد",
                        "واگرد", duration = SnackbarDuration.Short
                    )
                    if (r == SnackbarResult.ActionPerformed) vm.del(saved)
                }
            }
        }
    }
    val voice = remember { Voice(ctx, { handle.value(it) }, { status = it }) }
    DisposableEffect(Unit) { onDispose { voice.destroy() } }
    LaunchedEffect(status, listening) { if (status.isNotEmpty() && !listening) { delay(4000); status = "" } }

    Scaffold(
        containerColor = cs.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == 0, { tab = 0 }, { Text("🏠") }, label = { Text("خانه") })
                NavigationBarItem(tab == 1, { tab = 1 }, { Text("💳") }, label = { Text("کارت‌ها") })
                NavigationBarItem(tab == 2, { tab = 2 }, { Text("⚙️") }, label = { Text("تنظیمات") })
            }
        },
        floatingActionButton = {
            if (tab == 0) Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (status.isNotEmpty()) Surface(shape = RoundedCornerShape(16.dp), color = cs.surfaceContainerHighest) {
                    Text(status, Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    SmallFloatingActionButton({ sheet = true }) { Icon(Icons.Default.Add, "تراکنش جدید") }
                    Box(
                        Modifier.size(76.dp).scale(if (listening) 1.12f else 1f).clip(CircleShape)
                            .background(if (listening) cs.error else cs.primary)
                            .semantics { contentDescription = "نگه دارید و هزینه یا درآمد را بگویید" }
                            .pointerInput(Unit) {
                                detectTapGestures(onPress = {
                                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                        perm.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        listening = true; status = "در حال گوش دادن…"; voice.start()
                                        tryAwaitRelease()
                                        listening = false; voice.stop()
                                    }
                                })
                            },
                        Alignment.Center
                    ) { Text("🎙️", fontSize = 32.sp) }
                }
            }
        }
    ) { pad ->
        if (tab == 2) {
            SettingsScreen(pad, vm) { m -> scope.launch { snack.showSnackbar(m) } }
        } else if (tab == 1) {
            CardsScreen(
                pad, cards, bal, { vm.addCard(it) }, { vm.updCard(it) }, { c, blocked -> vm.delCard(c, blocked) },
                { vm.addTr(it) }, { m -> scope.launch { snack.showSnackbar(m) } }
            )
        } else LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 140.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Balance(shownBal, filter?.let { "موجودی ${names[it] ?: ""}" } ?: "موجودی کل") }
            if (cards.isNotEmpty()) item {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(filter == null, { filter = null }, { Text("همه") })
                    FilterChip(filter == 0L, { filter = 0L }, { Text("نقدی") })
                    cards.forEach { c -> FilterChip(filter == c.id, { filter = c.id }, { Text(names[c.id] ?: "") }) }
                }
            }
            item {
                PeriodBar(if (yearly) "سال ${py.p()}" else "${Months[pm - 1]} ${py.p()}", yearly, { step(-1) }, { step(1) }) { yearly = it }
            }
            if (yearly) item { YearChart(yi, ye, pm) { pm = it; yearly = false } }
            item { FlowBar(inc, exp) }
            item { CatBars(period.filter { !it.income }, byId) }
            item { Text("تراکنش‌ها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            if (entries.isEmpty()) item {
                Text(
                    if (txs.isEmpty()) "دکمه 🎙️ را نگه دارید و بگویید: «ناهار صد و پنجاه هزار تومان» یا «حقوق ۲۵ میلیون واریز شد». یا با + دستی ثبت کنید."
                    else "در این دوره تراکنشی ثبت نشده.",
                    color = cs.onSurfaceVariant
                )
            }
            items(entries, key = { it.key }) { e ->
                when (e) {
                    is Entry.T -> TxRow(e.t, byId[e.t.catId], if (cards.isEmpty()) null else names[e.t.cardId]) { vm.del(e.t) }
                    is Entry.X -> TransferRow(e.x, names) { vm.delTr(e.x) }
                }
            }
        }
    }
    if (sheet) AddSheet(
        cats, cards, if (lastCard >= 0) lastCard else cards.firstOrNull()?.id ?: 0L,
        { sheet = false }, { catDlg = true }
    ) { vm.add(it); lastCard = it.cardId; sheet = false }
    if (catDlg) CatDialog(cats, { vm.addCat(it) }, { c, blocked -> vm.delCat(c, blocked) }) { catDlg = false }
}

@Composable
fun Balance(bal: Long, title: String) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, color = cs.onSurfaceVariant)
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(bal.fa(), fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 52.sp)
            Text("تومان", color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PeriodBar(label: String, yearly: Boolean, onPrev: () -> Unit, onNext: () -> Unit, onMode: (Boolean) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("ماهانه", "سالانه").forEachIndexed { i, l ->
                SegmentedButton(selected = (i == 1) == yearly, onClick = { onMode(i == 1) }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(l) }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onPrev) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "قبلی") }
            Text(label, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            IconButton(onNext) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "بعدی") }
        }
    }
}

@Composable
fun YearChart(yi: LongArray, ye: LongArray, sel: Int, onPick: (Int) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val mx = (1..12).maxOf { maxOf(yi[it], ye[it]) }.coerceAtLeast(1L).toFloat()
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainerLow).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        for (m in 1..12) {
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (m == sel) cs.primaryContainer else Color.Transparent)
                    .clickable { onPick(m) }.padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.height(80.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                    Box(Modifier.width(6.dp).height((80f * yi[m] / mx).dp).clip(CircleShape).background(cs.primary))
                    Box(Modifier.width(6.dp).height((80f * ye[m] / mx).dp).clip(CircleShape).background(cs.error))
                }
                Spacer(Modifier.height(4.dp))
                Text(m.toLong().fa(), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun FlowBar(inc: Long, exp: Long) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(cs.surfaceContainerHighest)) {
            if (inc + exp > 0) Row(Modifier.fillMaxSize()) {
                if (inc > 0) Box(Modifier.weight(inc.toFloat()).fillMaxHeight().background(cs.primary))
                if (exp > 0) Box(Modifier.weight(exp.toFloat()).fillMaxHeight().background(cs.error))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("درآمد", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text(inc.fa(), color = cs.primary, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("مانده دوره", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text((inc - exp).fa(), fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("هزینه", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text(exp.fa(), color = cs.error, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun CatBars(ex: List<Tx>, cats: Map<Long, Category>) {
    val g = ex.groupBy { it.catId }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }.take(4)
    if (g.isEmpty()) return
    val top = g.first().value.toFloat()
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceContainerLow).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("بیشترین هزینه‌ها در این ماه", fontWeight = FontWeight.Bold)
        g.forEach { e ->
            val c = cats[e.key]
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${c?.emoji ?: ""} ${c?.name ?: ""}")
                    Text(e.value.fa(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box(Modifier.fillMaxWidth(e.value / top).height(6.dp).clip(CircleShape).background(Color(c?.color ?: 0xFF8A9A96)))
            }
        }
    }
}

@Composable
fun TxRow(t: Tx, c: Category?, card: String?, onDel: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(Color(c?.color ?: 0xFF8A9A96).copy(alpha = .22f)), Alignment.Center) { Text(c?.emoji ?: "•") }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c?.name ?: "", fontWeight = FontWeight.SemiBold)
            Text(
                listOfNotNull(fmtDate(t.ts), t.note.takeIf { it.isNotBlank() }, card).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
        }
        // sign goes after the number
        Text(t.amount.fa() + if (t.income) "+" else "−", color = if (t.income) cs.primary else cs.error, fontWeight = FontWeight.Bold)
        IconButton(onDel) { Icon(Icons.Default.Delete, "حذف", tint = cs.onSurfaceVariant) }
    }
}

@Composable
fun TransferRow(x: Transfer, names: Map<Long, String>, onDel: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(cs.surfaceContainerHighest), Alignment.Center) { Text("🔁") }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("انتقال از ${names[x.fromId] ?: "؟"} به ${names[x.toId] ?: "؟"}", fontWeight = FontWeight.SemiBold)
            Text(
                listOfNotNull(fmtDate(x.ts), x.note.takeIf { it.isNotBlank() }).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
        }
        Text(x.amount.fa(), fontWeight = FontWeight.Bold)
        IconButton(onDel) { Icon(Icons.Default.Delete, "حذف", tint = cs.onSurfaceVariant) }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddSheet(cats: List<Category>, cards: List<BankCard>, defCard: Long, onClose: () -> Unit, onCats: () -> Unit, onSave: (Tx) -> Unit) {
    var inc by remember { mutableStateOf(false) }
    var amt by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var cid by remember { mutableStateOf<Long?>(null) }
    var cardSel by remember { mutableLongStateOf(defCard) }
    val v = digits(amt).toLongOrNull()
    ModalBottomSheet(onDismissRequest = onClose) {
        Column(
            Modifier.padding(20.dp).navigationBarsPadding().imePadding().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("هزینه", "درآمد").forEachIndexed { i, l ->
                    SegmentedButton(selected = (i == 1) == inc, onClick = { inc = i == 1; cid = null }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(l) }
                }
            }
            OutlinedTextField(
                amt, { amt = digits(it) }, Modifier.fillMaxWidth(),
                label = { Text("مبلغ (تومان)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cats.filter { it.income == inc }.forEach { c ->
                    FilterChip(cid == c.id, { cid = c.id }, { Text("${c.emoji} ${c.name}") })
                }
                AssistChip(onClick = onCats, label = { Text("＋ دسته جدید") })
            }
            if (cards.isNotEmpty()) {
                Text("کارت", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(cardSel == 0L, { cardSel = 0L }, { Text("نقدی") })
                    cards.forEach { c -> FilterChip(cardSel == c.id, { cardSel = c.id }, { Text(c.name.ifBlank { c.bank }) }) }
                }
            }
            OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("یادداشت (اختیاری)") }, singleLine = true)
            Button(
                {
                    onSave(Tx(amount = v!!, income = inc, catId = cid!!, note = note.trim(), ts = System.currentTimeMillis(), cardId = if (cards.isEmpty()) 0L else cardSel))
                },
                Modifier.fillMaxWidth().height(52.dp), enabled = v != null && v > 0 && cid != null
            ) { Text("ثبت") }
            Spacer(Modifier.height(8.dp))
        }
    }
}

private val Palette = listOf(0xFFE8A33DL, 0xFF4C8DF6L, 0xFF8E6CEFL, 0xFFE0574FL, 0xFF2BB3A3L, 0xFFEC6FA8L, 0xFF3FB950L, 0xFF8A9A96L)
private val Emojis = listOf("🏷️", "🎓", "🐶", "🎁", "🧾", "💳", "🚗", "🏋️", "📱", "☕", "🧴", "🛠️", "✈️", "👶", "🏦", "📈")

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun CatDialog(cats: List<Category>, onAdd: (Category) -> Unit, onDel: (Category, () -> Unit) -> Unit, onClose: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var inc by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var emoji by remember { mutableStateOf(Emojis[0]) }
    var color by remember { mutableStateOf(Palette[0]) }
    var warn by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClose) { Text("بستن") } },
        title = { Text("دسته جدید") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    listOf("هزینه", "درآمد").forEachIndexed { i, l ->
                        SegmentedButton(selected = (i == 1) == inc, onClick = { inc = i == 1 }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(l) }
                    }
                }
                OutlinedTextField(name, { name = it.take(20) }, Modifier.fillMaxWidth(), label = { Text("نام دسته") }, singleLine = true)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Emojis.forEach { e ->
                        Box(
                            Modifier.size(40.dp).clip(CircleShape).background(if (e == emoji) cs.primaryContainer else Color.Transparent).clickable { emoji = e },
                            Alignment.Center
                        ) { Text(e, fontSize = 20.sp) }
                    }
                }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Palette.forEach { c ->
                        Box(
                            Modifier.size(32.dp).clip(CircleShape).background(Color(c))
                                .border(3.dp, if (c == color) cs.onSurface else Color.Transparent, CircleShape).clickable { color = c }
                        )
                    }
                }
                Button({ onAdd(Category(name = name.trim(), emoji = emoji, color = color, income = inc)); name = ""; warn = "" }, Modifier.fillMaxWidth(), enabled = name.isNotBlank()) { Text("افزودن") }
                val mine = cats.filter { it.id > 10 }
                if (mine.isNotEmpty()) {
                    HorizontalDivider()
                    Text("دسته‌های شما", fontWeight = FontWeight.Bold)
                    mine.forEach { c ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("${c.emoji} ${c.name} · ${if (c.income) "درآمد" else "هزینه"}", Modifier.weight(1f))
                            IconButton({ onDel(c) { warn = "«${c.name}» تراکنش دارد و حذف نمی‌شود" } }) { Icon(Icons.Default.Delete, "حذف") }
                        }
                    }
                }
                if (warn.isNotEmpty()) Text(warn, color = cs.error, style = MaterialTheme.typography.bodySmall)
            }
        }
    )
}
