package ir.modiriat.app

import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation

/**
 * Shows a digits-only value with thousands separators and Persian digits while typing (۱٬۲۰۰٬۰۰۰).
 * The stored text stays plain digits; only the display changes, and the cursor is mapped correctly.
 */
class ThousandsTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text
        val n = raw.length
        val out = StringBuilder()
        val o2t = IntArray(n + 1)
        val t2o = ArrayList<Int>()
        for (k in 0 until n) {
            if (k > 0 && (n - k) % 3 == 0) { out.append('٬'); t2o.add(k) }
            o2t[k] = out.length
            val ch = raw[k]
            out.append(if (ch in '0'..'9') '۰' + (ch - '0') else ch)
            t2o.add(k)
        }
        o2t[n] = out.length
        t2o.add(n)
        return TransformedText(AnnotatedString(out.toString()), object : OffsetMapping {
            override fun originalToTransformed(offset: Int): Int = o2t[offset.coerceIn(0, n)]
            override fun transformedToOriginal(offset: Int): Int = t2o[offset.coerceIn(0, t2o.size - 1)]
        })
    }
}

val Thousands = ThousandsTransformation()
