package ir.modiriat.app

import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** Lets the app stay unlocked while it deliberately opens a file picker or share sheet (they move the app to the background). */
object LockCtl {
    var skipNext = false
    var kept = false
    var stoppedAt = 0L
}

/**
 * Strong biometric or phone PIN/pattern. If the phone has neither, the app's own PIN is used
 * (and must be created first), so data is never shown without any check.
 */
fun authenticate(a: FragmentActivity, title: String, onOk: () -> Unit) {
    val x = BIOMETRIC_STRONG or DEVICE_CREDENTIAL
    if (BiometricManager.from(a).canAuthenticate(x) == BiometricManager.BIOMETRIC_SUCCESS) {
        val cb = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
        }
        BiometricPrompt(a, ContextCompat.getMainExecutor(a), cb).authenticate(
            BiometricPrompt.PromptInfo.Builder().setTitle(title).setAllowedAuthenticators(x).build()
        )
    } else {
        Gate.req = PinReq(setup = !Pin.isSet(a), onOk = onOk)
    }
}

class MainActivity : FragmentActivity() {
    private var unlocked by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()
        Pref.load(this)
        Fonts.load(this)
        cleanShare(this)
        setContent {
            Theme {
                if (unlocked) App() else LockScreen { auth() }
                PinHost()
            }
        }
        // anti-overlay (tapjacking): ignore touches while another window covers the app
        window.decorView.filterTouchesWhenObscured = true
        findViewById<ViewGroup>(android.R.id.content).getChildAt(0)?.filterTouchesWhenObscured = true
        if (Build.VERSION.SDK_INT >= 31) window.setHideOverlayWindows(true)
    }

    private fun delayMs() = getSharedPreferences("set", MODE_PRIVATE).getInt("lockDelay", 0) * 1000L

    override fun onStart() {
        super.onStart()
        if (unlocked && !LockCtl.kept && delayMs() > 0 && SystemClock.elapsedRealtime() - LockCtl.stoppedAt > delayMs()) unlocked = false
        LockCtl.kept = false
        if (!unlocked) auth()
    }

    override fun onStop() {
        super.onStop()
        LockCtl.stoppedAt = SystemClock.elapsedRealtime()
        if (LockCtl.skipNext) { LockCtl.skipNext = false; LockCtl.kept = true }
        else if (delayMs() == 0L) unlocked = false
    }

    private fun auth() = authenticate(this, "ورود به حسابداری شخصی") { unlocked = true }
}
