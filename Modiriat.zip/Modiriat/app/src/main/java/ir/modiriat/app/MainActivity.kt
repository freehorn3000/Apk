package ir.modiriat.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** Biometric / device-credential check. If the phone has no screen lock, it simply continues. */
fun authenticate(a: FragmentActivity, title: String, onOk: () -> Unit) {
    val x = BIOMETRIC_WEAK or DEVICE_CREDENTIAL
    if (BiometricManager.from(a).canAuthenticate(x) != BiometricManager.BIOMETRIC_SUCCESS) { onOk(); return }
    val cb = object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onOk() }
    }
    BiometricPrompt(a, ContextCompat.getMainExecutor(a), cb).authenticate(
        BiometricPrompt.PromptInfo.Builder().setTitle(title).setAllowedAuthenticators(x).build()
    )
}

class MainActivity : FragmentActivity() {
    private var unlocked by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()
        setContent { Theme { if (unlocked) App() else LockScreen { auth() } } }
    }

    override fun onStart() { super.onStart(); if (!unlocked) auth() }
    override fun onStop() { super.onStop(); unlocked = false }

    private fun auth() = authenticate(this, "ورود به حسابداری شخصی") { unlocked = true }
}
