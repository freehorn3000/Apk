package ir.modiriat.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToLong
import kotlinx.coroutines.launch

/** Same day-of-month, k Jalali months later (clamped to the length of that month). */
fun addJalaliMonths(ms: Long, k: Int): Long {
    val (y, m, d) = jalali(ms)
    val idx = y * 12 + (m - 1) + k
    val nm = idx % 12 + 1
    val maxd = if (nm <= 6) 31 else if (nm <= 11) 30 else 29
    return jalaliToMs(idx / 12, nm, minOf(d, maxd))
}

/**
 * Estimated interest part of each installment: finds the periodic rate that makes the installments worth
 * `principal` today, then splits each installment into interest (balance x rate) and principal. The last one absorbs rounding.
 * It is an estimate: the bank statement always wins, and each installment can be edited.
 */
fun amortize(principal: Long, amounts: List<Long>): List<Long> {
    if (amounts.isEmpty() || amounts.sum() <= principal) return amounts.map { 0L }
    var lo = 0.0; var hi = 5.0
    repeat(100) {
        val mid = (lo + hi) / 2
        var pv = 0.0
        amounts.forEachIndexed { i, a -> pv += a / Math.pow(1 + mid, (i + 1).toDouble()) }
        if (pv > principal) lo = mid else hi = mid
    }
    val r = (lo + hi) / 2
    var bal = principal
    val out = ArrayList<Long>()
    amounts.forEachIndexed { i, a ->
        if (i == amounts.lastIndex) out.add((a - bal).coerceAtLeast(0L))
        else { val intr = (bal * r).roundToLong().coerceIn(0L, a); out.add(intr); bal -= (a - intr) }
    }
    return out
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun LoanDialog(cards: List<BankCard>, onSave: (Loan, Long, Int, Long) -> Unit, onClose: () -> Unit) {
    var lender by remember { mutableStateOf("") }
    var principal by remember { mutableStateOf("") }
    var fees by remember { mutableStateOf("") }
    var recv by remember { mutableStateOf<Long?>(todayStart()) }
    var cnt by remember { mutableStateOf("") }
    var inst by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<Long?>(addJalaliMonths(todayStart(), 1)) }
    var interval by remember { mutableIntStateOf(1) }
    var card by remember { mutableLongStateOf(-1L) }
    var remind by remember { mutableStateOf(true) }
    var note by remember { mutableStateOf("") }
    val p = digits(principal).toLongOrNull()
    val n = digits(cnt).toIntOrNull()
    val a = digits(inst).toLongOrNull()
    val ok = lender.isNotBlank() && p != null && p > 0 && n != null && n in 1..120 && a != null && a > 0 && recv != null && first != null
    val opts = listOf(-1L to "وام قبلی (بدون اثر روی کارت)", 0L to "نقدی") + cards.map { it.id to it.name.ifBlank { it.bank } }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("وام دریافتی جدید") },
        confirmButton = {
            TextButton(
                {
                    onSave(
                        Loan(lender = lender.trim(), principal = p!!, fees = digits(fees).toLongOrNull() ?: 0L, receivedTs = recv!!, cnt = n!!, cardId = card,
                            note = note.trim(), remind = remind, personId = 0, disbDebtId = 0, feeTxId = 0),
                        first!!, interval, a!!
                    )
                },
                enabled = ok
            ) { Text("ثبت وام") }
        },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(lender, { lender = it.take(30) }, Modifier.fillMaxWidth(), label = { Text("وام‌دهنده (مثلاً بانک ملی)") }, singleLine = true)
                OutlinedTextField(principal, { principal = digits(it) }, Modifier.fillMaxWidth(), label = { Text("مبلغ وام (تومان)") }, singleLine = true, keyboardOptions = num)
                OutlinedTextField(fees, { fees = digits(it) }, Modifier.fillMaxWidth(), label = { Text("کارمزد و بیمه کسرشده هنگام دریافت (اختیاری)") }, singleLine = true, keyboardOptions = num)
                Text("تاریخ دریافت", fontWeight = FontWeight.SemiBold)
                DateFields(todayStart()) { recv = it }
                OutlinedTextField(cnt, { cnt = digits(it).take(3) }, Modifier.fillMaxWidth(), label = { Text("تعداد اقساط") }, singleLine = true, keyboardOptions = num)
                OutlinedTextField(inst, { inst = digits(it) }, Modifier.fillMaxWidth(), label = { Text("مبلغ هر قسط (تومان)") }, singleLine = true, keyboardOptions = num)
                Text("سررسید قسط اول", fontWeight = FontWeight.SemiBold)
                DateFields(addJalaliMonths(todayStart(), 1)) { first = it }
                Text("فاصله اقساط", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(1, 2, 3).forEach { m -> FilterChip(interval == m, { interval = m }, { Text(if (m == 1) "ماهانه" else "هر ${faDigits("$m")} ماه") }) }
                }
                Text("دریافت وام در کدام حساب بوده؟", fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { opts.forEach { o -> FilterChip(card == o.first, { card = o.first }, { Text(o.second) }) } }
                if (ok) {
                    val total = a!! * n!!
                    Text("جمع اقساط ${total.fa()} تومان · سود و کارمزد کل (برآوردی) ${(total - p!!).coerceAtLeast(0L).fa()} تومان", style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("یادداشت (اختیاری)") }, singleLine = true)
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) { Text("یادآوری اقساط"); Switch(remind, { remind = it }) }
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PayDialog(l: Loan, i: Installment, cards: List<BankCard>, onOk: (Long, Long, Long, Long) -> Unit, onClose: () -> Unit) {
    var amt by remember { mutableStateOf(i.amount.toString()) }
    var late by remember { mutableStateOf("") }
    var ts by remember { mutableStateOf<Long?>(minOf(i.dueTs, todayStart())) }
    var card by remember { mutableLongStateOf(if (l.cardId >= 0) l.cardId else (cards.firstOrNull()?.id ?: 0L)) }
    val v = digits(amt).toLongOrNull()
    val lf = digits(late).toLongOrNull() ?: 0L
    val opts = listOf(0L to "نقدی") + cards.map { it.id to it.name.ifBlank { it.bank } }
    val intr = if (v != null) minOf(i.interest, v) else 0L
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("پرداخت قسط ${i.num.toLong().fa()}") },
        confirmButton = { TextButton({ onOk(v!!, lf, ts!!, card) }, enabled = v != null && v > 0 && ts != null) { Text("ثبت پرداخت") } },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(amt, { amt = digits(it) }, Modifier.fillMaxWidth(), label = { Text("مبلغ قسط (تومان)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(late, { late = digits(it) }, Modifier.fillMaxWidth(), label = { Text("جریمه دیرکرد (اختیاری)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Text("تاریخ پرداخت", fontWeight = FontWeight.SemiBold)
                DateFields(minOf(i.dueTs, todayStart())) { ts = it }
                Text("پرداخت از", fontWeight = FontWeight.SemiBold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { opts.forEach { o -> FilterChip(card == o.first, { card = o.first }, { Text(o.second) }) } }
                if (v != null) Text(
                    "اصل وام ≈ ${(v - intr).fa()} تومان کم از بدهی می‌شود. سود و جریمه ≈ ${(intr + lf).fa()} تومان به‌عنوان هزینه ثبت می‌شود.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    )
}

@Composable
fun InstEditDialog(i: Installment, onSave: (Installment) -> Unit, onClose: () -> Unit) {
    var due by remember { mutableStateOf<Long?>(i.dueTs) }
    var amt by remember { mutableStateOf(i.amount.toString()) }
    var intr by remember { mutableStateOf(i.interest.toString()) }
    val v = digits(amt).toLongOrNull()
    val it2 = digits(intr).toLongOrNull()
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("ویرایش قسط ${i.num.toLong().fa()}") },
        confirmButton = { TextButton({ onSave(i.copy(dueTs = due!!, amount = v!!, interest = it2!!)) }, enabled = due != null && v != null && v > 0 && it2 != null) { Text("ذخیره") } },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("سررسید", fontWeight = FontWeight.SemiBold)
                DateFields(i.dueTs) { due = it }
                OutlinedTextField(amt, { amt = digits(it) }, Modifier.fillMaxWidth(), label = { Text("مبلغ قسط") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                OutlinedTextField(intr, { intr = digits(it) }, Modifier.fillMaxWidth(), label = { Text("بخش سود و کارمزد (طبق برگه بانک)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoansScreen(pad: PaddingValues, vm: VM, cards: List<BankCard>, cats: List<Category>, onMsg: (String) -> Unit, onPeople: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    fun share(doc: Doc, pdf: Boolean) {
        scope.launch {
            val f = runCatching { exportDoc(ctx, doc, pdf) }.getOrNull()
            if (f == null) onMsg("ساخت صورت‌حساب ناموفق بود")
            else { sendFile(ctx, f, if (pdf) "application/pdf" else "image/png"); vm.log("صورت‌حساب گرافیکی ارسال شد") }
        }
    }
    val loans by vm.loans.collectAsState()
    val its by vm.installments.collectAsState()
    val debts by vm.debts.collectAsState()
    var open by remember { mutableStateOf<Long?>(null) }
    var adding by remember { mutableStateOf(false) }
    var payFor by remember { mutableStateOf<Installment?>(null) }
    var editInst by remember { mutableStateOf<Installment?>(null) }
    var sel by remember { mutableStateOf<Installment?>(null) }
    var revertFor by remember { mutableStateOf<Installment?>(null) }
    var delLoan by remember { mutableStateOf(false) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val expCat = (cats.filter { !it.income }.let { it.getOrNull(6) ?: it.lastOrNull() })?.id ?: 0L
    fun remaining(l: Loan) = (-netOf(debts.filter { it.personId == l.personId })).coerceAtLeast(0L)
    fun dueText(i: Installment): String {
        val d = daysLeft(i.dueTs)
        return if (d < 0) faDigits("${-d}") + " روز معوق" else if (d == 0) "امروز" else faDigits("$d") + " روز دیگر"
    }
    val loan = loans.firstOrNull { it.id == open }

    if (loan == null) {
        val unpaid = its.filter { !it.paid }.sortedBy { it.dueTs }
        val next = unpaid.firstOrNull()
        val nextLoan = loans.firstOrNull { it.id == next?.loanId }
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 150.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Seg(listOf("اشخاص", "وام‌ها"), 1, 36.dp) { if (it == 0) onPeople() }
                    Button({ adding = true }) { Text("＋ وام") }
                }
            }
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainerLow).padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("مانده اصل همه وام‌ها", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    Text(loans.sumOf { remaining(it) }.fa() + " تومان", fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 26.sp, color = cs.error)
                    if (next != null && nextLoan != null) Text(
                        "قسط بعدی: ${nextLoan.lender} · ${fmtDateY(next.dueTs)} · ${dueText(next)} · ${next.amount.fa()} تومان",
                        style = MaterialTheme.typography.bodySmall, color = if (daysLeft(next.dueTs) < 0) cs.error else cs.onSurfaceVariant
                    )
                }
            }
            if (loans.isEmpty()) item { Text("وام دریافتی‌تان را با «＋ وام» ثبت کنید. برای وامی که قبلاً گرفته‌اید، فقط باقی‌مانده و اقساط پیش‌رو را وارد کنید.", color = cs.onSurfaceVariant) }
            items(loans, key = { it.id }) { l ->
                val mine = its.filter { it.loanId == l.id }.sortedBy { it.num }
                val paid = mine.count { it.paid }
                val nx = mine.firstOrNull { !it.paid }
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).clickable { open = l.id }.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(l.lender, fontWeight = FontWeight.Bold)
                        Text(remaining(l).fa(), color = cs.error, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(progress = { if (mine.isEmpty()) 0f else paid.toFloat() / mine.size }, Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)))
                    Text(
                        "${paid.toLong().fa()} از ${mine.size.toLong().fa()} قسط پرداخت شده" + if (nx != null) " · قسط بعدی ${fmtDate(nx.dueTs)} (${dueText(nx)})" else " · تسویه‌شده",
                        style = MaterialTheme.typography.bodySmall, color = if (nx != null && daysLeft(nx.dueTs) < 0) cs.error else cs.onSurfaceVariant
                    )
                }
            }
        }
    } else {
        val mine = its.filter { it.loanId == loan.id }.sortedBy { it.num }
        val paid = mine.count { it.paid }
        val nx = mine.firstOrNull { !it.paid }
        val total = mine.sumOf { it.amount }
        val overdue = mine.count { !it.paid && daysLeft(it.dueTs) < 0 }
        LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 150.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ open = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "بازگشت") }
                    Text("وام ${loan.lender}", fontFamily = Fonts.head, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                }
            }
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainerLow).padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("مانده اصل وام", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                    Text(remaining(loan).fa() + " تومان", fontFamily = Fonts.head, fontWeight = FontWeight.Bold, fontSize = 28.sp, color = cs.error)
                    LinearProgressIndicator(progress = { if (mine.isEmpty()) 0f else paid.toFloat() / mine.size }, Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)))
                    HorizontalDivider(color = cs.outlineVariant)
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text("مبلغ وام"); Text(loan.principal.fa()) }
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text("جمع اقساط"); Text(total.fa()) }
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text("سود و کارمزد کل (برآوردی)"); Text((total - loan.principal).coerceAtLeast(0L).fa()) }
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text("مانده اقساط"); Text(mine.filter { !it.paid }.sumOf { it.amount }.fa(), fontWeight = FontWeight.Bold) }
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text("پرداخت‌شده"); Text("${paid.toLong().fa()} از ${mine.size.toLong().fa()} قسط") }
                    if (overdue > 0) Text("${overdue.toLong().fa()} قسط معوق دارید", color = cs.error, fontWeight = FontWeight.SemiBold)
                    Text("تقسیم قسط به اصل و سود برآوردی است. اگر برگه بانک را دارید، با «ویرایش» اصلاحش کنید.", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ nx?.let { payFor = it } }, Modifier.weight(1f), enabled = nx != null) { Text("پرداخت قسط بعدی") }
                    OutlinedButton({ delLoan = true }, Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(contentColor = cs.error)) { Text("حذف وام") }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ share(loanDoc(loan, mine, remaining(loan), System.currentTimeMillis()), false) }, Modifier.weight(1f)) { Text("صورت‌حساب وام (تصویر)") }
                    OutlinedButton({ share(loanDoc(loan, mine, remaining(loan), System.currentTimeMillis()), true) }, Modifier.weight(1f)) { Text("فایل PDF") }
                }
            }
            items(mine, key = { it.id }) { i ->
                val late = !i.paid && daysLeft(i.dueTs) < 0
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.surfaceContainerLow).clickable { sel = i }.padding(14.dp),
                    Arrangement.SpaceBetween, Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("قسط ${i.num.toLong().fa()} · ${fmtDateY(i.dueTs)}", fontWeight = FontWeight.SemiBold)
                        Text(
                            if (i.paid) "پرداخت‌شده ${fmtDate(i.paidTs)}" else dueText(i),
                            style = MaterialTheme.typography.bodySmall,
                            color = if (i.paid) incomeColor() else if (late) cs.error else if (daysLeft(i.dueTs) <= 3) warnColor() else cs.onSurfaceVariant
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(i.amount.fa(), fontWeight = FontWeight.Bold)
                        Text("سود ≈ ${i.interest.fa()}", fontSize = 12.sp, color = cs.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (adding) LoanDialog(cards, { l, first, interval, amount ->
        vm.createLoan(l, first, interval, amount, expCat); if (l.remind) askNotif(); adding = false
    }) { adding = false }
    payFor?.let { i ->
        val l = loans.firstOrNull { it.id == i.loanId }
        if (l != null) PayDialog(l, i, cards, { amount, late, ts, card -> vm.payInstallment(l, i, amount, late, ts, card, expCat); payFor = null }) { payFor = null }
    }
    editInst?.let { i -> InstEditDialog(i, { vm.updInstallment(it); editInst = null }) { editInst = null } }
    revertFor?.let { i ->
        AlertDialog(
            onDismissRequest = { revertFor = null },
            title = { Text("برگشت پرداخت قسط؟") },
            text = { Text("تراکنش‌های ثبت‌شده برای این پرداخت حذف می‌شوند و قسط دوباره «پرداخت‌نشده» می‌شود.") },
            confirmButton = { TextButton({ vm.revertInstallment(i); revertFor = null }) { Text("برگردان") } },
            dismissButton = { TextButton({ revertFor = null }) { Text("انصراف") } }
        )
    }
    if (delLoan && loan != null) AlertDialog(
        onDismissRequest = { delLoan = false },
        title = { Text("حذف وام ${loan.lender}؟") },
        text = { Text("فقط وامی که هیچ قسطی از آن پرداخت نشده حذف می‌شود. اگر قسط پرداخت‌شده دارد، اول پرداخت‌ها را برگردانید.") },
        confirmButton = {
            TextButton({
                vm.deleteLoan(loan, its.filter { it.loanId == loan.id }) { onMsg("این وام قسط پرداخت‌شده دارد و حذف نمی‌شود") }
                delLoan = false; open = null
            }, colors = ButtonDefaults.textButtonColors(contentColor = cs.error)) { Text("حذف") }
        },
        dismissButton = { TextButton({ delLoan = false }) { Text("انصراف") } }
    )
    sel?.let { i ->
        val cur = its.firstOrNull { it.id == i.id } ?: i
        ModalBottomSheet(onDismissRequest = { sel = null }) {
            Column(Modifier.padding(20.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("قسط ${cur.num.toLong().fa()} · ${fmtDateY(cur.dueTs)}", fontWeight = FontWeight.Bold)
                Text("${cur.amount.fa()} تومان · سود ≈ ${cur.interest.fa()}", color = cs.onSurfaceVariant)
                if (!cur.paid) {
                    Button({ payFor = cur; sel = null }, Modifier.fillMaxWidth()) { Text("پرداخت") }
                    OutlinedButton({ editInst = cur; sel = null }, Modifier.fillMaxWidth()) { Text("ویرایش تاریخ و مبلغ") }
                } else {
                    Text("پرداخت‌شده در ${fmtDateY(cur.paidTs)} · مبلغ ${cur.paidAmount.fa()} تومان", color = cs.onSurfaceVariant)
                    Button({
                        val l2 = loans.firstOrNull { it.id == cur.loanId }
                        if (l2 != null) share(installmentReceipt(l2, cur, its.count { it.loanId == l2.id }, remaining(l2), System.currentTimeMillis()), false)
                        sel = null
                    }, Modifier.fillMaxWidth()) { Text("ارسال رسید پرداخت (تصویر)") }
                    OutlinedButton({ revertFor = cur; sel = null }, Modifier.fillMaxWidth()) { Text("برگشت پرداخت") }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
