package ir.modiriat.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VM(app: Application) : AndroidViewModel(app) {
    private val d = AppDb.build(app).d()
    val txs = d.txs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cats = d.cats().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cards = d.cards().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val trs = d.trs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun add(t: Tx, done: (Tx) -> Unit = {}) { viewModelScope.launch { val id = d.add(t); done(t.copy(id = id)) } }
    fun del(t: Tx) { viewModelScope.launch { d.del(t) } }
    fun addCat(c: Category) { viewModelScope.launch { d.addCat(c) } }
    fun delCat(c: Category, blocked: () -> Unit) { viewModelScope.launch { if (d.used(c.id) > 0) blocked() else d.delCat(c.id) } }
    fun addCard(c: BankCard) { viewModelScope.launch { d.addCard(c) } }
    fun updCard(c: BankCard) { viewModelScope.launch { d.updCard(c) } }
    fun delCard(c: BankCard, blocked: () -> Unit) { viewModelScope.launch { if (d.cardUsed(c.id) > 0) blocked() else d.delCard(c.id) } }
    fun addTr(x: Transfer) { viewModelScope.launch { d.addTr(x) } }
    fun delTr(x: Transfer) { viewModelScope.launch { d.delTr(x) } }
}
