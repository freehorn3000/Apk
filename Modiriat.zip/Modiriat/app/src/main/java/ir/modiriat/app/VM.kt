package ir.modiriat.app

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.security.KeyStore
import kotlin.system.exitProcess

class VM(app: Application) : AndroidViewModel(app) {
    private val db = AppDb.build(app)
    private val d = db.d()
    val txs = d.txs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cats = d.cats().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cards = d.cards().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val trs = d.trs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val events = d.events().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cheques = d.cheques().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val persons = d.persons().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val debts = d.debts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val loans = d.loans().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val installments = d.installments().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val tasks = d.tasks().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Local activity log (stays in the encrypted database). */
    fun log(text: String) { viewModelScope.launch { d.addEvent(Event(ts = System.currentTimeMillis(), text = text)); d.trimEvents() } }
    fun clearEvents() { viewModelScope.launch { d.clearEvents() } }

    fun add(t: Tx, done: (Tx) -> Unit = {}) {
        viewModelScope.launch {
            val id = d.add(t)
            log("${if (t.income) "درآمد" else "هزینه"} ${t.amount.fa()} تومان ثبت شد")
            done(t.copy(id = id))
        }
    }
    fun del(t: Tx) { viewModelScope.launch { d.del(t); log("تراکنش ${t.amount.fa()} تومان حذف شد") } }
    fun restoreTx(t: Tx) { viewModelScope.launch { d.add(t); log("حذف تراکنش واگرد شد") } }
    fun addCat(c: Category) { viewModelScope.launch { d.addCat(c); log("دسته «${c.name}» افزوده شد") } }
    fun delCat(c: Category, blocked: () -> Unit) {
        viewModelScope.launch { if (d.used(c.id) > 0) blocked() else { d.delCat(c.id); log("دسته «${c.name}» حذف شد") } }
    }
    fun addCard(c: BankCard) { viewModelScope.launch { d.addCard(c); log("کارت جدید افزوده شد") } }
    fun updCard(c: BankCard) { viewModelScope.launch { d.updCard(c); log("کارت ویرایش شد") } }
    fun delCard(c: BankCard, blocked: () -> Unit) {
        viewModelScope.launch { if (d.cardUsed(c.id) > 0) blocked() else { d.delCard(c.id); log("کارت حذف شد") } }
    }
    fun addTr(x: Transfer) { viewModelScope.launch { d.addTr(x); log("انتقال ${x.amount.fa()} تومان ثبت شد") } }
    fun delTr(x: Transfer) { viewModelScope.launch { d.delTr(x); log("انتقال حذف شد") } }

    // ---- cheques ----
    fun addCheque(c: Cheque) { viewModelScope.launch { d.addCheque(c); log("چک ${if (c.incoming) "دریافتی" else "پرداختی"} ثبت شد") } }
    fun updCheque(c: Cheque) { viewModelScope.launch { d.updCheque(c); log("چک ویرایش شد") } }
    fun delCheque(c: Cheque) { viewModelScope.launch { d.delCheque(c); log("چک حذف شد") } }
    fun setChequeStatus(c: Cheque, st: Int) { viewModelScope.launch { d.updCheque(c.copy(status = st)); log("وضعیت چک تغییر کرد") } }

    /** Clearing a cheque records one real transaction (cash basis); the cheque keeps a link to it. */
    fun clearCheque(c: Cheque, ts: Long, cardId: Long, catId: Long) {
        viewModelScope.launch {
            val id = d.add(Tx(amount = c.amount, income = c.incoming, catId = catId, note = ("چک " + c.party).trim(), ts = ts, cardId = cardId))
            d.updCheque(c.copy(status = 1, cardId = cardId, txId = id, doneTs = ts))
            log("چک پاس شد و تراکنش ثبت شد")
        }
    }
    fun revertCheque(c: Cheque) {
        viewModelScope.launch {
            if (c.txId > 0) d.delTxId(c.txId)
            if (c.tx2Id > 0) d.delTxId(c.tx2Id)
            d.updCheque(c.copy(status = 0, txId = 0, tx2Id = 0, doneTs = 0))
            log("پاس چک برگردانده شد")
        }
    }
    /** Received cheque handed to a third party: income and expense on cash, net zero. */
    fun endorseCheque(c: Cheque, ts: Long, incCat: Long, expCat: Long) {
        viewModelScope.launch {
            val a = d.add(Tx(amount = c.amount, income = true, catId = incCat, note = ("چک " + c.party).trim(), ts = ts, cardId = 0))
            val b = d.add(Tx(amount = c.amount, income = false, catId = expCat, note = ("خرج چک " + c.party).trim(), ts = ts, cardId = 0))
            d.updCheque(c.copy(status = 4, txId = a, tx2Id = b, doneTs = ts))
            log("چک خرج شد")
        }
    }

    // ---- debts and credits ----
    fun addPerson(p: Person) { viewModelScope.launch { d.addPerson(p); log("حساب شخص جدید افزوده شد") } }
    fun delPerson(p: Person, blocked: () -> Unit) {
        viewModelScope.launch { if (d.personUsed(p.id) > 0) blocked() else { d.delPerson(p.id); log("حساب یک شخص حذف شد") } }
    }
    fun addDebt(e: DebtEntry, done: (DebtEntry) -> Unit = {}) {
        viewModelScope.launch { val id = d.addDebt(e); log("ثبت بدهی یا طلب: ${DebtKinds[e.kind]}"); done(e.copy(id = id)) }
    }
    fun delDebt(e: DebtEntry) { viewModelScope.launch { d.delDebt(e); log("یک ثبت بدهی یا طلب حذف شد") } }

    // ---- tasks / reminders ----
    fun addTask(t: Task) { viewModelScope.launch { d.addTask(t); log("یادآوری جدید ثبت شد") } }
    fun updTask(t: Task) { viewModelScope.launch { d.updTask(t) } }
    fun delTask(t: Task) { viewModelScope.launch { d.delTask(t.id); log("یک یادآوری حذف شد") } }
    /** One-off tasks become done; repeating tasks move to their next occurrence. */
    fun completeTask(t: Task) {
        viewModelScope.launch {
            if (t.rep == 0) d.updTask(t.copy(done = true, doneTs = System.currentTimeMillis()))
            else d.updTask(t.copy(dueTs = plusRepeat(effDue(t), t.rep)))
            log("یک یادآوری انجام شد")
        }
    }

    /** Fills an empty app with demo data (for store screenshots only). */
    fun loadSample(cats: List<Category>) {
        viewModelScope.launch {
            val exp = cats.filter { !it.income }
            val inc = cats.filter { it.income }
            if (exp.size < 7 || inc.isEmpty()) return@launch
            val day = 86_400_000L
            val a = d.addCard(BankCard(bank = "ملی", number = "6037991812345670", name = "حقوق", initial = 20_000_000))
            val b = d.addCard(BankCard(bank = "ملت", number = "6104339876543210", name = "پس‌انداز", initial = 10_000_000))
            val today = todayStart()
            val todayDay = jalali(today).third
            fun at(k: Int, dd: Int): Long {
                val m = addJalaliMonths(today, k)
                return m + (minOf(dd, if (k == 0) todayDay else dd) - jalali(m).third) * day + 12 * 3_600_000L
            }
            val f = listOf(100L, 85L, 120L, 95L)
            for (k in 0 downTo -3) {
                val p = f[-k]
                d.add(Tx(amount = 25_000_000, income = true, catId = inc[0].id, note = "حقوق", ts = at(k, 1), cardId = a))
                d.add(Tx(amount = 3_200_000, income = false, catId = exp[2].id, note = "اجاره و قبوض", ts = at(k, 5), cardId = a))
                d.add(Tx(amount = 2_100_000 * p / 100, income = false, catId = exp[0].id, note = "خرید خوراک", ts = at(k, 8), cardId = a))
                d.add(Tx(amount = 1_450_000 * p / 100, income = false, catId = exp[1].id, note = "تاکسی و بنزین", ts = at(k, 12), cardId = a))
                d.add(Tx(amount = 900_000 * p / 100, income = false, catId = exp[3].id, note = "لباس", ts = at(k, 15), cardId = b))
                d.add(Tx(amount = 450_000, income = false, catId = exp[4].id, note = "دکتر", ts = at(k, 18), cardId = a))
                d.add(Tx(amount = 700_000 * p / 100, income = false, catId = exp[5].id, note = "سینما", ts = at(k, 20), cardId = a))
            }
            d.add(Tx(amount = 150_000, income = false, catId = exp[0].id, note = "ناهار", ts = today + 12 * 3_600_000L, cardId = a))
            d.add(Tx(amount = 80_000, income = false, catId = exp[1].id, note = "تاکسی", ts = today + 13 * 3_600_000L, cardId = 0))
            val pid = d.addPerson(Person(name = "علی", note = ""))
            d.addDebt(DebtEntry(personId = pid, kind = 0, amount = 5_000_000, ts = today - 40 * day, note = "برای خرید", cardId = -1, dueTs = 0))
            d.addDebt(DebtEntry(personId = pid, kind = 2, amount = 1_000_000, ts = today - 25 * day, note = "", cardId = -1, dueTs = 0))
            d.addDebt(DebtEntry(personId = pid, kind = 1, amount = 1_500_000, ts = today - 10 * day, note = "", cardId = -1, dueTs = 0))
            d.addDebt(DebtEntry(personId = pid, kind = 3, amount = 500_000, ts = today - 3 * day, note = "", cardId = -1, dueTs = 0))
            d.addCheque(Cheque(incoming = false, amount = 8_000_000, dueTs = today + 5 * day, party = "پیمانکار", sayad = "", number = "", cardId = a, status = 0, note = "", remind = true))
            d.addCheque(Cheque(incoming = true, amount = 12_000_000, dueTs = today + 12 * day, party = "مشتری", sayad = "", number = "", cardId = b, status = 0, note = "", remind = true))
            d.addTask(Task(title = "پرداخت قبض برق", note = "", dueTs = today + day + 10 * 3_600_000L, rep = 3, leadMin = 60, done = false, doneTs = 0, showTitle = true))
            d.addTask(Task(title = "زنگ زدن به بانک", note = "", dueTs = today + day + 17 * 3_600_000L, rep = 0, leadMin = 0, done = false, doneTs = 0, showTitle = true))
            createLoan(
                Loan(lender = "بانک ملی", principal = 100_000_000, fees = 500_000, receivedTs = today - 35 * day, cnt = 12, cardId = -1, note = "", remind = true,
                    personId = 0, disbDebtId = 0, feeTxId = 0),
                addJalaliMonths(today, 1), 1, 9_500_000, exp[6].id
            )
            log("داده نمونه افزوده شد")
        }
    }

    // ---- received loans ----
    /**
     * Cash-basis accounting: the principal is a liability (a DebtEntry of the lender), not income; upfront fees are an expense.
     * Each installment is later split into principal (reduces the liability) and interest (an expense).
     */
    fun createLoan(l: Loan, firstDue: Long, interval: Int, amount: Long, feeCat: Long) {
        viewModelScope.launch {
            val pid = d.addPerson(Person(name = l.lender, note = "وام"))
            val dis = d.addDebt(DebtEntry(personId = pid, kind = 1, amount = l.principal, ts = l.receivedTs, note = "دریافت وام", cardId = l.cardId, dueTs = 0))
            val feeId = if (l.fees > 0 && l.cardId >= 0) d.add(Tx(amount = l.fees, income = false, catId = feeCat, note = "کارمزد و بیمه وام ${l.lender}", ts = l.receivedTs, cardId = l.cardId)) else 0L
            val loanId = d.addLoan(l.copy(personId = pid, disbDebtId = dis, feeTxId = feeId))
            val ints = amortize(l.principal, List(l.cnt) { amount })
            d.addInstallments(List(l.cnt) { k ->
                Installment(loanId = loanId, num = k + 1, dueTs = addJalaliMonths(firstDue, k * interval), amount = amount, interest = ints[k],
                    paid = false, paidTs = 0, paidAmount = 0, debtId = 0, txId = 0)
            })
            log("وام جدید ثبت شد")
        }
    }
    fun updInstallment(i: Installment) { viewModelScope.launch { d.updInstallment(i); log("قسط وام ویرایش شد") } }
    fun payInstallment(l: Loan, i: Installment, amount: Long, lateFee: Long, ts: Long, cardId: Long, catId: Long) {
        viewModelScope.launch {
            val interest = minOf(i.interest, amount)
            val principalPart = amount - interest
            val debtId = if (principalPart > 0) d.addDebt(DebtEntry(personId = l.personId, kind = 3, amount = principalPart, ts = ts, note = "قسط ${i.num} وام ${l.lender}", cardId = cardId, dueTs = 0)) else 0L
            val expense = interest + lateFee
            val txId = if (expense > 0) d.add(Tx(amount = expense, income = false, catId = catId, note = "سود و کارمزد قسط ${i.num} ${l.lender}", ts = ts, cardId = cardId)) else 0L
            d.updInstallment(i.copy(paid = true, paidTs = ts, paidAmount = amount + lateFee, debtId = debtId, txId = txId))
            log("قسط وام پرداخت شد")
        }
    }
    fun revertInstallment(i: Installment) {
        viewModelScope.launch {
            if (i.debtId > 0) d.delDebtId(i.debtId)
            if (i.txId > 0) d.delTxId(i.txId)
            d.updInstallment(i.copy(paid = false, paidTs = 0, paidAmount = 0, debtId = 0, txId = 0))
            log("پرداخت قسط وام برگردانده شد")
        }
    }
    fun deleteLoan(l: Loan, its: List<Installment>, blocked: () -> Unit) {
        viewModelScope.launch {
            if (its.any { it.paid }) blocked()
            else {
                if (l.disbDebtId > 0) d.delDebtId(l.disbDebtId)
                if (l.feeTxId > 0) d.delTxId(l.feeTxId)
                d.delInstallments(l.id); d.delLoan(l.id)
                if (d.personUsed(l.personId) == 0) d.delPerson(l.personId)
                log("وام حذف شد")
            }
        }
    }

    /** Replaces all data with the backup content, atomically. */
    fun restore(b: Backup.Data, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = runCatching {
                db.withTransaction {
                    d.clearTx(); d.clearTr(); d.clearCards(); d.clearCats(); d.clearCheques(); d.clearPersons(); d.clearDebts(); d.clearLoans(); d.clearInstallments(); d.clearTasks()
                    d.putCats(b.cats); d.putCards(b.cards); d.putTxs(b.txs); d.putTrs(b.trs); d.putCheques(b.cheques); d.putPersons(b.persons); d.putDebts(b.debts); d.putLoans(b.loans); d.putInstallments(b.installments); d.putTasks(b.tasks)
                }
            }.isSuccess
            log(if (ok) "اطلاعات از پشتیبان بازیابی شد" else "بازیابی پشتیبان ناموفق بود")
            done(ok)
        }
    }

    /** Deletes the database, the encryption key and all settings, then quits. */
    fun wipe(a: Activity) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { db.close() }
            a.deleteDatabase("m.db")
            listOf("k", "pin", "set", "learn", "rem", "remtitle").forEach { a.getSharedPreferences(it, 0).edit().clear().commit() }
            runCatching { KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry("db") }
            exitProcess(0)
        }
    }
}
