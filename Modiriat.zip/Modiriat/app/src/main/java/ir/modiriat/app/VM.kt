package ir.modiriat.app

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.security.KeyStore
import kotlin.system.exitProcess

class VM(app: Application) : AndroidViewModel(app) {
    private val db = AppDb.build(app)
    private val d = db.d()
    val txs = d.txs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cats = d.cats().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cards = d.cards().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val trs = d.trs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val events = d.events().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Local activity log (stays in the encrypted database). */
    fun log(text: String) { viewModelScope.launch { d.addEvent(Event(ts = System.currentTimeMillis(), text = text)); d.trimEvents() } }
    fun clearEvents() { viewModelScope.launch { d.clearEvents() } }

    fun add(t: Tx, done: (Tx) -> Unit = {}) {
        viewModelScope.launch {
            val id = d.add(t)
            log("${if (t.income) "درآمد" else "هزینه"} ${t.amount.fa()} تومان ثبت شد")
            done(t.copy(id = id))
        }
    }
    fun del(t: Tx) { viewModelScope.launch { d.del(t); log("تراکنش ${t.amount.fa()} تومان حذف شد") } }
    fun restoreTx(t: Tx) { viewModelScope.launch { d.add(t); log("حذف تراکنش واگرد شد") } }
    fun addCat(c: Category) { viewModelScope.launch { d.addCat(c); log("دسته «${c.name}» افزوده شد") } }
    fun delCat(c: Category, blocked: () -> Unit) {
        viewModelScope.launch { if (d.used(c.id) > 0) blocked() else { d.delCat(c.id); log("دسته «${c.name}» حذف شد") } }
    }
    fun addCard(c: BankCard) { viewModelScope.launch { d.addCard(c); log("کارت جدید افزوده شد") } }
    fun updCard(c: BankCard) { viewModelScope.launch { d.updCard(c); log("کارت ویرایش شد") } }
    fun delCard(c: BankCard, blocked: () -> Unit) {
        viewModelScope.launch { if (d.cardUsed(c.id) > 0) blocked() else { d.delCard(c.id); log("کارت حذف شد") } }
    }
    fun addTr(x: Transfer) { viewModelScope.launch { d.addTr(x); log("انتقال ${x.amount.fa()} تومان ثبت شد") } }
    fun delTr(x: Transfer) { viewModelScope.launch { d.delTr(x); log("انتقال حذف شد") } }

    /** Replaces all data with the backup content, atomically. */
    fun restore(b: Backup.Data, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = runCatching {
                db.withTransaction {
                    d.clearTx(); d.clearTr(); d.clearCards(); d.clearCats()
                    d.putCats(b.cats); d.putCards(b.cards); d.putTxs(b.txs); d.putTrs(b.trs)
                }
            }.isSuccess
            log(if (ok) "اطلاعات از پشتیبان بازیابی شد" else "بازیابی پشتیبان ناموفق بود")
            done(ok)
        }
    }

    /** Deletes the database, the encryption key and all settings, then quits. */
    fun wipe(a: Activity) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { db.close() }
            a.deleteDatabase("m.db")
            listOf("k", "pin", "set", "learn").forEach { a.getSharedPreferences(it, 0).edit().clear().commit() }
            runCatching { KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry("db") }
            exitProcess(0)
        }
    }
}
