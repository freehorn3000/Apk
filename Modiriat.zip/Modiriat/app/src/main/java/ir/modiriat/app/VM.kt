package ir.modiriat.app

import android.app.Activity
import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.security.KeyStore
import kotlin.system.exitProcess

class VM(app: Application) : AndroidViewModel(app) {
    private val db = AppDb.build(app)
    private val d = db.d()
    val txs = d.txs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cats = d.cats().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cards = d.cards().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val trs = d.trs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val events = d.events().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val cheques = d.cheques().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val persons = d.persons().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val debts = d.debts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** Local activity log (stays in the encrypted database). */
    fun log(text: String) { viewModelScope.launch { d.addEvent(Event(ts = System.currentTimeMillis(), text = text)); d.trimEvents() } }
    fun clearEvents() { viewModelScope.launch { d.clearEvents() } }

    fun add(t: Tx, done: (Tx) -> Unit = {}) {
        viewModelScope.launch {
            val id = d.add(t)
            log("${if (t.income) "درآمد" else "هزینه"} ${t.amount.fa()} تومان ثبت شد")
            done(t.copy(id = id))
        }
    }
    fun del(t: Tx) { viewModelScope.launch { d.del(t); log("تراکنش ${t.amount.fa()} تومان حذف شد") } }
    fun restoreTx(t: Tx) { viewModelScope.launch { d.add(t); log("حذف تراکنش واگرد شد") } }
    fun addCat(c: Category) { viewModelScope.launch { d.addCat(c); log("دسته «${c.name}» افزوده شد") } }
    fun delCat(c: Category, blocked: () -> Unit) {
        viewModelScope.launch { if (d.used(c.id) > 0) blocked() else { d.delCat(c.id); log("دسته «${c.name}» حذف شد") } }
    }
    fun addCard(c: BankCard) { viewModelScope.launch { d.addCard(c); log("کارت جدید افزوده شد") } }
    fun updCard(c: BankCard) { viewModelScope.launch { d.updCard(c); log("کارت ویرایش شد") } }
    fun delCard(c: BankCard, blocked: () -> Unit) {
        viewModelScope.launch { if (d.cardUsed(c.id) > 0) blocked() else { d.delCard(c.id); log("کارت حذف شد") } }
    }
    fun addTr(x: Transfer) { viewModelScope.launch { d.addTr(x); log("انتقال ${x.amount.fa()} تومان ثبت شد") } }
    fun delTr(x: Transfer) { viewModelScope.launch { d.delTr(x); log("انتقال حذف شد") } }

    // ---- cheques ----
    fun addCheque(c: Cheque) { viewModelScope.launch { d.addCheque(c); log("چک ${if (c.incoming) "دریافتی" else "پرداختی"} ثبت شد") } }
    fun updCheque(c: Cheque) { viewModelScope.launch { d.updCheque(c); log("چک ویرایش شد") } }
    fun delCheque(c: Cheque) { viewModelScope.launch { d.delCheque(c); log("چک حذف شد") } }
    fun setChequeStatus(c: Cheque, st: Int) { viewModelScope.launch { d.updCheque(c.copy(status = st)); log("وضعیت چک تغییر کرد") } }

    /** Clearing a cheque records one real transaction (cash basis); the cheque keeps a link to it. */
    fun clearCheque(c: Cheque, ts: Long, cardId: Long, catId: Long) {
        viewModelScope.launch {
            val id = d.add(Tx(amount = c.amount, income = c.incoming, catId = catId, note = ("چک " + c.party).trim(), ts = ts, cardId = cardId))
            d.updCheque(c.copy(status = 1, cardId = cardId, txId = id, doneTs = ts))
            log("چک پاس شد و تراکنش ثبت شد")
        }
    }
    fun revertCheque(c: Cheque) {
        viewModelScope.launch {
            if (c.txId > 0) d.delTxId(c.txId)
            if (c.tx2Id > 0) d.delTxId(c.tx2Id)
            d.updCheque(c.copy(status = 0, txId = 0, tx2Id = 0, doneTs = 0))
            log("پاس چک برگردانده شد")
        }
    }
    /** Received cheque handed to a third party: income and expense on cash, net zero. */
    fun endorseCheque(c: Cheque, ts: Long, incCat: Long, expCat: Long) {
        viewModelScope.launch {
            val a = d.add(Tx(amount = c.amount, income = true, catId = incCat, note = ("چک " + c.party).trim(), ts = ts, cardId = 0))
            val b = d.add(Tx(amount = c.amount, income = false, catId = expCat, note = ("خرج چک " + c.party).trim(), ts = ts, cardId = 0))
            d.updCheque(c.copy(status = 4, txId = a, tx2Id = b, doneTs = ts))
            log("چک خرج شد")
        }
    }

    // ---- debts and credits ----
    fun addPerson(p: Person) { viewModelScope.launch { d.addPerson(p); log("حساب شخص جدید افزوده شد") } }
    fun delPerson(p: Person, blocked: () -> Unit) {
        viewModelScope.launch { if (d.personUsed(p.id) > 0) blocked() else { d.delPerson(p.id); log("حساب یک شخص حذف شد") } }
    }
    fun addDebt(e: DebtEntry, done: (DebtEntry) -> Unit = {}) {
        viewModelScope.launch { val id = d.addDebt(e); log("ثبت بدهی یا طلب: ${DebtKinds[e.kind]}"); done(e.copy(id = id)) }
    }
    fun delDebt(e: DebtEntry) { viewModelScope.launch { d.delDebt(e); log("یک ثبت بدهی یا طلب حذف شد") } }

    /** Replaces all data with the backup content, atomically. */
    fun restore(b: Backup.Data, done: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = runCatching {
                db.withTransaction {
                    d.clearTx(); d.clearTr(); d.clearCards(); d.clearCats(); d.clearCheques(); d.clearPersons(); d.clearDebts()
                    d.putCats(b.cats); d.putCards(b.cards); d.putTxs(b.txs); d.putTrs(b.trs); d.putCheques(b.cheques); d.putPersons(b.persons); d.putDebts(b.debts)
                }
            }.isSuccess
            log(if (ok) "اطلاعات از پشتیبان بازیابی شد" else "بازیابی پشتیبان ناموفق بود")
            done(ok)
        }
    }

    /** Deletes the database, the encryption key and all settings, then quits. */
    fun wipe(a: Activity) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { db.close() }
            a.deleteDatabase("m.db")
            listOf("k", "pin", "set", "learn", "rem").forEach { a.getSharedPreferences(it, 0).edit().clear().commit() }
            runCatching { KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry("db") }
            exitProcess(0)
        }
    }
}
