package ir.modiriat.app

import java.text.NumberFormat
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.util.Locale

private val nf = NumberFormat.getInstance(Locale.forLanguageTag("fa"))
private val nfPlain = NumberFormat.getInstance(Locale.forLanguageTag("fa")).apply { isGroupingUsed = false }
val Months = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")

fun Long.fa(): String = nf.format(this)

fun jalali(ms: Long): Triple<Int, Int, Int> {
    val d = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
    val gy = d.year; val gm = d.monthValue; val gd = d.dayOfMonth
    val g = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    val gy2 = if (gm > 2) gy + 1 else gy
    var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + g[gm - 1]
    var jy = -1595 + 33 * (days / 12053); days %= 12053
    jy += 4 * (days / 1461); days %= 1461
    if (days > 365) { jy += (days - 1) / 365; days = (days - 1) % 365 }
    val jm = if (days < 186) 1 + days / 31 else 7 + (days - 186) / 30
    val jd = 1 + if (days < 186) days % 31 else (days - 186) % 30
    return Triple(jy, jm, jd)
}

fun fmtDate(ms: Long): String { val (_, m, d) = jalali(ms); return nfPlain.format(d) + " " + Months[m - 1] }

fun Int.p(): String = nfPlain.format(this)

fun faDigits(s: String): String = s.map { when { it in '0'..'9' -> '۰' + (it - '0'); it == '.' -> '٫'; else -> it } }.joinToString("")

fun fmtTime(ms: Long): String {
    val t = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault())
    return faDigits("%02d:%02d".format(t.hour, t.minute))
}

fun todayStart(): Long = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
fun daysLeft(due: Long): Int = Math.round((due - todayStart()) / 86_400_000.0).toInt()
fun fmtDateY(ms: Long): String = fmtDate(ms) + " " + jalali(ms).first.p()

/** Local midnight of a Jalali date, in epoch millis. */
fun jalaliToMs(jy0: Int, jm: Int, jd: Int): Long {
    val jy = jy0 + 1595
    var days = -355668 + 365 * jy + (jy / 33) * 8 + ((jy % 33) + 3) / 4 + jd + (if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186)
    var gy = 400 * (days / 146097); days %= 146097
    if (days > 36524) { days -= 1; gy += 100 * (days / 36524); days %= 36524; if (days >= 365) days += 1 }
    gy += 4 * (days / 1461); days %= 1461
    if (days > 365) { gy += (days - 1) / 365; days = (days - 1) % 365 }
    var gd = days + 1
    val sal = intArrayOf(0, 31, if ((gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    var gm = 0
    while (gm < 13 && gd > sal[gm]) { gd -= sal[gm]; gm++ }
    return LocalDate.of(gy, gm, gd).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
}
