package ir.modiriat.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.Instant
import java.time.ZoneId

/**
 * Due-date and task reminders. Alarms are scheduled from the database while the app is open, and the schedule
 * (keys and times, plus optional short task titles) is kept in small separate files so it can be restored after a reboot
 * even though the encrypted database cannot be opened while the phone is locked.
 * Key format: <kind><id>_<slot>  (c cheque, d debt, i installment, t task; slot 0 = on time, p = early, s = snoozed).
 */
object Reminders {
    private fun pi(ctx: Context, key: String): PendingIntent = PendingIntent.getBroadcast(
        ctx, key.hashCode(), Intent(ctx, ReminderReceiver::class.java).setAction("due.$key").putExtra("k", key),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    /** Exact when the system allows it, otherwise a slightly delayed (but still idle-safe) alarm. */
    fun set(ctx: Context, am: AlarmManager, key: String, t: Long) {
        val p = pi(ctx, key)
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
        }
    }

    fun reschedule(
        ctx: Context, cheques: List<Cheque>, debts: List<DebtEntry>, loans: List<Loan> = emptyList(),
        installments: List<Installment> = emptyList(), tasks: List<Task> = emptyList()
    ) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val rp = ctx.getSharedPreferences("rem", Context.MODE_PRIVATE)
        (rp.getStringSet("set", emptySet()) ?: emptySet()).forEach { am.cancel(pi(ctx, it.substringBefore('|'))) }
        val st = ctx.getSharedPreferences("set", Context.MODE_PRIVATE)
        val out = mutableSetOf<String>()
        val rules = mutableSetOf<String>()
        val titles = ctx.getSharedPreferences("remtitle", Context.MODE_PRIVATE).edit().clear()
        if (st.getBoolean("remOn", true)) {
            val hour = st.getInt("remHour", 9)
            val days = st.getInt("remDays", 3)
            val now = System.currentTimeMillis()
            val zone = ZoneId.systemDefault()
            fun add(key: String, due: Long) {
                for (off in listOf(days, 0).distinct()) {
                    val t = Instant.ofEpochMilli(due).atZone(zone).toLocalDate().minusDays(off.toLong()).atTime(hour, 0).atZone(zone).toInstant().toEpochMilli()
                    if (t > now) { val k = "${key}_$off"; set(ctx, am, k, t); out.add("$k|$t") }
                }
            }
            cheques.filter { it.status == 0 && it.remind && it.dueTs > 0 }.forEach { add("c${it.id}", it.dueTs) }
            // person debts: only while that person still has an open balance
            val nets = debts.groupBy { it.personId }.mapValues { e -> e.value.sumOf { debtSign(it.kind) * it.amount } }
            debts.filter { it.dueTs > 0 && (it.kind == 0 || it.kind == 1) && (nets[it.personId] ?: 0L) != 0L }.forEach { add("d${it.id}", it.dueTs) }
            // loan installments: next 24 unpaid ones
            val on = loans.filter { it.remind }.map { it.id }.toSet()
            installments.filter { !it.paid && it.loanId in on }.sortedBy { it.dueTs }.take(24).forEach { add("i${it.id}", it.dueTs) }
            // tasks: exact time, optional early reminder, repeats roll forward on their own
            tasks.filter { !it.done }.forEach { t ->
                val due = effDue(t)
                fun at(k: String, tm: Long) { if (tm > now) { set(ctx, am, k, tm); out.add("$k|$tm") } }
                at("t${t.id}_0", due)
                if (t.leadMin > 0) at("t${t.id}_p", due - t.leadMin * 60_000L)
                if (t.showTitle) titles.putString("t${t.id}", t.title.take(40))
                if (t.rep != 0) rules.add("t${t.id}|${t.rep}|$due|${t.leadMin}")
            }
        }
        titles.apply()
        rp.edit().putStringSet("set", out).putStringSet("rules", rules).apply()
    }

    /** After a repeating task fires, plan its next occurrence without opening the database. */
    fun rollForward(ctx: Context, base: String) {
        val rp = ctx.getSharedPreferences("rem", Context.MODE_PRIVATE)
        val rules = (rp.getStringSet("rules", emptySet()) ?: emptySet()).toMutableSet()
        val r = rules.firstOrNull { it.startsWith("$base|") } ?: return
        val f = r.split('|')
        val rep = f[1].toInt(); val due = f[2].toLong(); val lead = f[3].toInt()
        val next = plusRepeat(due, rep)
        rules.remove(r); rules.add("$base|$rep|$next|$lead")
        val am = ctx.getSystemService(AlarmManager::class.java)
        val out = (rp.getStringSet("set", emptySet()) ?: emptySet()).toMutableSet()
        val now = System.currentTimeMillis()
        fun at(k: String, tm: Long) { if (tm > now) { set(ctx, am, k, tm); out.removeAll { it.startsWith("$k|") }; out.add("$k|$tm") } }
        at("${base}_0", next)
        if (lead > 0) at("${base}_p", next - lead * 60_000L)
        rp.edit().putStringSet("rules", rules).putStringSet("set", out).apply()
    }

    fun snooze(ctx: Context, base: String, minutes: Int = 60) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val t = System.currentTimeMillis() + minutes * 60_000L
        set(ctx, am, "${base}_s", t)
        val rp = ctx.getSharedPreferences("rem", Context.MODE_PRIVATE)
        val out = (rp.getStringSet("set", emptySet()) ?: emptySet()).toMutableSet()
        out.removeAll { it.startsWith("${base}_s|") }; out.add("${base}_s|$t")
        rp.edit().putStringSet("set", out).apply()
    }

    /** A test notification one minute from now (not stored in the schedule). */
    fun test(ctx: Context) {
        ctx.getSharedPreferences("remtitle", Context.MODE_PRIVATE).edit().putString("ttest", "آزمایش یادآوری موفق بود").apply()
        set(ctx, ctx.getSystemService(AlarmManager::class.java), "ttest_0", System.currentTimeMillis() + 60_000L)
    }

    /** After reboot: re-register future alarms from the saved schedule (no database access). */
    fun rescheduleFromPrefs(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()
        (ctx.getSharedPreferences("rem", Context.MODE_PRIVATE).getStringSet("set", emptySet()) ?: emptySet()).forEach {
            val t = it.substringAfter('|').toLongOrNull() ?: return@forEach
            if (t > now) set(ctx, am, it.substringBefore('|'), t)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        val key = i.getStringExtra("k") ?: return
        val base = key.substringBefore('_')
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (i.action?.startsWith("snooze.") == true) {
            nm.cancel(base.hashCode())
            Reminders.snooze(ctx, base)
            return
        }
        val isTask = base.startsWith("t")
        if (isTask && key.endsWith("_0")) Reminders.rollForward(ctx, base)
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val ch = if (isTask) "tasks" else "due"
        nm.createNotificationChannel(
            NotificationChannel(ch, if (isTask) "یادآوری کارها" else "سررسیدها", if (isTask) NotificationManager.IMPORTANCE_HIGH else NotificationManager.IMPORTANCE_DEFAULT)
        )
        val icon = android.R.drawable.ic_popup_reminder
        val title = if (isTask) ctx.getSharedPreferences("remtitle", Context.MODE_PRIVATE).getString(base, null) else null
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        // generic public text: titles, names and amounts never show on the lock screen
        val pub = NotificationCompat.Builder(ctx, ch).setSmallIcon(icon).setContentTitle("حسابداری شخصی")
            .setContentText(if (isTask) "یک یادآوری دارید" else "یک سررسید دارید").build()
        val b = NotificationCompat.Builder(ctx, ch).setSmallIcon(icon)
            .setContentTitle(title ?: if (isTask) "یادآوری" else "یادآوری سررسید")
            .setContentText(if (title == null && isTask) "یک یادآوری دارید" else "برای دیدن جزئیات برنامه را باز کنید")
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE).setPublicVersion(pub).setContentIntent(open).setAutoCancel(true)
        if (isTask) {
            val sn = PendingIntent.getBroadcast(
                ctx, ("sn$base").hashCode(), Intent(ctx, ReminderReceiver::class.java).setAction("snooze.$base").putExtra("k", "${base}_s"),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(0, "۱ ساعت بعد", sn)
        }
        nm.notify(base.hashCode(), b.build())
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) Reminders.rescheduleFromPrefs(ctx)
    }
}
