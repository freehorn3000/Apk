package ir.modiriat.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import java.time.Instant
import java.time.ZoneId

/**
 * Due-date reminders. Alarms are scheduled from the database while the app is open, and the schedule
 * (only keys and times, no names or amounts) is kept in a small separate file so it can be restored after a reboot
 * even though the encrypted database cannot be opened while the phone is locked.
 */
object Reminders {
    private fun pi(ctx: Context, key: String): PendingIntent = PendingIntent.getBroadcast(
        ctx, key.hashCode(), Intent(ctx, ReminderReceiver::class.java).setAction("due.$key").putExtra("k", key),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun set(ctx: Context, am: AlarmManager, key: String, t: Long) {
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi(ctx, key))
    }

    fun reschedule(ctx: Context, cheques: List<Cheque>, debts: List<DebtEntry>, loans: List<Loan> = emptyList(), installments: List<Installment> = emptyList()) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val rp = ctx.getSharedPreferences("rem", Context.MODE_PRIVATE)
        (rp.getStringSet("set", emptySet()) ?: emptySet()).forEach { am.cancel(pi(ctx, it.substringBefore('|'))) }
        val st = ctx.getSharedPreferences("set", Context.MODE_PRIVATE)
        val out = mutableSetOf<String>()
        if (st.getBoolean("remOn", true)) {
            val hour = st.getInt("remHour", 9)
            val days = st.getInt("remDays", 3)
            val now = System.currentTimeMillis()
            val zone = ZoneId.systemDefault()
            fun add(key: String, due: Long) {
                for (off in listOf(days, 0).distinct()) {
                    val t = Instant.ofEpochMilli(due).atZone(zone).toLocalDate().minusDays(off.toLong()).atTime(hour, 0).atZone(zone).toInstant().toEpochMilli()
                    if (t > now) { val k = "${key}_$off"; set(ctx, am, k, t); out.add("$k|$t") }
                }
            }
            cheques.filter { it.status == 0 && it.remind && it.dueTs > 0 }.forEach { add("c${it.id}", it.dueTs) }
            // person debts: only while that person still has an open balance
            val nets = debts.groupBy { it.personId }.mapValues { e -> e.value.sumOf { debtSign(it.kind) * it.amount } }
            debts.filter { it.dueTs > 0 && (it.kind == 0 || it.kind == 1) && (nets[it.personId] ?: 0L) != 0L }.forEach { add("d${it.id}", it.dueTs) }
            // loan installments: next 24 unpaid ones
            val on = loans.filter { it.remind }.map { it.id }.toSet()
            installments.filter { !it.paid && it.loanId in on }.sortedBy { it.dueTs }.take(24).forEach { add("i${it.id}", it.dueTs) }
        }
        rp.edit().putStringSet("set", out).apply()
    }

    /** After reboot: re-register future alarms from the saved schedule (no database access). */
    fun rescheduleFromPrefs(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val now = System.currentTimeMillis()
        (ctx.getSharedPreferences("rem", Context.MODE_PRIVATE).getStringSet("set", emptySet()) ?: emptySet()).forEach {
            val t = it.substringAfter('|').toLongOrNull() ?: return@forEach
            if (t > now) set(ctx, am, it.substringBefore('|'), t)
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("due", "سررسیدها", NotificationManager.IMPORTANCE_DEFAULT))
        val icon = android.R.drawable.ic_popup_reminder
        val open = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        // generic text: no names or amounts on the lock screen
        val pub = NotificationCompat.Builder(ctx, "due").setSmallIcon(icon).setContentTitle("حسابداری شخصی").setContentText("یک سررسید دارید").build()
        val n = NotificationCompat.Builder(ctx, "due").setSmallIcon(icon).setContentTitle("یادآوری سررسید")
            .setContentText("برای دیدن جزئیات برنامه را باز کنید").setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(pub).setContentIntent(open).setAutoCancel(true).build()
        nm.notify((i.getStringExtra("k") ?: "x").hashCode(), n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) Reminders.rescheduleFromPrefs(ctx)
    }
}
