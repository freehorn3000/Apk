package ir.modiriat.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.os.PersistableBundle
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

private val Grads = listOf(
    0xFF0B7A5EL to 0xFF064A3AL, 0xFF2F6FE0L to 0xFF1B3F8FL, 0xFF7450D8L to 0xFF46288FL,
    0xFFC9453DL to 0xFF86221DL, 0xFF1F9A8BL to 0xFF0F5A52L, 0xFFC4508AL to 0xFF7E2A58L
)
val Banks = listOf(
    "ملی", "ملت", "صادرات", "تجارت", "سپه", "رفاه", "کشاورزی", "مسکن", "پاسارگاد", "پارسیان", "سامان",
    "اقتصاد نوین", "سینا", "شهر", "آینده", "دی", "کارآفرین", "سرمایه", "پست بانک", "مهر ایران", "توسعه صادرات", "انصار", "ایران زمین"
)
private val Bin = mapOf(
    "603799" to "ملی", "589210" to "سپه", "627648" to "توسعه صادرات", "603770" to "کشاورزی", "628023" to "مسکن",
    "627760" to "پست بانک", "627412" to "اقتصاد نوین", "622106" to "پارسیان", "639194" to "پارسیان",
    "502229" to "پاسارگاد", "639347" to "پاسارگاد", "627488" to "کارآفرین", "621986" to "سامان", "639346" to "سینا",
    "639607" to "سرمایه", "636214" to "آینده", "502806" to "شهر", "504706" to "شهر", "502938" to "دی",
    "603769" to "صادرات", "610433" to "ملت", "627353" to "تجارت", "585983" to "تجارت", "589463" to "رفاه",
    "627381" to "انصار", "606373" to "مهر ایران", "505785" to "ایران زمین"
)

/** Any Unicode digits → latin digits, everything else dropped. */
fun digits(s: String): String = buildString { s.forEach { val d = Character.digit(it, 10); if (d >= 0) append(d) } }

fun luhn(s: String): Boolean {
    if (s.length != 16 || !s.all { it in '0'..'9' }) return false
    var sum = 0
    for ((i, ch) in s.reversed().withIndex()) {
        var d = ch - '0'
        if (i % 2 == 1) { d *= 2; if (d > 9) d -= 9 }
        sum += d
    }
    return sum % 10 == 0
}

/** Balance per card id (0 = cash): initial balance + income − expense ± transfers. */
fun balances(cards: List<BankCard>, txs: List<Tx>, trs: List<Transfer>, debts: List<DebtEntry> = emptyList()): Map<Long, Long> {
    val m = HashMap<Long, Long>(); m[0L] = 0L
    cards.forEach { m[it.id] = it.initial }
    txs.forEach { m[it.cardId] = (m[it.cardId] ?: 0L) + if (it.income) it.amount else -it.amount }
    trs.forEach { m[it.fromId] = (m[it.fromId] ?: 0L) - it.amount; m[it.toId] = (m[it.toId] ?: 0L) + it.amount }
    debts.forEach { if (it.cardId >= 0) m[it.cardId] = (m[it.cardId] ?: 0L) + if (it.kind == 1 || it.kind == 2) it.amount else -it.amount }
    return m
}

fun Context.activity(): FragmentActivity? {
    var c: Context? = this
    while (c is ContextWrapper) { if (c is FragmentActivity) return c; c = c.baseContext }
    return null
}

@Composable
fun CardsScreen(
    pad: PaddingValues, cards: List<BankCard>, bal: Map<Long, Long>,
    onAdd: (BankCard) -> Unit, onUpdate: (BankCard) -> Unit, onDel: (BankCard, () -> Unit) -> Unit,
    onTransfer: (Transfer) -> Unit, onMsg: (String) -> Unit, onLog: (String) -> Unit
) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var revealed by remember { mutableStateOf<Long?>(null) }
    var edit by remember { mutableStateOf<BankCard?>(null) }
    var adding by remember { mutableStateOf(false) }
    var trf by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf<BankCard?>(null) }
    LaunchedEffect(revealed) { if (revealed != null) { delay(20000); revealed = null } }

    fun guard(ok: () -> Unit) {
        val a = ctx.activity()
        if (a == null) onMsg("خطا در تأیید هویت") else authenticate(a, "تأیید هویت", ok)
    }
    fun copy(c: BankCard) {
        val cm = ctx.getSystemService(ClipboardManager::class.java)
        val clip = ClipData.newPlainText("card", c.number)
        clip.description.extras = PersistableBundle().apply { putBoolean("android.content.extra.IS_SENSITIVE", true) }
        cm.setPrimaryClip(clip)
        onMsg("شماره کارت کپی شد. بعد از ۳۰ ثانیه پاک می‌شود")
        scope.launch {
            delay(30000)
            val cur = runCatching { cm.primaryClip?.getItemAt(0)?.text?.toString() }.getOrNull()
            if (cur == null || cur == c.number) runCatching { cm.clearPrimaryClip() }
        }
    }

    LazyColumn(
        Modifier.padding(pad).fillMaxSize(),
        contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 150.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("کارت‌ها", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton({ trf = true }) { Text("انتقال") }
                    Button({ adding = true }) { Text("＋ کارت") }
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(cs.surfaceContainerLow).padding(18.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically
            ) {
                Text("💵 نقدی / بدون کارت", fontWeight = FontWeight.SemiBold)
                Text("${(bal[0L] ?: 0L).fa()} تومان", fontWeight = FontWeight.Bold)
            }
        }
        items(cards, key = { it.id }) { c ->
            CardTile(
                c, bal[c.id] ?: c.initial, revealed == c.id,
                onReveal = { guard { revealed = c.id; onLog("شماره کامل کارت نمایش داده شد") } },
                onCopy = { guard { copy(c); onLog("شماره کارت کپی شد") } },
                onEdit = { edit = c }, onDel = { del = c }
            )
        }
        if (cards.isEmpty()) item { Text("هنوز کارتی اضافه نکرده‌اید.", color = cs.onSurfaceVariant) }
    }

    if (adding) CardDialog(null, { onAdd(it); adding = false }) { adding = false }
    edit?.let { e -> CardDialog(e, { onUpdate(it); edit = null }) { edit = null } }
    if (trf) TransferDialog(cards, { onTransfer(it); trf = false }) { trf = false }
    del?.let { d ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("حذف کارت؟") },
            text = { Text("«${d.name.ifBlank { d.bank }}» حذف می‌شود. کارتی که تراکنش دارد حذف نمی‌شود.") },
            confirmButton = { TextButton({ onDel(d) { onMsg("این کارت تراکنش دارد و حذف نمی‌شود") }; del = null }) { Text("حذف") } },
            dismissButton = { TextButton({ del = null }) { Text("انصراف") } }
        )
    }
}

@Composable
fun CardTile(c: BankCard, balance: Long, shown: Boolean, onReveal: () -> Unit, onCopy: () -> Unit, onEdit: () -> Unit, onDel: () -> Unit) {
    val g = Grads[abs(c.bank.hashCode()) % Grads.size]
    val white = ButtonDefaults.textButtonColors(contentColor = Color.White)
    // LRE/PDF keep the digit groups in left-to-right order inside the RTL layout
    val number = if (shown) c.number.chunked(4).joinToString(" ") else "•••• •••• •••• " + c.number.takeLast(4)
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(g.first), Color(g.second)))).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            Text("بانک ${c.bank}", color = Color.White, fontWeight = FontWeight.Bold)
            if (c.name.isNotBlank()) Text(c.name, color = Color.White.copy(alpha = .85f))
        }
        Text("\u202A$number\u202C", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Medium)
        Text("موجودی", color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.bodySmall)
        Text("${balance.fa()} تومان", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
            TextButton(onReveal, colors = white) { Text("نمایش") }
            TextButton(onCopy, colors = white) { Text("کپی") }
            TextButton(onEdit, colors = white) { Text("ویرایش") }
            TextButton(onDel, colors = white) { Text("حذف") }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CardDialog(init: BankCard?, onSave: (BankCard) -> Unit, onClose: () -> Unit) {
    var bank by remember { mutableStateOf(init?.bank ?: "") }
    var number by remember { mutableStateOf(init?.number ?: "") }
    var name by remember { mutableStateOf(init?.name ?: "") }
    var initial by remember { mutableStateOf(init?.initial?.toString() ?: "") }
    LaunchedEffect(number) { if (bank.isBlank() && number.length >= 6) Bin[number.take(6)]?.let { bank = it } }
    val ok = bank.isNotBlank() && luhn(number)
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (init == null) "کارت جدید" else "ویرایش کارت") },
        confirmButton = {
            TextButton(
                { onSave(BankCard(id = init?.id ?: 0, bank = bank.trim(), number = number, name = name.trim(), initial = digits(initial).toLongOrNull() ?: 0L)) },
                enabled = ok
            ) { Text("ذخیره") }
        },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    number, { number = digits(it).take(16) }, Modifier.fillMaxWidth(),
                    label = { Text("شماره کارت (۱۶ رقم)") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    supportingText = { if (number.length == 16 && !luhn(number)) Text("شماره کارت معتبر نیست") }
                )
                OutlinedTextField(bank, { bank = it.take(24) }, Modifier.fillMaxWidth(), label = { Text("نام بانک") }, singleLine = true)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Banks.forEach { b -> FilterChip(bank == b, { bank = b }, { Text(b) }) }
                }
                OutlinedTextField(name, { name = it.take(20) }, Modifier.fillMaxWidth(), label = { Text("نام دلخواه (اختیاری)") }, singleLine = true)
                OutlinedTextField(
                    initial, { initial = digits(it) }, Modifier.fillMaxWidth(),
                    label = { Text("موجودی اولیه (تومان)") }, visualTransformation = Thousands, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TransferDialog(cards: List<BankCard>, onSave: (Transfer) -> Unit, onClose: () -> Unit) {
    val opts = listOf(0L to "نقدی") + cards.map { it.id to it.name.ifBlank { it.bank } }
    var from by remember { mutableStateOf(opts.first().first) }
    var to by remember { mutableStateOf(opts.getOrElse(1) { opts.first() }.first) }
    var amt by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    val v = digits(amt).toLongOrNull()
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("انتقال بین کارت‌ها") },
        confirmButton = {
            TextButton(
                { onSave(Transfer(fromId = from, toId = to, amount = v!!, note = note.trim(), ts = System.currentTimeMillis())) },
                enabled = v != null && v > 0 && from != to
            ) { Text("ثبت") }
        },
        dismissButton = { TextButton(onClose) { Text("انصراف") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("از")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { opts.forEach { o -> FilterChip(from == o.first, { from = o.first }, { Text(o.second) }) } }
                Text("به")
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) { opts.forEach { o -> FilterChip(to == o.first, { to = o.first }, { Text(o.second) }) } }
                OutlinedTextField(
                    amt, { amt = digits(it) }, Modifier.fillMaxWidth(), label = { Text("مبلغ (تومان)") }, visualTransformation = Thousands, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("یادداشت (اختیاری)") }, singleLine = true)
            }
        }
    )
}
