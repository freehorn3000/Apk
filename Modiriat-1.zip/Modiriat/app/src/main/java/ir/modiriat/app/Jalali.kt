package ir.modiriat.app

import java.text.NumberFormat
import java.time.Instant
import java.time.ZoneId
import java.util.Locale

private val nf = NumberFormat.getInstance(Locale.forLanguageTag("fa"))
private val nfPlain = NumberFormat.getInstance(Locale.forLanguageTag("fa")).apply { isGroupingUsed = false }
val Months = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")

fun Long.fa(): String = nf.format(this)

fun jalali(ms: Long): Triple<Int, Int, Int> {
    val d = Instant.ofEpochMilli(ms).atZone(ZoneId.systemDefault()).toLocalDate()
    val gy = d.year; val gm = d.monthValue; val gd = d.dayOfMonth
    val g = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
    val gy2 = if (gm > 2) gy + 1 else gy
    var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + g[gm - 1]
    var jy = -1595 + 33 * (days / 12053); days %= 12053
    jy += 4 * (days / 1461); days %= 1461
    if (days > 365) { jy += (days - 1) / 365; days = (days - 1) % 365 }
    val jm = if (days < 186) 1 + days / 31 else 7 + (days - 186) / 30
    val jd = 1 + if (days < 186) days % 31 else (days - 186) % 30
    return Triple(jy, jm, jd)
}

fun fmtDate(ms: Long): String { val (_, m, d) = jalali(ms); return nfPlain.format(d) + " " + Months[m - 1] }
