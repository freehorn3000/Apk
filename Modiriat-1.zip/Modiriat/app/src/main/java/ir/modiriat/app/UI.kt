package ir.modiriat.app

import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.draw.scale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.lifecycle.viewmodel.compose.viewModel

private val Light = lightColorScheme(
    primary = Color(0xFF0E8F6E), onPrimary = Color.White, primaryContainer = Color(0xFFCDEBE1),
    background = Color(0xFFEEF3F1), surface = Color(0xFFEEF3F1), onSurface = Color(0xFF12302B),
    onSurfaceVariant = Color(0xFF5B716C), error = Color(0xFFD9453D),
    surfaceContainerLow = Color.White, surfaceContainerHighest = Color(0xFFD9E4E0)
)
private val Dark = darkColorScheme(
    primary = Color(0xFF4FD1A9), onPrimary = Color(0xFF00382B), primaryContainer = Color(0xFF1B4A3E),
    background = Color(0xFF0D1514), surface = Color(0xFF0D1514), onSurface = Color(0xFFE3EDEA),
    onSurfaceVariant = Color(0xFF9BB0AB), error = Color(0xFFFF8A80),
    surfaceContainerLow = Color(0xFF16211F), surfaceContainerHighest = Color(0xFF26332F)
)

@Composable
fun Theme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
    }
}

@Composable
fun LockScreen(onTry: () -> Unit) {
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("🔒", fontSize = 56.sp)
            Text("مدیریت", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            FilledTonalButton(onTry) { Text("باز کردن قفل") }
        }
    }
}

@Composable
fun App(vm: VM = viewModel()) {
    val txs by vm.txs.collectAsState()
    val cats by vm.cats.collectAsState()
    val byId = cats.associateBy { it.id }
    val now = jalali(System.currentTimeMillis())
    val month = txs.filter { val j = jalali(it.ts); j.first == now.first && j.second == now.second }
    val inc = month.filter { it.income }.sumOf { it.amount }
    val exp = month.filter { !it.income }.sumOf { it.amount }
    val balance = txs.sumOf { if (it.income) it.amount else -it.amount }
    val cs = MaterialTheme.colorScheme
    var sheet by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        status = if (ok) "حالا دکمه را نگه دارید و صحبت کنید" else "برای ثبت صوتی، اجازه میکروفون لازم است"
    }
    val handle = rememberUpdatedState { text: String ->
        val p = parseVoice(text)
        val amt = p.amount
        val c = pickCat(cats, p)
        if (amt == null) status = "مبلغ را متوجه نشدم: «$text»"
        else if (c == null) status = "دسته‌ای پیدا نشد"
        else vm.add(Tx(amount = amt, income = p.income, catId = c.id, note = text, ts = System.currentTimeMillis())) { saved ->
            scope.launch {
                val r = snack.showSnackbar(
                    "${if (saved.income) "درآمد" else "هزینه"} ${saved.amount.fa()} تومان · ${c.name} ثبت شد",
                    "واگرد", duration = SnackbarDuration.Short
                )
                if (r == SnackbarResult.ActionPerformed) vm.del(saved)
            }
        }
    }
    val voice = remember { Voice(ctx, { handle.value(it) }, { status = it }) }
    DisposableEffect(Unit) { onDispose { voice.destroy() } }
    LaunchedEffect(status, listening) { if (status.isNotEmpty() && !listening) { delay(4000); status = "" } }

    Scaffold(
        containerColor = cs.background,
        snackbarHost = { SnackbarHost(snack) },
        floatingActionButton = {
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (status.isNotEmpty()) Surface(shape = RoundedCornerShape(16.dp), color = cs.surfaceContainerHighest) {
                    Text(status, Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    SmallFloatingActionButton({ sheet = true }) { Icon(Icons.Default.Add, "تراکنش جدید") }
                    Box(
                        Modifier.size(76.dp).scale(if (listening) 1.12f else 1f).clip(CircleShape)
                            .background(if (listening) cs.error else cs.primary)
                            .semantics { contentDescription = "نگه دارید و هزینه یا درآمد را بگویید" }
                            .pointerInput(Unit) {
                                detectTapGestures(onPress = {
                                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                                        perm.launch(Manifest.permission.RECORD_AUDIO)
                                    } else {
                                        listening = true; status = "در حال گوش دادن…"; voice.start()
                                        tryAwaitRelease()
                                        listening = false; voice.stop()
                                    }
                                })
                            },
                        Alignment.Center
                    ) { Text("🎙️", fontSize = 32.sp) }
                }
            }
        }
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 140.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Header(balance, inc, exp, now.second) }
            item { CatBars(month.filter { !it.income }, byId) }
            item { Text("تراکنش‌ها", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            if (txs.isEmpty()) item {
                Text("دکمه 🎙️ را نگه دارید و بگویید: «ناهار صد و پنجاه هزار تومان» یا «حقوق ۲۵ میلیون واریز شد». یا با + دستی ثبت کنید.", color = cs.onSurfaceVariant)
            }
            items(txs, key = { it.id }) { t -> TxRow(t, byId[t.catId]) { vm.del(t) } }
        }
    }
    if (sheet) AddSheet(cats, { sheet = false }) { vm.add(it); sheet = false }
}

@Composable
fun Header(bal: Long, inc: Long, exp: Long, m: Int) {
    val cs = MaterialTheme.colorScheme
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("موجودی کل", color = cs.onSurfaceVariant)
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(bal.fa(), fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 52.sp)
            Text("تومان", color = cs.onSurfaceVariant, modifier = Modifier.padding(bottom = 8.dp))
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(cs.surfaceContainerHighest)) {
            if (inc + exp > 0) Row(Modifier.fillMaxSize()) {
                if (inc > 0) Box(Modifier.weight(inc.toFloat()).fillMaxHeight().background(cs.primary))
                if (exp > 0) Box(Modifier.weight(exp.toFloat()).fillMaxHeight().background(cs.error))
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("درآمد ${Months[m - 1]}", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text(inc.fa(), color = cs.primary, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("هزینه ${Months[m - 1]}", color = cs.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                Text(exp.fa(), color = cs.error, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun CatBars(ex: List<Tx>, cats: Map<Long, Category>) {
    val g = ex.groupBy { it.catId }.mapValues { e -> e.value.sumOf { it.amount } }.entries.sortedByDescending { it.value }.take(4)
    if (g.isEmpty()) return
    val top = g.first().value.toFloat()
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surfaceContainerLow).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("بیشترین هزینه‌ها در این ماه", fontWeight = FontWeight.Bold)
        g.forEach { e ->
            val c = cats[e.key]
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${c?.emoji ?: ""} ${c?.name ?: ""}")
                    Text(e.value.fa(), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box(Modifier.fillMaxWidth(e.value / top).height(6.dp).clip(CircleShape).background(Color(c?.color ?: 0xFF8A9A96)))
            }
        }
    }
}

@Composable
fun TxRow(t: Tx, c: Category?, onDel: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(cs.surfaceContainerLow).padding(start = 12.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(Color(c?.color ?: 0xFF8A9A96).copy(alpha = .22f)), Alignment.Center) { Text(c?.emoji ?: "•") }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(c?.name ?: "", fontWeight = FontWeight.SemiBold)
            Text(fmtDate(t.ts) + if (t.note.isNotBlank()) " · ${t.note}" else "", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
        }
        Text((if (t.income) "+" else "−") + t.amount.fa(), color = if (t.income) cs.primary else cs.error, fontWeight = FontWeight.Bold)
        IconButton(onDel) { Icon(Icons.Default.Delete, "حذف", tint = cs.onSurfaceVariant) }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AddSheet(cats: List<Category>, onClose: () -> Unit, onSave: (Tx) -> Unit) {
    var inc by remember { mutableStateOf(false) }
    var amt by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var cid by remember { mutableStateOf<Long?>(null) }
    val v = amt.map { Character.digit(it, 10) }.joinToString("").toLongOrNull()
    ModalBottomSheet(onDismissRequest = onClose) {
        Column(Modifier.padding(20.dp).navigationBarsPadding().imePadding(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                listOf("هزینه", "درآمد").forEachIndexed { i, l ->
                    SegmentedButton(selected = (i == 1) == inc, onClick = { inc = i == 1; cid = null }, shape = SegmentedButtonDefaults.itemShape(i, 2)) { Text(l) }
                }
            }
            OutlinedTextField(
                amt, { amt = it.filter { ch -> ch.isDigit() } }, Modifier.fillMaxWidth(),
                label = { Text("مبلغ (تومان)") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cats.filter { it.income == inc }.forEach { c ->
                    FilterChip(cid == c.id, { cid = c.id }, { Text("${c.emoji} ${c.name}") })
                }
            }
            OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), label = { Text("یادداشت (اختیاری)") }, singleLine = true)
            Button(
                { onSave(Tx(amount = v!!, income = inc, catId = cid!!, note = note.trim(), ts = System.currentTimeMillis())) },
                Modifier.fillMaxWidth().height(52.dp), enabled = v != null && v > 0 && cid != null
            ) { Text("ثبت") }
            Spacer(Modifier.height(8.dp))
        }
    }
}
